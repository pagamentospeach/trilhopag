# Tracking / Ads module — export do BravoPay

Módulo de **tracking estilo UTMify** extraído do gateway BravoPay (Next.js App
Router + Prisma). Faz:

- **Conectar contas de anúncio** (Meta, TikTok, Google, Kwai) via OAuth.
- **Puxar o gasto** (insights) das campanhas/conjuntos/anúncios (sync em lote,
  sem estourar rate limit).
- **Atribuir vendas → campanha** por UTM (casa por `nome|id`, **nome puro** ou
  só `id`) e calcular **ROAS / lucro / CPA**.
- **Dashboard de ads**: ROAS por plataforma, melhor/pior campanha, ranking de
  criativos, ROAS por produto, favoritas, projeção de fim de dia, hoje × ontem,
  gráfico de evolução, alerta de queima.
- **Regras automáticas** (pausar/ativar/escalar por ROAS/CPA/gasto/hora…).
- **Subir campanhas em massa**, **apelação em massa** (TikTok), **multi-moeda**
  (câmbio ao vivo → BRL), **export CSV**.

> Tudo aqui já está **pronto e rodando em produção**. É só adaptar as 6
> dependências externas (abaixo) e o schema.

---

## 1. Estrutura

```
src/app/dashboard/tracking/        → as abas (UI): integrações, campanhas, regras,
                                     massa, apelação, diagnóstico, tutorial
src/app/dashboard/ads-actions.ts   → actions do dashboard (pausar/escalar campanha)
src/components/dashboard/ads-*.tsx → seção "Ads" do dashboard + gráfico (recharts)

src/lib/ad-sync.ts                 → sync de campanhas/insights (Meta+TikTok); set status/budget/nome
src/lib/ad-insights.ts             → CRON: snapshot diário + alerta de queima + auto-scale + resumo
src/lib/ads-overview.ts            → monta a visão de ads do dashboard (lê do banco)
src/lib/rule-engine.ts             → motor de regras automáticas
src/lib/utm-match.ts               → ⭐ atribuição venda→campanha (nome|id / nome / id)
src/lib/fx.ts                      → câmbio ao vivo p/ BRL (+ override por conta)
src/lib/mass-campaign-publish.ts   → publica campanha (Meta/TikTok) no mass upload
src/lib/platform-apps.ts           → credenciais Meta/TikTok (DB → env fallback)
src/lib/utmify.ts                  → dispatch de conversões PRA UTMify (remova se VOCÊ é o UTMify)
src/lib/crypto.ts                  → AES-GCM (criptografa os tokens OAuth) — usa APP_ENCRYPTION_KEY
src/lib/providers/*-ads.ts         → clients das APIs Meta/TikTok/Google/Kwai

src/app/api/oauth/{meta,tiktok,google,kwai}/  → connect / callback / sync / disconnect
src/app/api/cron/{ad-sync,ad-rules,ad-insights,process-mass-campaigns,dispatch-utmify}/
src/app/admin01/(authed)/apps/     → painel admin pra setar App ID/Secret (opcional)

prisma/schema-tracking.prisma      → os 13 models necessários
```

---

## 2. Dependências externas que VOCÊ precisa fornecer

Esses imports `@/lib/...` e `./...` **não vieram no pacote** (são infra do app
maior). Forneça os seus (ou stubs):

| Import | O que é | Mínimo necessário |
|---|---|---|
| `@/lib/prisma` (`./prisma`) | Client do Prisma | `export const prisma = new PrismaClient(...)` |
| `@/lib/auth-helpers` | Usuário logado | `requireUserId(): Promise<string>` e `requireSessionUserId()` |
| `@/lib/security/origin` | CSRF | `assertSafeOrigin(): Promise<void>` (pode ser no-op no começo) |
| `@/lib/utils` | Helpers de UI | `formatBRL(cents:number):string`, `cn(...classes)` |
| `@/lib/push` (`./push`) | Web Push (alertas) | `sendPushToUser(userId, payload)` — opcional, pode stubar `async()=>({sent:0})` |
| `@/lib/rate-limit` | Rate limit OAuth/cron | pode stubar pra sempre permitir |
| `@/lib/admin-auth` | Gating do painel admin | só pra `admin01/apps` — remova se não usar |
| `@/lib/checkout-url`, `@/lib/internal-purchases` | Específicos do gateway | usados em tutorial/massa — stub/remova |

### ⚠️ A FONTE DAS VENDAS (o mais importante)
O tracking lê as conversões de **`prisma.transaction`** (status `PAID`, com
`utmCampaign` / `utmMedium` / `utmContent`, `amountCents`, `paidAt`, `userId`).

No seu SaaS, **troque por SUA tabela de conversões/pixel** com esses campos.
Procure por `prisma.transaction.findMany` em `ads-overview.ts`, `ad-insights.ts`,
`rule-engine.ts` e `tracking/campanhas/page.tsx` e aponte pra sua fonte.

---

## 3. npm

`next` (App Router, v15/16), `react`, `@prisma/client` (+ adapter do seu banco),
`zod`, `recharts`, `lucide-react`, `web-push` (alertas), `next-intl` (i18n — só
no `layout.tsx`, dá pra remover).

---

## 4. Env vars

```
DATABASE_URL=...
APP_ENCRYPTION_KEY=<base64 de 32 bytes>   # cripto dos tokens OAuth (crypto.ts)
CRON_SECRET=<segredo>                      # protege os /api/cron/*
NEXT_PUBLIC_APP_URL=https://seuapp.com     # redirect do OAuth

# Apps (ou cadastre no DB via PlatformAppConfig / painel admin/apps)
META_APP_ID=...        META_APP_SECRET=...    META_CONFIG_ID=...
TIKTOK_APP_ID=...      TIKTOK_APP_SECRET=...
GOOGLE_ADS_*=...       KWAI_*=...             # se for usar

# Web Push (opcional — alertas)
VAPID_PUBLIC_KEY=...   VAPID_PRIVATE_KEY=...  VAPID_SUBJECT=mailto:...
```

## 5. Crons (vercel.json)

```json
{ "crons": [
  { "path": "/api/cron/ad-sync",                "schedule": "*/30 * * * *" },
  { "path": "/api/cron/ad-rules",               "schedule": "*/15 * * * *" },
  { "path": "/api/cron/ad-insights",            "schedule": "15,45 * * * *" },
  { "path": "/api/cron/process-mass-campaigns", "schedule": "*/2 * * * *" },
  { "path": "/api/cron/dispatch-utmify",        "schedule": "* * * * *" }
]}
```
Os crons exigem `Authorization: Bearer $CRON_SECRET`.

---

## 6. Fluxo (como funciona)

1. **Conectar**: `/api/oauth/<plataforma>/connect` → callback grava `AdAccount`
   com o token **criptografado** (`crypto.ts`).
2. **Sync** (`ad-sync.ts`, cron a cada 30min): puxa campanhas/conjuntos/anúncios
   + **gasto em lote** (1 chamada por nível, evita rate limit) → grava
   `AdCampaign/AdAdset/Ad` (`spendCentsDay`, etc).
3. **Atribuição** (`utm-match.ts`): casa `Transaction.utmCampaign` com a campanha
   por **`nome|id` → nome puro → id**. (Era o bug clássico: só casava `nome|id` e
   ignorava o nome puro do TikTok.) ROAS = receita ÷ gasto.
4. **Dashboard** (`ads-overview.ts`): visão consolidada (lê do banco, converte
   gasto pra BRL com `fx.ts`).
5. **Regras** (`rule-engine.ts`, cron a cada 15min): avalia condições
   (roas/cpa/spend/ctr/hora…) e age (pausar/ativar/budget) via API da plataforma.
6. **Snapshots/alertas** (`ad-insights.ts`, cron): grava o histórico diário,
   dispara push de "queimando dinheiro" e escala vencedoras.

---

## 7. O que dá pra cortar (específico do gateway)

- `tracking/massa`, `mass-campaign-publish.ts`, cron `process-mass-campaigns` →
  subir campanhas em massa (mantém se quiser esse diferencial).
- `tracking/apelacao` → apelação em massa de anúncio reprovado (TikTok).
- `tracking/tutorial`, `utmify.ts` + cron `dispatch-utmify` → se VOCÊ é o UTMify,
  não precisa despachar pra ele.
- `admin01/(authed)/apps` → se gerenciar as credenciais de outro jeito.
- `providers/google-ads.ts`, `kwai-ads.ts` → esqueletos; foco real é Meta+TikTok.

---

## 8. Schema

`prisma/schema-tracking.prisma` tem os 13 models: `AdAccount`, `AdCampaign`,
`AdAdset`, `Ad`, `AdRule`, `AdRuleExecution`, `AdSpendSnapshot`,
`PlatformAppConfig`, `MassCampaignTemplate`, `MassCampaignJob`, `UtmifyConfig`,
`TrackingPixel` + enum `TrackingPlatform`. Ajuste os `@relation` com o seu `User`
e a sua tabela de conversões.
