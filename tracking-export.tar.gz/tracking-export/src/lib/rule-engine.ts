/**
 * Engine de regras automatizadas. Roda via cron periodicamente.
 *
 * Para cada regra ativa do usuário:
 *  1. Carrega objetos (campanhas/conjuntos/anúncios) no escopo
 *  2. Pega métricas agregadas no período (window)
 *  3. Avalia condições
 *  4. Aplica ação (pause/activate/budget) via Meta API
 *  5. Salva log em AdRuleExecution
 */
import { prisma } from "./prisma";
import { decryptString } from "./crypto";
import {
  updateObjectStatus,
  updateBudget,
  getInsights,
} from "./providers/meta-ads";
import {
  updateObjectStatus as tiktokUpdateObjectStatus,
  updateBudget as tiktokUpdateBudget,
} from "./providers/tiktok-ads";
import { sendPushToUser } from "./push";
import { normUtm, resolveUtmToExternalId } from "./utm-match";

type Condition = {
  metric: "spend" | "cpa" | "roas" | "roi" | "profit" | "margin" | "cpc" | "ctr" | "impressions" | "sales" | "hour";
  op: "gt" | "lt" | "gte" | "lte" | "eq";
  value: number;
};

type Action = {
  type: "pause" | "activate" | "budget_increase" | "budget_decrease" | "notify";
  value?: number; // % para budget actions
};

type Scope = {
  productId?: string;
  accountIds?: string[];
  applyTo?: "campaigns" | "adsets" | "ads";
  filter?: "active" | "all";
  nameFilter?: string;
};

function evalCondition(value: number, cond: Condition): boolean {
  switch (cond.op) {
    case "gt":
      return value > cond.value;
    case "lt":
      return value < cond.value;
    case "gte":
      return value >= cond.value;
    case "lte":
      return value <= cond.value;
    case "eq":
      return Math.abs(value - cond.value) < 0.001;
  }
}

function windowToDatePreset(w: string): string {
  switch (w) {
    case "30m":
      return "today";
    case "1h":
      return "today";
    case "1d":
      return "today";
    case "7d":
      return "last_7d";
    default:
      return "today";
  }
}

async function getMetricValue(
  metric: Condition["metric"],
  spendCents: number,
  salesCents: number,
  salesCount: number,
  impressions: number,
  clicks: number,
  cpcCents: number,
  ctrPercent: number,
): Promise<number> {
  switch (metric) {
    case "spend":
      return spendCents / 100;
    case "sales":
      return salesCount;
    case "cpa":
      return salesCount > 0 ? spendCents / 100 / salesCount : 0;
    case "roas":
      return spendCents > 0 ? salesCents / spendCents : 0;
    case "roi":
      return spendCents > 0 ? (salesCents - spendCents) / spendCents : 0;
    case "profit":
      return (salesCents - spendCents) / 100;
    case "margin":
      return salesCents > 0 ? (salesCents - spendCents) / salesCents : 0;
    case "cpc":
      return cpcCents / 100;
    case "ctr":
      return ctrPercent;
    case "impressions":
      return impressions;
    case "hour": {
      // Hora atual no fuso de Brasília (UTC-3, 0-23) — pra dayparting.
      const b = new Date(Date.now() - 3 * 60 * 60 * 1000);
      return b.getUTCHours();
    }
  }
}

/** Plataformas com dispatch de ação (pause/activate/budget) implementado.
 *  Google/Kwai sincronizam métricas mas ainda não têm provider de escrita —
 *  ficam fora de escopo pra não "rodar e falhar em silêncio" no dispatch. */
const DISPATCHABLE_PLATFORMS = ["meta", "tiktok"];

export async function runRule(
  ruleId: string,
  dryRun = false,
): Promise<{
  ok: boolean;
  matchedCount: number;
  actionTaken: string;
  error?: string;
}> {
  const rule = await prisma.adRule.findUnique({
    where: { id: ruleId },
    include: { user: { select: { id: true } } },
  });
  if (!rule || !rule.active) {
    return { ok: false, matchedCount: 0, actionTaken: "skipped", error: "inactive" };
  }

  const scope = rule.scope as unknown as Scope;
  const conditions = rule.conditions as unknown as Condition[];
  const action = rule.action as unknown as Action;
  const applyTo = scope.applyTo ?? "campaigns";
  const onlyActive = (scope.filter ?? "active") === "active";

  // Pega ad accounts no escopo. Sempre limita às plataformas com dispatch
  // implementado e ao próprio user; o id-filter entra só quando o rule
  // especifica accountIds (antes esse ramo não filtrava platform, deixando
  // contas TikTok/Google/Kwai entrarem no escopo e falharem no dispatch).
  const adAccountsWhere = {
    userId: rule.userId,
    status: "active",
    platform: { in: DISPATCHABLE_PLATFORMS },
    ...(scope.accountIds && scope.accountIds.length > 0
      ? { id: { in: scope.accountIds } }
      : {}),
  };
  const adAccounts = await prisma.adAccount.findMany({ where: adAccountsWhere });
  if (adAccounts.length === 0) {
    await logExecution(ruleId, 0, "no_accounts", { reason: "Sem contas ativas no escopo." });
    return { ok: true, matchedCount: 0, actionTaken: "no_accounts" };
  }

  const sinceDate = windowToSince(rule.window);
  const accountIds = adAccounts.map((a) => a.id);
  // adAccountId -> credenciais + plataforma, pra escolher o provider certo no
  // dispatch. accountId = act_<id> no Meta / advertiser_id no TikTok.
  const accById = new Map<
    string,
    { token: string; platform: string; accountId: string }
  >();
  for (const a of adAccounts) {
    try {
      accById.set(a.id, {
        token: decryptString(a.accessToken),
        platform: a.platform,
        accountId: a.accountId,
      });
    } catch {
      // token inválido/corrompido — conta fica fora do dispatch
    }
  }

  // Vendas do período (pra cálculo de ROAS/CPA/profit)
  const txs = await prisma.transaction.findMany({
    where: {
      userId: rule.userId,
      status: "PAID",
      paidAt: { gte: sinceDate },
    },
    select: {
      amountCents: true,
      utmCampaign: true,
      utmMedium: true,
      utmContent: true,
    },
  });
  const salesByExternalId = new Map<string, { count: number; cents: number }>();
  function add(map: Map<string, { count: number; cents: number }>, key: string, c: number) {
    const cur = map.get(key) ?? { count: 0, cents: 0 };
    cur.count++;
    cur.cents += c;
    map.set(key, cur);
  }
  // NOTA: a atribuição de vendas é feita DEPOIS de carregar os objetos (logo
  // abaixo), pra casar o UTM por id OU por nome (qualquer formato).

  // Carrega objetos no DB
  let objects: Array<{
    id: string;
    externalId: string;
    name: string;
    status: string;
    spendCentsDay: number;
    impressions: number;
    clicks: number;
    cpcCents: number | null;
    ctrPercent: number | null;
    adAccountId: string;
  }> = [];

  if (applyTo === "campaigns") {
    const camps = await prisma.adCampaign.findMany({
      where: {
        adAccountId: { in: accountIds },
        ...(onlyActive ? { status: "ACTIVE" } : {}),
        ...(scope.nameFilter
          ? { name: { contains: scope.nameFilter, mode: "insensitive" } }
          : {}),
      },
    });
    objects = camps.map((c) => ({
      id: c.id,
      externalId: c.externalId,
      name: c.name,
      status: c.status,
      spendCentsDay: c.spendCentsDay,
      impressions: c.impressions,
      clicks: c.clicks,
      cpcCents: c.cpcCents,
      ctrPercent: c.ctrPercent,
      adAccountId: c.adAccountId,
    }));
  } else if (applyTo === "adsets") {
    const sets = await prisma.adAdset.findMany({
      where: {
        campaign: { adAccountId: { in: accountIds } },
        ...(onlyActive ? { status: "ACTIVE" } : {}),
        ...(scope.nameFilter
          ? { name: { contains: scope.nameFilter, mode: "insensitive" } }
          : {}),
      },
      include: { campaign: { select: { adAccountId: true } } },
    });
    objects = sets.map((s) => ({
      id: s.id,
      externalId: s.externalId,
      name: s.name,
      status: s.status,
      spendCentsDay: s.spendCentsDay,
      impressions: s.impressions,
      clicks: s.clicks,
      cpcCents: null,
      ctrPercent: null,
      adAccountId: s.campaign.adAccountId,
    }));
  } else {
    const ads = await prisma.ad.findMany({
      where: {
        adset: { campaign: { adAccountId: { in: accountIds } } },
        ...(onlyActive ? { status: "ACTIVE" } : {}),
        ...(scope.nameFilter
          ? { name: { contains: scope.nameFilter, mode: "insensitive" } }
          : {}),
      },
      include: { adset: { include: { campaign: { select: { adAccountId: true } } } } },
    });
    objects = ads.map((a) => ({
      id: a.id,
      externalId: a.externalId,
      name: a.name,
      status: a.status,
      spendCentsDay: a.spendCentsDay,
      impressions: a.impressions,
      clicks: a.clicks,
      cpcCents: null,
      ctrPercent: null,
      adAccountId: a.adset.campaign.adAccountId,
    }));
  }

  // Atribui as vendas aos objetos por id OU nome (cobre "nome|id", nome puro
  // do TikTok, ou só o id) — antes só casava "nome|id" e ignorava o nome.
  {
    const extIds = new Set(objects.map((o) => o.externalId));
    const byName = new Map<string, string>();
    for (const o of objects) {
      const nk = normUtm(o.name);
      if (nk && !byName.has(nk)) byName.set(nk, o.externalId);
    }
    for (const t of txs) {
      const utm =
        applyTo === "campaigns"
          ? t.utmCampaign
          : applyTo === "adsets"
            ? t.utmMedium
            : t.utmContent;
      const ext = resolveUtmToExternalId(utm, extIds, byName);
      if (ext) add(salesByExternalId, ext, t.amountCents);
    }
  }

  const matchedObjects: typeof objects = [];
  for (const obj of objects) {
    const sales = salesByExternalId.get(obj.externalId) ?? { count: 0, cents: 0 };
    let allMatch = true;
    for (const cond of conditions) {
      const val = await getMetricValue(
        cond.metric,
        obj.spendCentsDay,
        sales.cents,
        sales.count,
        obj.impressions,
        obj.clicks,
        obj.cpcCents ?? 0,
        obj.ctrPercent ?? 0,
      );
      if (!evalCondition(val, cond)) {
        allMatch = false;
        break;
      }
    }
    if (allMatch) matchedObjects.push(obj);
  }

  // 🧪 SIMULAÇÃO (dry-run): só conta quem bateria a condição, sem aplicar
  // nada na plataforma nem logar/atualizar lastRunAt.
  if (dryRun) {
    return {
      ok: true,
      matchedCount: matchedObjects.length,
      actionTaken: "dry_run",
    };
  }

  // Aplica a ação
  let actionTaken: string = action.type;
  const details: Record<string, unknown> = {
    matched: matchedObjects.map((o) => ({ id: o.externalId, name: o.name })),
  };

  if (matchedObjects.length === 0) {
    actionTaken = "no_matches";
  } else if (action.type === "notify") {
    // Stub: notification table seria mais robusta. Por enquanto só loga.
    details.notified = true;
  } else {
    for (const obj of matchedObjects) {
      const acc = accById.get(obj.adAccountId);
      if (!acc) continue;
      const { token, platform, accountId: advertiserId } = acc;
      try {
        if (action.type === "pause" || action.type === "activate") {
          const status = action.type === "pause" ? "PAUSED" : "ACTIVE";
          if (platform === "tiktok") {
            // TikTok exige advertiser_id + o "kind" do objeto (endpoint
            // distinto por nível). adsets -> adgroup na nomenclatura do TikTok.
            const kind =
              applyTo === "campaigns"
                ? "campaign"
                : applyTo === "adsets"
                  ? "adgroup"
                  : "ad";
            await tiktokUpdateObjectStatus(
              token,
              advertiserId,
              kind,
              obj.externalId,
              status,
            );
          } else {
            await updateObjectStatus(token, obj.externalId, status);
          }
        } else if (
          action.type === "budget_increase" ||
          action.type === "budget_decrease"
        ) {
          const pct = action.value ?? 10;
          // SCOPED (auditoria jun/2026): filtra pelas contas DESTE rule. Antes
          // buscava só por externalId — se dois tenants sincronizassem a mesma
          // ad account (externalId é o ID global da plataforma), o findFirst
          // podia ler o orçamento da campanha de OUTRO tenant e calcular um
          // newBudget errado pra aplicar na campanha do user.
          const camp = await prisma.adCampaign.findFirst({
            where: {
              externalId: obj.externalId,
              adAccountId: { in: accountIds },
            },
            select: { dailyBudgetCents: true },
          });
          const curBudget = camp?.dailyBudgetCents ?? 0;
          if (curBudget > 0) {
            const newBudget =
              action.type === "budget_increase"
                ? Math.round(curBudget * (1 + pct / 100))
                : Math.round(curBudget * (1 - pct / 100));
            // dailyBudgetCents é sempre em centavos (TikTok também: o sync grava
            // budget*100); o provider do TikTok reconverte pra unidade da moeda.
            if (platform === "tiktok") {
              await tiktokUpdateBudget(
                token,
                advertiserId,
                obj.externalId,
                newBudget,
              );
            } else {
              await updateBudget(token, obj.externalId, newBudget);
            }
          }
        }
      } catch (e) {
        details[`error_${obj.externalId}`] =
          e instanceof Error ? e.message : "unknown";
      }
    }
  }

  await logExecution(ruleId, matchedObjects.length, actionTaken, details);
  await prisma.adRule.update({
    where: { id: ruleId },
    data: { lastRunAt: new Date() },
  });

  // 🔔 Avisa o seller por push quando a regra de fato AGIU (ou alertou).
  if (matchedObjects.length > 0) {
    const verb =
      action.type === "pause"
        ? "pausou"
        : action.type === "activate"
          ? "ativou"
          : action.type === "budget_increase"
            ? "subiu o budget de"
            : action.type === "budget_decrease"
              ? "baixou o budget de"
              : "encontrou";
    const noun =
      applyTo === "campaigns"
        ? "campanha(s)"
        : applyTo === "adsets"
          ? "conjunto(s)"
          : "anúncio(s)";
    await sendPushToUser(rule.userId, {
      title: `⚙️ Regra: ${rule.name}`,
      body: `${verb} ${matchedObjects.length} ${noun}.`,
      url: "/dashboard/tracking/regras",
      kind: "generic",
    }).catch(() => {});
  }

  return { ok: true, matchedCount: matchedObjects.length, actionTaken };
}

function windowToSince(w: string): Date {
  const now = Date.now();
  switch (w) {
    case "30m":
      return new Date(now - 30 * 60 * 1000);
    case "1h":
      return new Date(now - 60 * 60 * 1000);
    case "7d":
      return new Date(now - 7 * 86400000);
    case "1d":
    default:
      return new Date(now - 86400000);
  }
}

async function logExecution(
  ruleId: string,
  matchedCount: number,
  actionTaken: string,
  details: Record<string, unknown>,
) {
  await prisma.adRuleExecution.create({
    data: {
      ruleId,
      matchedCount,
      actionTaken,
      details: details as never,
    },
  });
}

/** Roda TODAS as regras ativas — chamado pelo cron. */
export async function runAllActiveRules(): Promise<{
  ranCount: number;
  ranIds: string[];
}> {
  const now = Date.now();
  const rules = await prisma.adRule.findMany({
    where: { active: true },
    select: { id: true, frequency: true, lastRunAt: true },
  });
  const ranIds: string[] = [];
  for (const r of rules) {
    const minInterval = freqToMs(r.frequency);
    if (
      r.lastRunAt &&
      now - new Date(r.lastRunAt).getTime() < minInterval
    ) {
      continue;
    }
    try {
      await runRule(r.id);
      ranIds.push(r.id);
    } catch (e) {
      console.error("[rule-engine] erro em rule", r.id, e);
    }
  }
  return { ranCount: ranIds.length, ranIds };
}

function freqToMs(f: string): number {
  switch (f) {
    case "15m":
      return 15 * 60 * 1000;
    case "1h":
      return 60 * 60 * 1000;
    case "6h":
      return 6 * 60 * 60 * 1000;
    case "24h":
      return 24 * 60 * 60 * 1000;
    default:
      return 60 * 60 * 1000;
  }
}
