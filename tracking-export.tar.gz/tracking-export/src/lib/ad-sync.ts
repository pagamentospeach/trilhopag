/**
 * Sync de campanhas/conjuntos/anúncios de uma ad account.
 * Suporta Meta e TikTok — dispatch via campo `platform` na AdAccount.
 */
import { prisma } from "./prisma";
import { decryptString } from "./crypto";
import {
  listCampaigns,
  listAdsets,
  listAds,
  getInsightsByLevel as metaInsightsByLevel,
  listAdsPixels,
  updateObjectStatus as metaUpdateStatus,
  updateBudget as metaUpdateBudget,
  updateObjectName as metaUpdateName,
  getAccountCurrency as metaGetCurrency,
} from "./providers/meta-ads";
import {
  listCampaigns as ttListCampaigns,
  listAdgroups as ttListAdgroups,
  listAds as ttListAds,
  getInsightsByLevel as ttInsightsByLevel,
  listPixels as ttListPixels,
  updateObjectStatus as ttUpdateStatus,
  updateBudget as ttUpdateBudget,
  updateAdgroupBudget as ttUpdateAdgroupBudget,
  updateCampaignName as ttUpdateCampaignName,
  updateAdgroupName as ttUpdateAdgroupName,
  updateAdName as ttUpdateAdName,
  getAdvertiserCurrency as ttGetCurrency,
  getAdRejectReasons as ttGetAdRejectReasons,
  isRejectedStatus as ttIsRejected,
} from "./providers/tiktok-ads";

function parseBudgetToCents(raw: string | undefined): number | null {
  if (!raw) return null;
  // Meta retorna em unidade da moeda em cents (string), ex: "5000" = R$ 50,00
  const n = Number(raw);
  return Number.isFinite(n) ? n : null;
}

function parseSpendToCents(spend: string | undefined): number {
  if (!spend) return 0;
  // Meta retorna em unidade da moeda (decimal), ex: "12.34" = R$ 12,34 → 1234 cents
  const n = Number(spend);
  return Number.isFinite(n) ? Math.round(n * 100) : 0;
}

/** Sincroniza uma única ad account (com tudo embaixo dela). Despacha por plataforma. */
export async function syncAdAccount(adAccountDbId: string): Promise<{
  ok: boolean;
  campaigns: number;
  adsets: number;
  ads: number;
  error?: string;
}> {
  const acc = await prisma.adAccount.findUnique({
    where: { id: adAccountDbId },
  });
  if (!acc) return { ok: false, campaigns: 0, adsets: 0, ads: 0, error: "not_found" };

  if (acc.platform === "tiktok") {
    return syncTiktokAccount(adAccountDbId);
  }
  return syncMetaAccount(adAccountDbId);
}

async function syncMetaAccount(adAccountDbId: string): Promise<{
  ok: boolean;
  campaigns: number;
  adsets: number;
  ads: number;
  error?: string;
}> {
  const acc = await prisma.adAccount.findUnique({
    where: { id: adAccountDbId },
  });
  if (!acc) return { ok: false, campaigns: 0, adsets: 0, ads: 0, error: "not_found" };

  try {
    const token = decryptString(acc.accessToken);

    // Moeda da conta (1x, só se ainda não soubermos) — pra formatar o gasto.
    let currency = acc.currency;
    if (!currency) {
      try {
        currency = await metaGetCurrency(token, acc.accountId);
      } catch {
        /* best-effort */
      }
    }

    // INSIGHTS EM LOTE — 1 chamada por nível (campaign/adset/ad) cobre TODOS
    // os objetos da conta. Antes era 1 chamada POR objeto → estourava o rate
    // limit da Meta (code 17) e o gasto vinha zerado. Best-effort: se um nível
    // falhar, o mapa fica vazio e o gasto daquele nível fica 0 (sem abortar).
    const [campInsights, adsetInsightsMap, adInsightsMap] = await Promise.all([
      metaInsightsByLevel(token, acc.accountId, "campaign", "today").catch(
        () => new Map(),
      ),
      metaInsightsByLevel(token, acc.accountId, "adset", "today").catch(
        () => new Map(),
      ),
      metaInsightsByLevel(token, acc.accountId, "ad", "today").catch(
        () => new Map(),
      ),
    ]);

    // 1. CAMPANHAS
    const metaCampaigns = await listCampaigns(token, acc.accountId);
    let adsetsCount = 0;
    let adsCount = 0;

    for (const mc of metaCampaigns) {
      const insights = campInsights.get(mc.id) ?? null;
      const campaign = await prisma.adCampaign.upsert({
        where: {
          adAccountId_externalId: {
            adAccountId: acc.id,
            externalId: mc.id,
          },
        },
        create: {
          adAccountId: acc.id,
          externalId: mc.id,
          name: mc.name,
          status: mc.effective_status ?? mc.status ?? "UNKNOWN",
          objective: mc.objective ?? null,
          dailyBudgetCents: parseBudgetToCents(mc.daily_budget),
          lifetimeBudgetCents: parseBudgetToCents(mc.lifetime_budget),
          spendCentsDay: parseSpendToCents(insights?.spend),
          impressions: Number(insights?.impressions ?? 0),
          clicks: Number(insights?.clicks ?? 0),
          ctrPercent: insights?.ctr ? Number(insights.ctr) : null,
          cpcCents: insights?.cpc ? Math.round(Number(insights.cpc) * 100) : null,
          cpmCents: insights?.cpm ? Math.round(Number(insights.cpm) * 100) : null,
          externalUpdatedAt: mc.updated_time ? new Date(mc.updated_time) : null,
          lastSyncAt: new Date(),
        },
        update: {
          name: mc.name,
          status: mc.effective_status ?? mc.status ?? "UNKNOWN",
          objective: mc.objective ?? null,
          dailyBudgetCents: parseBudgetToCents(mc.daily_budget),
          lifetimeBudgetCents: parseBudgetToCents(mc.lifetime_budget),
          spendCentsDay: parseSpendToCents(insights?.spend),
          impressions: Number(insights?.impressions ?? 0),
          clicks: Number(insights?.clicks ?? 0),
          ctrPercent: insights?.ctr ? Number(insights.ctr) : null,
          cpcCents: insights?.cpc ? Math.round(Number(insights.cpc) * 100) : null,
          cpmCents: insights?.cpm ? Math.round(Number(insights.cpm) * 100) : null,
          externalUpdatedAt: mc.updated_time ? new Date(mc.updated_time) : null,
          lastSyncAt: new Date(),
        },
      });

      // 2. ADSETS — fetch insights e processa em paralelo (chunks de 8)
      const metaAdsets = await listAdsets(token, mc.id);
      const adsetResults = await Promise.all(
        metaAdsets.map(async (ms) => {
          const adsetInsights = adsetInsightsMap.get(ms.id) ?? null;
          const adset = await prisma.adAdset.upsert({
            where: {
              campaignId_externalId: {
                campaignId: campaign.id,
                externalId: ms.id,
              },
            },
            create: {
              campaignId: campaign.id,
              externalId: ms.id,
              name: ms.name,
              status: ms.status,
              dailyBudgetCents: parseBudgetToCents(ms.daily_budget),
              spendCentsDay: parseSpendToCents(adsetInsights?.spend),
              impressions: Number(adsetInsights?.impressions ?? 0),
              clicks: Number(adsetInsights?.clicks ?? 0),
              lastSyncAt: new Date(),
            },
            update: {
              name: ms.name,
              status: ms.status,
              dailyBudgetCents: parseBudgetToCents(ms.daily_budget),
              spendCentsDay: parseSpendToCents(adsetInsights?.spend),
              impressions: Number(adsetInsights?.impressions ?? 0),
              clicks: Number(adsetInsights?.clicks ?? 0),
              lastSyncAt: new Date(),
            },
          });

          // 3. ADS desse adset — fetch em paralelo
          const metaAds = await listAds(token, ms.id);
          await Promise.all(
            metaAds.map(async (ma) => {
              const adInsights = adInsightsMap.get(ma.id) ?? null;
              await prisma.ad.upsert({
                where: {
                  adsetId_externalId: {
                    adsetId: adset.id,
                    externalId: ma.id,
                  },
                },
                create: {
                  adsetId: adset.id,
                  externalId: ma.id,
                  name: ma.name,
                  status: ma.status,
                  spendCentsDay: parseSpendToCents(adInsights?.spend),
                  impressions: Number(adInsights?.impressions ?? 0),
                  clicks: Number(adInsights?.clicks ?? 0),
                  lastSyncAt: new Date(),
                },
                update: {
                  name: ma.name,
                  status: ma.status,
                  spendCentsDay: parseSpendToCents(adInsights?.spend),
                  impressions: Number(adInsights?.impressions ?? 0),
                  clicks: Number(adInsights?.clicks ?? 0),
                  lastSyncAt: new Date(),
                },
              });
            }),
          );
          return metaAds.length;
        }),
      );
      adsetsCount += metaAdsets.length;
      adsCount += adsetResults.reduce((s, n) => s + n, 0);
    }

    // PIXELS — fetch pra montar o picker do "Subir Campanhas em Massa".
    // Falhas não são fatais — guarda só os pixels que conseguiu listar.
    let pixels: Array<{ id: string; name: string }> = [];
    try {
      pixels = await listAdsPixels(token, acc.accountId);
    } catch (e) {
      console.warn("[ad-sync meta] listAdsPixels error:", e);
    }

    await prisma.adAccount.update({
      where: { id: acc.id },
      data: {
        lastSyncAt: new Date(),
        syncError: null,
        pixels: pixels as never,
        ...(currency ? { currency } : {}),
      },
    });

    return {
      ok: true,
      campaigns: metaCampaigns.length,
      adsets: adsetsCount,
      ads: adsCount,
    };
  } catch (e) {
    const msg = e instanceof Error ? e.message : "unknown";
    await prisma.adAccount.update({
      where: { id: acc.id },
      data: { syncError: msg, lastSyncAt: new Date() },
    });
    return { ok: false, campaigns: 0, adsets: 0, ads: 0, error: msg };
  }
}

/** Sincroniza uma ad account do TikTok. */
async function syncTiktokAccount(adAccountDbId: string): Promise<{
  ok: boolean;
  campaigns: number;
  adsets: number;
  ads: number;
  error?: string;
}> {
  const acc = await prisma.adAccount.findUnique({
    where: { id: adAccountDbId },
  });
  if (!acc) return { ok: false, campaigns: 0, adsets: 0, ads: 0, error: "not_found" };

  try {
    const token = decryptString(acc.accessToken);
    const advertiserId = acc.accountId; // No TikTok, accountId = advertiser_id

    // Moeda do advertiser (1x, só se ainda não soubermos).
    let currency = acc.currency;
    if (!currency) {
      try {
        currency = await ttGetCurrency(token, advertiserId);
      } catch {
        /* best-effort */
      }
    }

    // INSIGHTS EM LOTE — 1 report por data_level cobre TODOS os objetos do
    // advertiser. Antes era 1 report POR objeto → com o QPS baixo do TikTok o
    // gasto vinha zerado/lento. Best-effort por nível (não aborta o sync).
    const [ttCampMap, ttAdgroupMap, ttAdMap] = await Promise.all([
      ttInsightsByLevel(token, advertiserId, "AUCTION_CAMPAIGN", "campaign_id", "TODAY").catch(
        () => new Map(),
      ),
      ttInsightsByLevel(token, advertiserId, "AUCTION_ADGROUP", "adgroup_id", "TODAY").catch(
        () => new Map(),
      ),
      ttInsightsByLevel(token, advertiserId, "AUCTION_AD", "ad_id", "TODAY").catch(
        () => new Map(),
      ),
    ]);

    const ttCampaigns = await ttListCampaigns(token, advertiserId);
    let adsetsCount = 0;
    let adsCount = 0;

    for (const tc of ttCampaigns) {
      const insights = ttCampMap.get(tc.campaign_id) ?? null;
      const budgetCents =
        tc.budget != null ? Math.round(tc.budget * 100) : null;
      const status = tc.operation_status ?? tc.status ?? "UNKNOWN";

      const campaign = await prisma.adCampaign.upsert({
        where: {
          adAccountId_externalId: {
            adAccountId: acc.id,
            externalId: tc.campaign_id,
          },
        },
        create: {
          adAccountId: acc.id,
          externalId: tc.campaign_id,
          name: tc.campaign_name,
          status,
          objective: tc.objective_type ?? null,
          dailyBudgetCents: tc.budget_mode === "BUDGET_MODE_DAY" ? budgetCents : null,
          lifetimeBudgetCents:
            tc.budget_mode === "BUDGET_MODE_TOTAL" ? budgetCents : null,
          spendCentsDay: Math.round((insights?.spend ?? 0) * 100),
          impressions: insights?.impressions ?? 0,
          clicks: insights?.clicks ?? 0,
          ctrPercent: insights?.ctr ?? null,
          cpcCents: insights?.cpc ? Math.round(insights.cpc * 100) : null,
          cpmCents: insights?.cpm ? Math.round(insights.cpm * 100) : null,
          externalUpdatedAt: tc.modify_time ? new Date(tc.modify_time) : null,
          lastSyncAt: new Date(),
        },
        update: {
          name: tc.campaign_name,
          status,
          objective: tc.objective_type ?? null,
          dailyBudgetCents: tc.budget_mode === "BUDGET_MODE_DAY" ? budgetCents : null,
          lifetimeBudgetCents:
            tc.budget_mode === "BUDGET_MODE_TOTAL" ? budgetCents : null,
          spendCentsDay: Math.round((insights?.spend ?? 0) * 100),
          impressions: insights?.impressions ?? 0,
          clicks: insights?.clicks ?? 0,
          ctrPercent: insights?.ctr ?? null,
          cpcCents: insights?.cpc ? Math.round(insights.cpc * 100) : null,
          cpmCents: insights?.cpm ? Math.round(insights.cpm * 100) : null,
          externalUpdatedAt: tc.modify_time ? new Date(tc.modify_time) : null,
          lastSyncAt: new Date(),
        },
      });

      // Adgroups (= adsets no Meta)
      const ttAdgroups = await ttListAdgroups(token, advertiserId, tc.campaign_id);
      const adgroupResults = await Promise.all(
        ttAdgroups.map(async (ag) => {
          const agInsights = ttAdgroupMap.get(ag.adgroup_id) ?? null;
          const adset = await prisma.adAdset.upsert({
            where: {
              campaignId_externalId: {
                campaignId: campaign.id,
                externalId: ag.adgroup_id,
              },
            },
            create: {
              campaignId: campaign.id,
              externalId: ag.adgroup_id,
              name: ag.adgroup_name,
              status: ag.operation_status ?? ag.status ?? "UNKNOWN",
              dailyBudgetCents: ag.budget != null ? Math.round(ag.budget * 100) : null,
              spendCentsDay: Math.round((agInsights?.spend ?? 0) * 100),
              impressions: agInsights?.impressions ?? 0,
              clicks: agInsights?.clicks ?? 0,
              lastSyncAt: new Date(),
            },
            update: {
              name: ag.adgroup_name,
              status: ag.operation_status ?? ag.status ?? "UNKNOWN",
              dailyBudgetCents: ag.budget != null ? Math.round(ag.budget * 100) : null,
              spendCentsDay: Math.round((agInsights?.spend ?? 0) * 100),
              impressions: agInsights?.impressions ?? 0,
              clicks: agInsights?.clicks ?? 0,
              lastSyncAt: new Date(),
            },
          });

          const ttAds = await ttListAds(token, advertiserId, ag.adgroup_id);

          // Motivos de reprovação (batch, best-effort) pros ads reprovados.
          const rejectedIds = ttAds
            .filter((a) => ttIsRejected(a.secondary_status))
            .map((a) => a.ad_id);
          const reasons =
            rejectedIds.length > 0
              ? await ttGetAdRejectReasons(token, advertiserId, rejectedIds)
              : {};

          await Promise.all(
            ttAds.map(async (ad) => {
              const adInsights = ttAdMap.get(ad.ad_id) ?? null;
              const rejectReason = ttIsRejected(ad.secondary_status)
                ? reasons[ad.ad_id] ?? "Reprovado pelo TikTok (veja o motivo no Ads Manager)"
                : null;
              await prisma.ad.upsert({
                where: {
                  adsetId_externalId: {
                    adsetId: adset.id,
                    externalId: ad.ad_id,
                  },
                },
                create: {
                  adsetId: adset.id,
                  externalId: ad.ad_id,
                  name: ad.ad_name,
                  status: ad.operation_status ?? ad.status ?? "UNKNOWN",
                  secondaryStatus: ad.secondary_status ?? null,
                  rejectReason,
                  spendCentsDay: Math.round((adInsights?.spend ?? 0) * 100),
                  impressions: adInsights?.impressions ?? 0,
                  clicks: adInsights?.clicks ?? 0,
                  lastSyncAt: new Date(),
                },
                update: {
                  name: ad.ad_name,
                  status: ad.operation_status ?? ad.status ?? "UNKNOWN",
                  secondaryStatus: ad.secondary_status ?? null,
                  rejectReason,
                  spendCentsDay: Math.round((adInsights?.spend ?? 0) * 100),
                  impressions: adInsights?.impressions ?? 0,
                  clicks: adInsights?.clicks ?? 0,
                  lastSyncAt: new Date(),
                },
              });
            }),
          );
          return ttAds.length;
        }),
      );
      adsetsCount += ttAdgroups.length;
      adsCount += adgroupResults.reduce((s, n) => s + n, 0);
    }

    // PIXELS — fetch pra montar o picker do "Subir Campanhas em Massa".
    let pixels: Array<{ id: string; name: string }> = [];
    try {
      pixels = await ttListPixels(token, acc.accountId);
    } catch (e) {
      console.warn("[ad-sync tiktok] listPixels error:", e);
    }

    await prisma.adAccount.update({
      where: { id: acc.id },
      data: {
        lastSyncAt: new Date(),
        syncError: null,
        pixels: pixels as never,
        ...(currency ? { currency } : {}),
      },
    });

    return {
      ok: true,
      campaigns: ttCampaigns.length,
      adsets: adsetsCount,
      ads: adsCount,
    };
  } catch (e) {
    const msg = e instanceof Error ? e.message : "unknown";
    await prisma.adAccount.update({
      where: { id: acc.id },
      data: { syncError: msg, lastSyncAt: new Date() },
    });
    return { ok: false, campaigns: 0, adsets: 0, ads: 0, error: msg };
  }
}

/** Atualiza o status de um objeto (campaign/adset/ad) na plataforma + DB local. */
export async function setObjectStatus(
  adAccountDbId: string,
  objectKind: "campaign" | "adset" | "ad",
  externalId: string,
  status: "ACTIVE" | "PAUSED",
): Promise<{ ok: boolean; error?: string }> {
  const acc = await prisma.adAccount.findUnique({
    where: { id: adAccountDbId },
  });
  if (!acc) return { ok: false, error: "ad_account_not_found" };
  try {
    const token = decryptString(acc.accessToken);
    if (acc.platform === "tiktok") {
      const kind = objectKind === "adset" ? "adgroup" : objectKind;
      await ttUpdateStatus(token, acc.accountId, kind as "campaign" | "adgroup" | "ad", externalId, status);
    } else {
      await metaUpdateStatus(token, externalId, status);
    }
    // Atualiza DB local imediatamente (otimista)
    if (objectKind === "campaign") {
      await prisma.adCampaign.updateMany({
        where: { adAccountId: acc.id, externalId },
        data: { status },
      });
    } else if (objectKind === "adset") {
      await prisma.adAdset.updateMany({
        where: { externalId, campaign: { adAccountId: acc.id } },
        data: { status },
      });
    } else {
      await prisma.ad.updateMany({
        where: {
          externalId,
          adset: { campaign: { adAccountId: acc.id } },
        },
        data: { status },
      });
    }
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "unknown" };
  }
}

/** Ajusta orçamento daily de uma campanha (Meta ou TikTok). */
export async function setObjectBudget(
  adAccountDbId: string,
  externalId: string,
  dailyBudgetCents: number,
): Promise<{ ok: boolean; error?: string }> {
  const acc = await prisma.adAccount.findUnique({
    where: { id: adAccountDbId },
  });
  if (!acc) return { ok: false, error: "ad_account_not_found" };
  try {
    const token = decryptString(acc.accessToken);
    if (acc.platform === "tiktok") {
      await ttUpdateBudget(token, acc.accountId, externalId, dailyBudgetCents);
    } else {
      await metaUpdateBudget(token, externalId, dailyBudgetCents);
    }
    await prisma.adCampaign.updateMany({
      where: { adAccountId: acc.id, externalId },
      data: { dailyBudgetCents },
    });
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "unknown" };
  }
}

/** Renomeia uma campanha na plataforma + DB local. Meta ou TikTok. */
export async function setCampaignName(
  adAccountDbId: string,
  externalId: string,
  name: string,
): Promise<{ ok: boolean; error?: string }> {
  const acc = await prisma.adAccount.findUnique({
    where: { id: adAccountDbId },
  });
  if (!acc) return { ok: false, error: "ad_account_not_found" };
  const clean = name.trim();
  if (!clean) return { ok: false, error: "empty_name" };
  try {
    const token = decryptString(acc.accessToken);
    if (acc.platform === "tiktok") {
      await ttUpdateCampaignName(token, acc.accountId, externalId, clean);
    } else {
      await metaUpdateName(token, externalId, clean);
    }
    await prisma.adCampaign.updateMany({
      where: { adAccountId: acc.id, externalId },
      data: { name: clean },
    });
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "unknown" };
  }
}

/** Renomeia um CONJUNTO/adgroup na plataforma + DB local. */
export async function setAdsetName(
  adAccountDbId: string,
  externalId: string,
  name: string,
): Promise<{ ok: boolean; error?: string }> {
  const acc = await prisma.adAccount.findUnique({
    where: { id: adAccountDbId },
  });
  if (!acc) return { ok: false, error: "ad_account_not_found" };
  const clean = name.trim();
  if (!clean) return { ok: false, error: "empty_name" };
  try {
    const token = decryptString(acc.accessToken);
    if (acc.platform === "tiktok") {
      await ttUpdateAdgroupName(token, acc.accountId, externalId, clean);
    } else {
      await metaUpdateName(token, externalId, clean);
    }
    await prisma.adAdset.updateMany({
      where: { externalId, campaign: { adAccountId: acc.id } },
      data: { name: clean },
    });
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "unknown" };
  }
}

/** Renomeia um ANÚNCIO/ad na plataforma + DB local. */
export async function setAdName(
  adAccountDbId: string,
  externalId: string,
  name: string,
): Promise<{ ok: boolean; error?: string }> {
  const acc = await prisma.adAccount.findUnique({
    where: { id: adAccountDbId },
  });
  if (!acc) return { ok: false, error: "ad_account_not_found" };
  const clean = name.trim();
  if (!clean) return { ok: false, error: "empty_name" };
  try {
    const token = decryptString(acc.accessToken);
    if (acc.platform === "tiktok") {
      await ttUpdateAdName(token, acc.accountId, externalId, clean);
    } else {
      await metaUpdateName(token, externalId, clean);
    }
    await prisma.ad.updateMany({
      where: { externalId, adset: { campaign: { adAccountId: acc.id } } },
      data: { name: clean },
    });
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "unknown" };
  }
}

/** Ajusta orçamento daily de um CONJUNTO/adgroup (ABO). Meta ou TikTok. */
export async function setAdsetBudget(
  adAccountDbId: string,
  externalId: string,
  dailyBudgetCents: number,
): Promise<{ ok: boolean; error?: string }> {
  const acc = await prisma.adAccount.findUnique({
    where: { id: adAccountDbId },
  });
  if (!acc) return { ok: false, error: "ad_account_not_found" };
  try {
    const token = decryptString(acc.accessToken);
    if (acc.platform === "tiktok") {
      await ttUpdateAdgroupBudget(token, acc.accountId, externalId, dailyBudgetCents);
    } else {
      // Meta: editar budget é POST /{id} {daily_budget} — funciona p/ adset.
      await metaUpdateBudget(token, externalId, dailyBudgetCents);
    }
    await prisma.adAdset.updateMany({
      where: { externalId, campaign: { adAccountId: acc.id } },
      data: { dailyBudgetCents },
    });
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "unknown" };
  }
}
