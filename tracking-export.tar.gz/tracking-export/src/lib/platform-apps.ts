/**
 * Credenciais do APP (Meta/TikTok) da PLATAFORMA.
 *
 * Fonte de verdade: tabela PlatformAppConfig (configurável pelo admin em
 * /admin01/apps). Fallback: env vars (META_APP e TIKTOK_APP). Assim o
 * admin gerencia tudo pela UI E não perde as creds em migração de conta
 * Vercel (que foi o que derrubou o connect do TikTok).
 *
 * Os providers (meta-ads.ts, tiktok-ads.ts) leem APENAS daqui.
 */
import { prisma } from "./prisma";
import { encryptString, decryptString } from "./crypto";

export type PlatformAppCreds = {
  appId: string;
  appSecret: string;
  configId: string | null;
  source: "db" | "env";
};

async function getFromDb(
  platform: "meta" | "tiktok",
): Promise<Omit<PlatformAppCreds, "source"> | null> {
  try {
    const row = await prisma.platformAppConfig.findUnique({
      where: { platform },
    });
    if (!row || !row.active || !row.appId || !row.appSecretEnc) return null;
    return {
      appId: row.appId,
      appSecret: decryptString(row.appSecretEnc),
      configId: row.configId,
    };
  } catch {
    // tabela ausente / decrypt falhou → cai pro env
    return null;
  }
}

/** Creds do app TikTok: DB primeiro, env fallback. Null se nada configurado. */
export async function getTiktokApp(): Promise<PlatformAppCreds | null> {
  const db = await getFromDb("tiktok");
  if (db?.appId && db.appSecret) return { ...db, source: "db" };
  const appId = process.env.TIKTOK_APP_ID;
  const appSecret = process.env.TIKTOK_APP_SECRET;
  if (appId && appSecret) return { appId, appSecret, configId: null, source: "env" };
  return null;
}

/** Creds do app Meta: DB primeiro, env fallback. */
export async function getMetaApp(): Promise<PlatformAppCreds | null> {
  const db = await getFromDb("meta");
  if (db?.appId && db.appSecret) {
    return {
      ...db,
      configId: db.configId ?? process.env.META_LOGIN_CONFIG_ID ?? null,
      source: "db",
    };
  }
  const appId = process.env.META_APP_ID;
  const appSecret = process.env.META_APP_SECRET;
  if (appId && appSecret) {
    return {
      appId,
      appSecret,
      configId: process.env.META_LOGIN_CONFIG_ID ?? null,
      source: "env",
    };
  }
  return null;
}

/** Salva/atualiza as creds de uma plataforma (admin). Secret criptografado. */
export async function savePlatformApp(
  platform: "meta" | "tiktok",
  input: { appId: string; appSecret?: string | null; configId?: string | null },
): Promise<void> {
  const appId = input.appId.trim();
  const configId = input.configId?.trim() || null;
  const existing = await prisma.platformAppConfig.findUnique({
    where: { platform },
  });
  if (existing) {
    await prisma.platformAppConfig.update({
      where: { platform },
      data: {
        appId,
        configId,
        active: true,
        // só re-encripta o secret se um novo foi enviado (UI manda vazio = manter)
        ...(input.appSecret
          ? { appSecretEnc: encryptString(input.appSecret.trim()) }
          : {}),
      },
    });
    return;
  }
  if (!input.appSecret) {
    throw new Error("App Secret é obrigatório na primeira configuração.");
  }
  await prisma.platformAppConfig.create({
    data: {
      platform,
      appId,
      appSecretEnc: encryptString(input.appSecret.trim()),
      configId,
      active: true,
    },
  });
}

/** Status mascarado pras telas do admin (nunca expõe o secret). */
export async function getPlatformAppsStatus(): Promise<
  Record<
    "meta" | "tiktok",
    {
      configured: boolean;
      source: "db" | "env" | "none";
      appId: string | null;
      configId: string | null;
      hasSecret: boolean;
    }
  >
> {
  const [meta, tiktok] = await Promise.all([getMetaApp(), getTiktokApp()]);
  const build = (c: PlatformAppCreds | null) => ({
    configured: !!c,
    source: c?.source ?? ("none" as const),
    appId: c?.appId ?? null,
    configId: c?.configId ?? null,
    hasSecret: !!c?.appSecret,
  });
  return { meta: build(meta), tiktok: build(tiktok) };
}
