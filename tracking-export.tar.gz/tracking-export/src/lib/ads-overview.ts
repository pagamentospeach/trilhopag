/**
 * Visão geral de ads pro DASHBOARD (hoje) — lê do banco já sincronizado
 * (mesma fonte da aba Campanhas), sem chamar API da plataforma. Converte o
 * gasto pra BRL (cotação ao vivo + override por conta). Alimenta a seção
 * "Tracking · Ads": ROAS por plataforma e por produto, melhor campanha,
 * alertas, projeção de fim de dia e gráfico de evolução.
 */
import { prisma } from "./prisma";
import { toBrlCents, ensureFxRates, isFxLive } from "./fx";
import { normUtm, extractUtmId } from "./utm-match";

const PAUSED_HINTS = ["PAUSED", "DISABLE", "DELETE", "ARCHIV", "INACTIVE"];
function isActiveStatus(status: string | null | undefined): boolean {
  const s = (status || "").toUpperCase();
  return !PAUSED_HINTS.some((h) => s.includes(h));
}

export type AdsOverview = {
  platforms: {
    platform: string;
    spendCents: number;
    revenueCents: number;
    roas: number | null;
  }[];
  totalSpendCents: number;
  totalRevenueCents: number;
  totalRoas: number | null;
  best: {
    name: string;
    platform: string;
    roas: number;
    adAccountDbId: string;
    externalId: string;
  } | null;
  worst: {
    name: string;
    platform: string;
    roas: number;
    spendCents: number;
    adAccountDbId: string;
    externalId: string;
  } | null;
  topCreatives: {
    name: string;
    campaign: string;
    platform: string;
    spendCents: number;
    revenueCents: number;
    roas: number | null;
  }[];
  favorites: {
    name: string;
    platform: string;
    spendCents: number;
    revenueCents: number;
    roas: number | null;
    active: boolean;
  }[];
  burningCount: number;
  series: { day: string; spendCents: number; revenueCents: number }[];
  topProducts: {
    name: string;
    revenueCents: number;
    spendCents: number;
    roas: number | null;
  }[];
  projection: {
    spendTodayCents: number;
    revenueTodayCents: number;
    fractionElapsed: number;
    projSpendCents: number;
    projRevenueCents: number;
  };
  /**
   * Comparação "hoje vs ontem" no mesmo ponto do dia (ontem é prorrateado pela
   * fração do dia já decorrida, pra ser maçã-com-maçã). null se não há ontem.
   */
  comparison: {
    spendDeltaPct: number | null;
    revenueDeltaPct: number | null;
    profitDeltaPct: number | null;
    roasDeltaPct: number | null;
  } | null;
  converted: boolean; // tem conta em moeda != BRL (gasto foi convertido)
  fxLive: boolean; // cotação veio ao vivo (não do fallback estático)
  hasData: boolean;
};

export async function getAdsOverview(userId: string): Promise<AdsOverview> {
  const todayStart = new Date();
  todayStart.setUTCHours(0, 0, 0, 0);
  const since30 = new Date(todayStart);
  since30.setUTCDate(since30.getUTCDate() - 29);

  await ensureFxRates();

  const [campaigns, favoriteCampaigns, ads, paidTx, settings, snapshots] =
    await Promise.all([
    prisma.adCampaign.findMany({
      where: {
        adAccount: {
          userId,
          platform: { in: ["meta", "tiktok"] },
          status: "active",
          enabled: true,
        },
      },
      select: {
        name: true,
        externalId: true,
        adAccountId: true,
        status: true,
        spendCentsDay: true,
        adAccount: {
          select: { platform: true, currency: true, fxRateOverride: true },
        },
      },
    }),
    // ⭐ Favoritas — independem de estar ativas/com gasto (pra "acompanhar").
    prisma.adCampaign.findMany({
      where: {
        favorite: true,
        adAccount: { userId, platform: { in: ["meta", "tiktok"] } },
      },
      select: {
        name: true,
        status: true,
        spendCentsDay: true,
        adAccount: {
          select: { platform: true, currency: true, fxRateOverride: true },
        },
      },
    }),
    prisma.ad.findMany({
      where: {
        adset: {
          campaign: {
            adAccount: {
              userId,
              platform: { in: ["meta", "tiktok"] },
              status: "active",
              enabled: true,
            },
          },
        },
      },
      select: {
        externalId: true,
        name: true,
        status: true,
        spendCentsDay: true,
        adset: {
          select: {
            campaign: {
              select: {
                name: true,
                adAccount: {
                  select: {
                    platform: true,
                    currency: true,
                    fxRateOverride: true,
                  },
                },
              },
            },
          },
        },
      },
    }),
    prisma.transaction.findMany({
      where: { userId, status: "PAID", paidAt: { gte: todayStart } },
      select: {
        amountCents: true,
        utmCampaign: true,
        utmContent: true,
        productId: true,
        product: { select: { name: true } },
      },
    }),
    prisma.userSettings.findUnique({
      where: { userId },
      select: { adBurnAlertCents: true },
    }),
    prisma.adSpendSnapshot.findMany({
      where: { userId, day: { gte: since30 } },
      orderBy: { day: "asc" },
      select: { day: true, spendCents: true, revenueCents: true },
    }),
  ]);

  // Índices de anúncio (pra atribuir receita por utm_content → criativo).
  const adByExternalId = new Map<string, (typeof ads)[number]>();
  const adByName = new Map<string, (typeof ads)[number]>();
  for (const a of ads) {
    adByExternalId.set(a.externalId, a);
    const nk = a.name.trim().toLowerCase();
    if (!adByName.has(nk)) adByName.set(nk, a);
  }
  function matchAdExternalId(utm: string | null): string | null {
    if (!utm) return null;
    const id = extractUtmId(utm);
    if (id && adByExternalId.has(id)) return id;
    const nk = normUtm(utm);
    if (adByName.has(nk)) return adByName.get(nk)!.externalId;
    return null;
  }

  // Nome canônico da campanha por externalId — pra resolver UTM "nome|id"
  // (UTMify/Meta) pro mesmo nome usado no matching (TikTok manda nome puro).
  const campNameByExt = new Map<string, string>();
  for (const c of campaigns) campNameByExt.set(c.externalId, normUtm(c.name));

  // Receita de HOJE por campanha (nome normalizado) + nº de vendas + por produto
  // + por criativo (utm_content).
  const revByName = new Map<string, number>();
  const salesByName = new Map<string, number>();
  const revByNameProduct = new Map<string, Map<string, number>>();
  const productName = new Map<string, string>();
  const revByAdExt = new Map<string, number>();
  for (const t of paidTx) {
    const adExt = matchAdExternalId(t.utmContent);
    if (adExt) revByAdExt.set(adExt, (revByAdExt.get(adExt) ?? 0) + t.amountCents);

    // "nome|id" → nome canônico da campanha; senão usa o utm normalizado.
    const cid = extractUtmId(t.utmCampaign);
    const k =
      cid && campNameByExt.has(cid)
        ? campNameByExt.get(cid)!
        : normUtm(t.utmCampaign);
    if (!k) continue;
    revByName.set(k, (revByName.get(k) ?? 0) + t.amountCents);
    salesByName.set(k, (salesByName.get(k) ?? 0) + 1);
    if (t.productId) {
      productName.set(t.productId, t.product?.name ?? "Produto");
      const pm = revByNameProduct.get(k) ?? new Map<string, number>();
      pm.set(t.productId, (pm.get(t.productId) ?? 0) + t.amountCents);
      revByNameProduct.set(k, pm);
    }
  }

  const burnThreshold = settings?.adBurnAlertCents ?? 5000;
  const byPlatform = new Map<string, { spend: number; rev: number }>();
  const spendByName = new Map<string, number>();
  let best: AdsOverview["best"] = null;
  let worst: AdsOverview["worst"] = null;
  let worstBurn = 0; // só considera quem está perdendo dinheiro (burn > 0)
  let burningCount = 0;
  let converted = false;

  for (const c of campaigns) {
    const key = c.name.trim().toLowerCase();
    const spend = toBrlCents(
      c.spendCentsDay,
      c.adAccount.currency,
      c.adAccount.fxRateOverride,
    );
    const rev = revByName.get(key) ?? 0;
    const sales = salesByName.get(key) ?? 0;
    const platform = c.adAccount.platform;
    const active = isActiveStatus(c.status);

    if (
      c.spendCentsDay > 0 &&
      c.adAccount.currency &&
      c.adAccount.currency.toUpperCase() !== "BRL"
    ) {
      converted = true;
    }

    spendByName.set(key, (spendByName.get(key) ?? 0) + spend);
    const bp = byPlatform.get(platform) ?? { spend: 0, rev: 0 };
    bp.spend += spend;
    bp.rev += rev;
    byPlatform.set(platform, bp);

    if (spend > 0 && active) {
      const roas = rev / spend;
      if (best === null || roas > best.roas) {
        best = {
          name: c.name,
          platform,
          roas,
          adAccountDbId: c.adAccountId,
          externalId: c.externalId,
        };
      }
      // Pior = a que mais queima dinheiro hoje (maior gasto - receita).
      const burn = spend - rev;
      if (burn > 0 && burn > worstBurn) {
        worstBurn = burn;
        worst = {
          name: c.name,
          platform,
          roas,
          spendCents: spend,
          adAccountDbId: c.adAccountId,
          externalId: c.externalId,
        };
      }
      if (spend >= burnThreshold && sales === 0) burningCount++;
    }
  }

  const platforms = [...byPlatform.entries()]
    .map(([platform, v]) => ({
      platform,
      spendCents: v.spend,
      revenueCents: v.rev,
      roas: v.spend > 0 ? v.rev / v.spend : null,
    }))
    .sort((a, b) => b.spendCents - a.spendCents);

  const totalSpendCents = platforms.reduce((s, p) => s + p.spendCents, 0);
  const totalRevenueCents = platforms.reduce((s, p) => s + p.revenueCents, 0);

  // ROAS por produto: aloca o gasto de cada campanha aos produtos que ela
  // vendeu, proporcional à receita de cada produto naquela campanha.
  const prodAgg = new Map<string, { rev: number; spend: number }>();
  for (const [key, perProduct] of revByNameProduct) {
    const campRev = revByName.get(key) ?? 0;
    const campSpend = spendByName.get(key) ?? 0;
    for (const [pid, rev] of perProduct) {
      const cur = prodAgg.get(pid) ?? { rev: 0, spend: 0 };
      cur.rev += rev;
      cur.spend += campRev > 0 ? campSpend * (rev / campRev) : 0;
      prodAgg.set(pid, cur);
    }
  }
  const topProducts = [...prodAgg.entries()]
    .map(([pid, v]) => ({
      name: productName.get(pid) ?? "Produto",
      revenueCents: Math.round(v.rev),
      spendCents: Math.round(v.spend),
      roas: v.spend > 0 ? v.rev / v.spend : null,
    }))
    .sort((a, b) => b.revenueCents - a.revenueCents)
    .slice(0, 5);

  // 🏆 Ranking de criativos (hoje): top 3 anúncios ativos por ROAS.
  const topCreatives = ads
    .filter((a) => isActiveStatus(a.status) && a.spendCentsDay > 0)
    .map((a) => {
      const acc = a.adset.campaign.adAccount;
      const spend = toBrlCents(a.spendCentsDay, acc.currency, acc.fxRateOverride);
      const rev = revByAdExt.get(a.externalId) ?? 0;
      return {
        name: a.name,
        campaign: a.adset.campaign.name,
        platform: acc.platform,
        spendCents: spend,
        revenueCents: rev,
        roas: spend > 0 ? rev / spend : null,
      };
    })
    .sort((a, b) => (b.roas ?? 0) - (a.roas ?? 0))
    .slice(0, 3);

  // ⭐ Favoritas (vencedoras marcadas) — gasto convertido + receita de hoje.
  const favorites = favoriteCampaigns
    .map((c) => {
      const acc = c.adAccount;
      const spend = toBrlCents(c.spendCentsDay, acc.currency, acc.fxRateOverride);
      const rev = revByName.get(c.name.trim().toLowerCase()) ?? 0;
      return {
        name: c.name,
        platform: acc.platform,
        spendCents: spend,
        revenueCents: rev,
        roas: spend > 0 ? rev / spend : null,
        active: isActiveStatus(c.status),
      };
    })
    .sort((a, b) => (b.roas ?? -1) - (a.roas ?? -1));

  const series = snapshots.map((s) => ({
    day: s.day.toISOString().slice(0, 10),
    spendCents: s.spendCents,
    revenueCents: s.revenueCents,
  }));

  // Projeção de fim de dia (extrapola o ritmo pela fração do dia UTC decorrida).
  const elapsedMs = new Date().getTime() - todayStart.getTime();
  const fractionElapsed = Math.min(1, Math.max(elapsedMs / 86400000, 0.0001));

  // 📆 Hoje vs ontem (no mesmo ponto do dia). Ontem vem do snapshot diário,
  // prorrateado pela fração do dia → comparação justa de ritmo.
  const yStart = new Date(todayStart);
  yStart.setUTCDate(yStart.getUTCDate() - 1);
  const yKey = yStart.toISOString().slice(0, 10);
  const ySnap = snapshots.find(
    (s) => s.day.toISOString().slice(0, 10) === yKey,
  );
  let comparison: AdsOverview["comparison"] = null;
  if (ySnap) {
    const pace = (today: number, yFull: number): number | null => {
      const base = yFull * fractionElapsed;
      return base !== 0 ? ((today - base) / Math.abs(base)) * 100 : null;
    };
    const todayProfit = totalRevenueCents - totalSpendCents;
    const yProfit = ySnap.revenueCents - ySnap.spendCents;
    const roasToday =
      totalSpendCents > 0 ? totalRevenueCents / totalSpendCents : null;
    const roasYest =
      ySnap.spendCents > 0 ? ySnap.revenueCents / ySnap.spendCents : null;
    comparison = {
      spendDeltaPct: pace(totalSpendCents, ySnap.spendCents),
      revenueDeltaPct: pace(totalRevenueCents, ySnap.revenueCents),
      profitDeltaPct: pace(todayProfit, yProfit),
      roasDeltaPct:
        roasToday != null && roasYest != null && roasYest > 0
          ? ((roasToday - roasYest) / roasYest) * 100
          : null,
    };
  }

  return {
    platforms,
    totalSpendCents,
    totalRevenueCents,
    totalRoas: totalSpendCents > 0 ? totalRevenueCents / totalSpendCents : null,
    best,
    worst,
    topCreatives,
    favorites,
    burningCount,
    series,
    topProducts,
    projection: {
      spendTodayCents: totalSpendCents,
      revenueTodayCents: totalRevenueCents,
      fractionElapsed,
      projSpendCents: Math.round(totalSpendCents / fractionElapsed),
      projRevenueCents: Math.round(totalRevenueCents / fractionElapsed),
    },
    comparison,
    converted,
    fxLive: isFxLive(),
    hasData:
      totalSpendCents > 0 ||
      totalRevenueCents > 0 ||
      snapshots.length > 0 ||
      favorites.length > 0,
  };
}
