/**
 * Insights diários de ads por seller. Roda via cron (ad-insights), logo após
 * o sync de gasto. Tudo é derivado do que já está no banco:
 *   - gasto: AdCampaign.spendCentsDay (atualizado pelo ad-sync)
 *   - receita: Transaction PAID de hoje, atribuída por utm_campaign == nome
 *     da campanha (mesma lógica da tela de ROAS)
 *
 * Faz 3 coisas:
 *   1) 📈 Snapshot diário (grão usuário/dia) → alimenta o gráfico de evolução.
 *   2) 💸 Alerta de queima de budget → push quando campanha ATIVA gastou
 *      acima do limite no dia SEM nenhuma venda (dedup 12h por campanha).
 *   3) 🔁 Escalar vencedora → sobe o budget diário de campanhas com ROAS alto
 *      (dedup 24h por campanha; respeita teto opcional).
 */
import { prisma } from "./prisma";
import { sendPushToUser } from "./push";
import { setObjectBudget } from "./ad-sync";
import { toBrlCents, ensureFxRates } from "./fx";

function utcDayStart(d = new Date()): Date {
  const x = new Date(d);
  x.setUTCHours(0, 0, 0, 0);
  return x;
}

function brl(cents: number): string {
  return (cents / 100).toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  });
}

const PAUSED_HINTS = ["PAUSED", "DISABLE", "DELETE", "ARCHIV", "INACTIVE"];
function isActiveStatus(status: string | null | undefined): boolean {
  const s = (status || "").toUpperCase();
  return !PAUSED_HINTS.some((h) => s.includes(h));
}

const BURN_DEDUP_MS = 12 * 60 * 60 * 1000;
const SCALE_DEDUP_MS = 24 * 60 * 60 * 1000;

/** Roda os insights diários de UM seller. */
export async function runUserInsights(userId: string): Promise<{
  snapshot: boolean;
  burning: number;
  scaled: number;
}> {
  const todayStart = utcDayStart();

  const settings = await prisma.userSettings.findUnique({ where: { userId } });
  const alertsEnabled = settings?.adAlertsEnabled ?? true;
  const burnThreshold = settings?.adBurnAlertCents ?? 5000;
  const autoScaleEnabled = settings?.autoScaleEnabled ?? false;
  const minRoas = settings?.autoScaleMinRoas ?? 2;
  const stepPct = settings?.autoScaleStepPct ?? 20;
  const maxBudget = settings?.autoScaleMaxBudgetCents ?? 0;

  const campaigns = await prisma.adCampaign.findMany({
    where: { adAccount: { userId, enabled: true } },
    select: {
      id: true,
      externalId: true,
      name: true,
      status: true,
      dailyBudgetCents: true,
      spendCentsDay: true,
      alertedBurnAt: true,
      lastScaledAt: true,
      adAccountId: true,
      adAccount: { select: { currency: true, fxRateOverride: true } },
    },
  });
  await ensureFxRates();

  // Receita de HOJE por utm_campaign (normalizado) + total.
  const paidTx = await prisma.transaction.findMany({
    where: { userId, status: "PAID", paidAt: { gte: todayStart } },
    select: { amountCents: true, utmCampaign: true },
  });
  let totalRevenue = 0;
  const revByUtm = new Map<string, { rev: number; n: number }>();
  for (const t of paidTx) {
    totalRevenue += t.amountCents;
    const k = (t.utmCampaign || "").trim().toLowerCase();
    if (!k) continue;
    const e = revByUtm.get(k) ?? { rev: 0, n: 0 };
    e.rev += t.amountCents;
    e.n += 1;
    revByUtm.set(k, e);
  }
  // Gasto convertido pra BRL (snapshot/dashboard somam em R$).
  const totalSpend = campaigns.reduce(
    (s, c) =>
      s +
      toBrlCents(
        c.spendCentsDay,
        c.adAccount.currency,
        c.adAccount.fxRateOverride,
      ),
    0,
  );
  const sales = paidTx.length;

  // 1) SNAPSHOT — upsert por dia (último write do dia = número final).
  await prisma.adSpendSnapshot.upsert({
    where: { userId_day: { userId, day: todayStart } },
    create: {
      userId,
      day: todayStart,
      spendCents: totalSpend,
      revenueCents: totalRevenue,
      sales,
    },
    update: { spendCents: totalSpend, revenueCents: totalRevenue, sales },
  });

  const enriched = campaigns.map((c) => {
    const r = revByUtm.get(c.name.trim().toLowerCase());
    const rev = r?.rev ?? 0;
    // Gasto em BRL pra comparar com receita (BRL) e com o limite de queima (BRL).
    const spendBrl = toBrlCents(
      c.spendCentsDay,
      c.adAccount.currency,
      c.adAccount.fxRateOverride,
    );
    return {
      ...c,
      rev,
      salesN: r?.n ?? 0,
      spendBrl,
      roas: spendBrl > 0 ? rev / spendBrl : null,
      active: isActiveStatus(c.status),
    };
  });

  // 2) ALERTA DE QUEIMA — ativa, gastou >= limite hoje, 0 venda.
  const now = Date.now();
  const freshBurners: typeof enriched = [];
  for (const c of enriched) {
    const burning =
      c.active && c.spendBrl >= burnThreshold && c.salesN === 0;
    if (burning) {
      const last = c.alertedBurnAt ? new Date(c.alertedBurnAt).getTime() : 0;
      if (now - last > BURN_DEDUP_MS) {
        freshBurners.push(c);
        await prisma.adCampaign.update({
          where: { id: c.id },
          data: { alertedBurnAt: new Date() },
        });
      }
    } else if (c.alertedBurnAt) {
      // Deixou de queimar → reseta o dedup pra avisar de novo no futuro.
      await prisma.adCampaign
        .update({ where: { id: c.id }, data: { alertedBurnAt: null } })
        .catch(() => {});
    }
  }
  if (alertsEnabled && freshBurners.length > 0) {
    const head = freshBurners[0];
    const extra = freshBurners.length - 1;
    const title =
      freshBurners.length === 1
        ? "💸 Campanha queimando dinheiro"
        : `💸 ${freshBurners.length} campanhas queimando dinheiro`;
    const body =
      freshBurners.length === 1
        ? `"${head.name}" gastou ${brl(head.spendBrl)} hoje sem nenhuma venda.`
        : `"${head.name}" +${extra} gastaram sem venda hoje. Veja no ROAS.`;
    await sendPushToUser(userId, {
      title,
      body,
      url: "/dashboard/tracking/campanhas",
      kind: "generic",
    }).catch(() => {});
  }

  // 3) ESCALAR VENCEDORA — ativa, ROAS alto, com budget diário, dedup 24h.
  let scaled = 0;
  if (autoScaleEnabled) {
    const scaledNames: string[] = [];
    for (const c of enriched) {
      if (!c.active) continue;
      if (c.roas == null || c.roas < minRoas) continue;
      const cur = c.dailyBudgetCents ?? 0;
      if (cur <= 0) continue;
      if (maxBudget > 0 && cur >= maxBudget) continue;
      const last = c.lastScaledAt ? new Date(c.lastScaledAt).getTime() : 0;
      if (now - last < SCALE_DEDUP_MS) continue;

      let next = Math.round(cur * (1 + stepPct / 100));
      if (maxBudget > 0) next = Math.min(next, maxBudget);
      if (next <= cur) continue;

      const r = await setObjectBudget(c.adAccountId, c.externalId, next);
      if (r.ok) {
        await prisma.adCampaign.update({
          where: { id: c.id },
          data: { lastScaledAt: new Date() },
        });
        scaled++;
        scaledNames.push(`${c.name} → ${brl(next)}/dia`);
      }
    }
    if (scaled > 0) {
      await sendPushToUser(userId, {
        title:
          scaled === 1
            ? "🔁 Budget escalado (vencedora)"
            : `🔁 ${scaled} campanhas escaladas`,
        body: scaledNames.slice(0, 3).join(" · "),
        url: "/dashboard/tracking/campanhas",
        kind: "generic",
      }).catch(() => {});
    }
  }

  // 📊 RESUMO DIÁRIO — 1x/dia, a partir das 20h (Brasília), via push.
  // Usa o toggle de alertas (adAlertsEnabled) e deduplica por dia.
  if (alertsEnabled) {
    const bnow = new Date(Date.now() - 3 * 60 * 60 * 1000);
    const bToday = bnow.toISOString().slice(0, 10);
    if (bnow.getUTCHours() >= 20 && settings?.lastDailySummaryDay !== bToday) {
      const profit = totalRevenue - totalSpend;
      const best = enriched
        .filter((c) => c.roas != null && c.spendCentsDay > 0)
        .sort((a, b) => (b.roas ?? 0) - (a.roas ?? 0))[0];
      await sendPushToUser(userId, {
        title: "📊 Resumo do dia",
        body:
          `Gasto ${brl(totalSpend)} · Receita ${brl(totalRevenue)} · ` +
          `Lucro ${brl(profit)} · ${sales} venda(s)` +
          (best ? ` · 🏆 ${best.name} (${best.roas!.toFixed(2)}x)` : ""),
        url: "/dashboard/tracking/campanhas",
        kind: "generic",
      }).catch(() => {});
      await prisma.userSettings.upsert({
        where: { userId },
        create: { userId, lastDailySummaryDay: bToday },
        update: { lastDailySummaryDay: bToday },
      });
    }
  }

  // ⚠️ ALERTA "VENDAS SEM CAMPANHA" — quando muitas vendas de hoje chegam sem
  // utm_campaign (anúncio sem tracking configurado). 1x/dia, dedup.
  if (alertsEnabled && sales >= 5) {
    const untracked = paidTx.filter(
      (t) => !(t.utmCampaign || "").trim(),
    ).length;
    const pct = untracked / sales;
    const bnow = new Date(Date.now() - 3 * 60 * 60 * 1000);
    const bToday = bnow.toISOString().slice(0, 10);
    if (pct >= 0.5 && settings?.lastUtmAlertDay !== bToday) {
      await sendPushToUser(userId, {
        title: "⚠️ Vendas sem campanha",
        body: `${Math.round(pct * 100)}% das ${sales} vendas de hoje chegaram SEM campanha (UTM). Confira o tracking dos anúncios.`,
        url: "/dashboard/tracking/diagnostico",
        kind: "generic",
      }).catch(() => {});
      await prisma.userSettings.upsert({
        where: { userId },
        create: { userId, lastUtmAlertDay: bToday },
        update: { lastUtmAlertDay: bToday },
      });
    }
  }

  return { snapshot: true, burning: freshBurners.length, scaled };
}

/** Roda os insights pra TODOS os sellers com conta de ads ativa. */
export async function runAllInsights(): Promise<{
  users: number;
  snapshots: number;
  burning: number;
  scaled: number;
}> {
  const accounts = await prisma.adAccount.findMany({
    where: { enabled: true, platform: { in: ["meta", "tiktok"] } },
    select: { userId: true },
    distinct: ["userId"],
  });

  let users = 0;
  let snapshots = 0;
  let burning = 0;
  let scaled = 0;
  for (const a of accounts) {
    try {
      const r = await runUserInsights(a.userId);
      users++;
      if (r.snapshot) snapshots++;
      burning += r.burning;
      scaled += r.scaled;
    } catch (e) {
      console.error("[ad-insights] erro no user", a.userId, e);
    }
  }
  return { users, snapshots, burning, scaled };
}
