/**
 * Publicação REAL de mass campaign na API do TikTok (e Meta — em breve).
 *
 * Chamado pelo cron /api/cron/process-mass-campaigns. Substitui a antiga
 * simulação. Para cada conta de anúncio do job, roda a cadeia:
 *   createCampaign → getCountryLocationIds → createAdgroup
 *   → uploadVideoByUrl → suggestVideoCover → getOrCreateIdentity → createAd
 *
 * SEGURANÇA: tudo nasce PAUSED (operation_status: DISABLE no adgroup + ad),
 * então NADA entrega/gasta até o seller ativar manualmente no TikTok.
 *
 * Tolerante a falha: se o nível de criativo (vídeo/ad) falhar, a campanha +
 * adgroup já criados ficam (pausados) e o erro exato do TikTok vai pro
 * resultado do job — o seller vê e a gente ajusta sem perder a estrutura.
 */
import { prisma } from "./prisma";
import { decryptString } from "./crypto";
import {
  createCampaign,
  createAdgroup,
  getCountryLocationIds,
  uploadVideoByUrl,
  suggestVideoCover,
  getOrCreateIdentity,
  createAd,
} from "./providers/tiktok-ads";

export type PublishResult = {
  ok: boolean;
  campaignIds?: string[];
  adIds?: string[];
  error?: string;
};

type Counts = {
  campaignsPerAccount: number;
  adsetsPerCampaign: number;
  adsPerAdset: number;
};

/** Mapeia o optimization_goal da UI pro valor aceito pelo TikTok. */
function mapTiktokOptimizationGoal(goal: string): string {
  const g = (goal || "").toUpperCase();
  if (g === "CONVERSION" || g === "CONVERT") return "CONVERT";
  if (g === "CLICK") return "CLICK";
  if (g === "REACH") return "REACH";
  if (g === "INSTALL") return "INSTALL";
  return "CONVERT";
}

/** objective_type do TikTok (a UI/config pode mandar valores genéricos). */
function mapTiktokObjective(objective: string): string {
  const o = (objective || "").toUpperCase();
  if (
    o === "CONVERSIONS" ||
    o === "WEB_CONVERSIONS" ||
    o === "OFFSITE_CONVERSIONS" ||
    o === "CONVERSION"
  )
    return "WEB_CONVERSIONS";
  if (o === "TRAFFIC") return "TRAFFIC";
  if (o === "REACH") return "REACH";
  if (o === "VIDEO_VIEWS") return "VIDEO_VIEWS";
  if (o === "LEAD_GENERATION" || o === "LEADS") return "LEAD_GENERATION";
  if (o === "ENGAGEMENT") return "ENGAGEMENT";
  return "WEB_CONVERSIONS";
}

/** optimization_event (evento do pixel) — mapeia nomes comuns pro código TikTok. */
function mapTiktokOptimizationEvent(ev: string | null | undefined): string | null {
  if (!ev) return null;
  const e = ev.toUpperCase();
  if (e === "COMPLETE_PAYMENT" || e === "PURCHASE" || e === "ON_WEB_ORDER")
    return "ON_WEB_ORDER";
  if (e === "ADD_TO_CART" || e === "ON_WEB_CART") return "ON_WEB_CART";
  if (e === "INITIATE_CHECKOUT" || e === "INITIATE_ORDER")
    return "INITIATE_ORDER";
  if (e === "VIEW_CONTENT" || e === "ON_WEB_DETAIL") return "ON_WEB_DETAIL";
  if (e === "COMPLETE_REGISTRATION" || e === "ON_WEB_REGISTER")
    return "ON_WEB_REGISTER";
  if (e === "FORM" || e === "LEAD" || e === "SUBMIT_FORM") return "FORM";
  // passthrough (já pode ser um código válido do TikTok)
  return ev;
}

type TiktokConfig = {
  campaignName?: string;
  objective?: string;
  campaignBudgetMode?: string;
  campaignBudgetCents?: number | null;
  adGroupName?: string;
  adGroupDailyBudgetCents?: number;
  optimizationGoal?: string;
  pixelId?: string | null;
  conversionEvent?: string | null;
  placementType?: string;
  placements?: string[];
  targeting?: {
    countries?: string[];
    ageGroups?: string[];
    genders?: string[];
  };
  adName?: string;
  identityDisplayName?: string | null;
  creativeMediaUrls?: string[];
  adText?: string;
  callToAction?: string;
  landingUrl?: string;
  /** SINGLE_VIDEO (default) | SPARK_AD | ... */
  adFormat?: string;
  /** SPARK: id do post orgânico do TikTok a impulsionar */
  sparkTiktokItemId?: string | null;
  /** SPARK: identity TT_USER (conta dona do post) */
  sparkIdentityId?: string | null;
};

/**
 * Publica a campanha (do job) numa ÚNICA ad account. Loop de
 * campaignsPerAccount × adsetsPerCampaign × adsPerAdset.
 */
export async function publishToAdAccount(
  adAccountDbId: string,
  platform: string,
  config: unknown,
  counts: Counts,
): Promise<PublishResult> {
  const acc = await prisma.adAccount.findUnique({
    where: { id: adAccountDbId },
  });
  if (!acc) return { ok: false, error: "conta de anúncio não encontrada" };

  if (platform === "meta") {
    // Meta ainda nao implementado (app em analise no Facebook). Honesto:
    // nao finge sucesso.
    return {
      ok: false,
      error: "Publicação Meta ainda indisponível (app em análise no Facebook).",
    };
  }
  if (platform !== "tiktok") {
    return { ok: false, error: `Plataforma não suportada: ${platform}` };
  }

  const cfg = (config ?? {}) as TiktokConfig;
  const token = decryptString(acc.accessToken);
  const advertiserId = acc.accountId; // TikTok: accountId = advertiser_id

  const campaignIds: string[] = [];
  const adIds: string[] = [];

  try {
    // 1. Resolve location_ids uma vez por conta (reaproveita).
    const countries = cfg.targeting?.countries?.length
      ? cfg.targeting.countries
      : ["BR"];
    const objective = mapTiktokObjective(cfg.objective || "WEB_CONVERSIONS");
    const locationIds = await getCountryLocationIds(
      token,
      advertiserId,
      countries,
      objective,
    );

    const isSpark = (cfg.adFormat || "").toUpperCase() === "SPARK_AD";

    // 2. Criativo (reaproveita por conta).
    //  - SPARK: usa post orgânico existente (não sobe vídeo) + identity TT_USER.
    //  - VÍDEO: sobe o vídeo (video_id) + cover + cria/usa identity CUSTOMIZED_USER.
    let videoId: string | null = null;
    let coverImageId: string | null = null;
    let identity: { identityId: string; identityType: string } | null = null;

    if (isSpark) {
      if (cfg.sparkIdentityId) {
        identity = { identityId: cfg.sparkIdentityId, identityType: "TT_USER" };
      }
    } else {
      const videoUrl = cfg.creativeMediaUrls?.[0];
      if (videoUrl) {
        videoId = await uploadVideoByUrl(
          token,
          advertiserId,
          videoUrl,
          cfg.adName || cfg.campaignName || "BravoPay Ad",
        );
        coverImageId = await suggestVideoCover(token, advertiserId, videoId);
        identity = await getOrCreateIdentity(
          token,
          advertiserId,
          cfg.identityDisplayName || acc.accountName || "BravoPay",
        );
      }
    }

    const optGoal = mapTiktokOptimizationGoal(cfg.optimizationGoal || "CONVERT");

    // 4. Loop campanhas × adgroups × ads.
    for (let c = 0; c < counts.campaignsPerAccount; c++) {
      const suffix = counts.campaignsPerAccount > 1 ? ` ${c + 1}` : "";
      const campaignId = await createCampaign(token, advertiserId, {
        name: (cfg.campaignName || "Campanha BravoPay") + suffix,
        objective,
        budgetMode: cfg.campaignBudgetMode || "BUDGET_MODE_INFINITE",
        budgetCents: cfg.campaignBudgetCents ?? null,
      });
      campaignIds.push(campaignId);

      for (let g = 0; g < counts.adsetsPerCampaign; g++) {
        const gSuffix = counts.adsetsPerCampaign > 1 ? ` ${g + 1}` : "";
        const adgroupId = await createAdgroup(token, advertiserId, {
          campaignId,
          name: (cfg.adGroupName || "Conjunto BravoPay") + suffix + gSuffix,
          locationIds,
          budgetCents: cfg.adGroupDailyBudgetCents ?? 2000,
          optimizationGoal: optGoal,
          pixelId: cfg.pixelId ?? null,
          optimizationEvent: mapTiktokOptimizationEvent(cfg.conversionEvent),
          placementType: cfg.placementType,
          placements: cfg.placements,
          ageGroups: cfg.targeting?.ageGroups,
          genders: cfg.targeting?.genders,
        });

        // Cria ad se tiver identity + landing + (vídeo OU post spark).
        const hasCreative = isSpark ? !!cfg.sparkTiktokItemId : !!videoId;
        if (identity && cfg.landingUrl && hasCreative) {
          for (let a = 0; a < counts.adsPerAdset; a++) {
            const aSuffix = counts.adsPerAdset > 1 ? ` ${a + 1}` : "";
            const created = await createAd(token, advertiserId, {
              adgroupId,
              adName: (cfg.adName || "Anúncio BravoPay") + suffix + gSuffix + aSuffix,
              identityId: identity.identityId,
              identityType: identity.identityType,
              videoId: isSpark ? null : videoId,
              coverImageId: isSpark ? null : coverImageId,
              tiktokItemId: isSpark ? cfg.sparkTiktokItemId : null,
              adText: cfg.adText || "",
              callToAction: cfg.callToAction || "SHOP_NOW",
              landingUrl: cfg.landingUrl,
            });
            adIds.push(...created);
          }
        }
      }
    }

    // Sucesso parcial é OK: se faltou vídeo/landing, criou campanha+adgroup.
    return { ok: true, campaignIds, adIds };
  } catch (e) {
    const msg = e instanceof Error ? e.message : "erro desconhecido";
    // Se já criou alguma campanha antes de falhar, devolve os IDs pra rastreio.
    return {
      ok: false,
      error: msg,
      campaignIds: campaignIds.length ? campaignIds : undefined,
      adIds: adIds.length ? adIds : undefined,
    };
  }
}
