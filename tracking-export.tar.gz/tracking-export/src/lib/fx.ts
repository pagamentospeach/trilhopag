/**
 * Conversão de moeda → BRL para o GATEWAY.
 *
 * Regra do produto: a aba de Tracking (Campanhas) mostra o gasto na moeda
 * NATIVA da conta. O RESTO do gateway (dashboard, métricas, alertas,
 * snapshots) SEMPRE converte pra BRL.
 *
 * Cotação: tenta AO VIVO (open.er-api.com, grátis, sem key) com cache de 12h;
 * cai pra uma tabela estática se a API falhar. Cada conta pode ainda travar
 * uma taxa MANUAL (AdAccount.fxRateOverride).
 */

// Fallback estático (aprox.) caso a cotação ao vivo falhe.
const STATIC_FX_TO_BRL: Record<string, number> = {
  BRL: 1,
  USD: 5.4,
  USDT: 5.4,
  EUR: 5.9,
  GBP: 6.9,
  CLP: 0.0063,
  ARS: 0.004,
  MXN: 0.3,
  COP: 0.0013,
  PEN: 1.45,
  UYU: 0.135,
  PYG: 0.00072,
  BOB: 0.78,
  CAD: 3.95,
  AUD: 3.6,
  INR: 0.065,
};

let liveRates: Record<string, number> | null = null;
let fetchedAt = 0;
const FX_TTL_MS = 12 * 60 * 60 * 1000;

/**
 * Garante que temos cotações recentes em memória. Chame (await) antes de usar
 * toBrlCents num lote de conversões. Best-effort: se falhar, mantém o que tem
 * (live anterior ou nada → cai no estático). Não lança.
 */
export async function ensureFxRates(): Promise<void> {
  if (liveRates && Date.now() - fetchedAt < FX_TTL_MS) return;
  try {
    const res = await fetch("https://open.er-api.com/v6/latest/BRL", {
      signal: AbortSignal.timeout(5000),
    });
    const data = (await res.json()) as {
      result?: string;
      rates?: Record<string, number>;
    };
    if (data?.result === "success" && data.rates) {
      // data.rates = BRL→X (1 BRL = X moeda). Invertendo → X→BRL.
      const inv: Record<string, number> = { BRL: 1 };
      for (const [code, r] of Object.entries(data.rates)) {
        const n = Number(r);
        if (n > 0) inv[code.toUpperCase()] = 1 / n;
      }
      liveRates = inv;
      fetchedAt = Date.now();
    }
  } catch {
    // mantém fallback
  }
}

/** Taxa da moeda → BRL (live → estático → 1). */
export function fxRateToBrl(currency?: string | null): number {
  if (!currency) return 1;
  const code = currency.trim().toUpperCase();
  if (code === "BRL") return 1;
  return liveRates?.[code] ?? STATIC_FX_TO_BRL[code] ?? 1;
}

/**
 * Converte "cents" da moeda da conta para BRL cents.
 * `override` (taxa manual da conta) tem prioridade sobre a cotação.
 */
export function toBrlCents(
  cents: number,
  currency?: string | null,
  override?: number | null,
): number {
  if (!cents) return 0;
  const rate =
    override != null && override > 0 ? override : fxRateToBrl(currency);
  return Math.round(cents * rate);
}

/** True quando a cotação atual veio AO VIVO (não do fallback estático). */
export function isFxLive(): boolean {
  return liveRates != null;
}
