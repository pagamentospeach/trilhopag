/**
 * Kwai Ads Marketing API client.
 *
 * Docs: https://developers.kwai.com/marketing-api/
 *
 * Diferente do Meta/TikTok, o Kwai Ads usa **API Key direta** pra criadores
 * (não tem OAuth público pra apps de terceiros — a maioria das integrações
 * é via Marketing API com Bearer Token gerado no portal Business).
 *
 * Fluxo de conexão BravoPay:
 *  1. Usuário pega seu Access Token no Kwai Business Manager
 *  2. Cola no UI da gente
 *  3. Salvamos cifrado em AdAccount.accessTokenEnc
 *  4. Validamos chamando /openapi/account/info pra pegar accountId + name
 *
 * Eventos de conversão (server-side):
 *  - POST /log/common/api com `event` = "EVENT_PURCHASE" / "EVENT_CHECKOUT" etc
 *  - Inclui pixel_id + access_token + event_id (dedup) + event_time + properties
 */

const API_BASE = "https://developers.kwai.com/openapi";
const EVENT_API = "https://www.kwai.com/log/common/api";

export type KwaiAccountInfo = {
  accountId: string;
  accountName: string;
  currency?: string;
};

/**
 * Valida um access token tentando buscar info da conta.
 * Retorna info ou throw se token inválido.
 */
export async function fetchKwaiAccountInfo(accessToken: string): Promise<KwaiAccountInfo> {
  const res = await fetch(`${API_BASE}/account/info`, {
    method: "GET",
    headers: {
      "Access-Token": accessToken,
      "Content-Type": "application/json",
    },
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(
      `Kwai API: HTTP ${res.status} — verifique seu Access Token. ${text.slice(0, 200)}`,
    );
  }
  const data = (await res.json()) as {
    code?: number;
    data?: { id?: string; name?: string; currency?: string };
    message?: string;
  };
  if (data.code !== 0 || !data.data?.id) {
    throw new Error(`Kwai API erro: ${data.message ?? "resposta inesperada"}`);
  }
  return {
    accountId: data.data.id,
    accountName: data.data.name ?? "Conta Kwai",
    currency: data.data.currency,
  };
}

export type KwaiCampaign = {
  id: string;
  name: string;
  status: string;
  budget?: number;
  spend?: number;
};

/** Lista campanhas. */
export async function fetchKwaiCampaigns(
  accessToken: string,
  accountId: string,
): Promise<KwaiCampaign[]> {
  const res = await fetch(`${API_BASE}/v1/campaign/list?advertiser_id=${accountId}`, {
    headers: {
      "Access-Token": accessToken,
      "Content-Type": "application/json",
    },
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) {
    throw new Error(`Kwai campaigns: HTTP ${res.status}`);
  }
  const data = (await res.json()) as {
    code?: number;
    data?: { list?: Array<{ id: string; name: string; status: string; budget?: number }> };
  };
  return (
    data.data?.list?.map((c) => ({
      id: String(c.id),
      name: c.name,
      status: c.status,
      budget: c.budget,
    })) ?? []
  );
}

/**
 * Dispara um evento de conversão pro Kwai (server-side, igual Meta CAPI).
 * Use em markTransactionPaid pra atribuir vendas a campanhas Kwai.
 */
export async function fireKwaiEvent(opts: {
  pixelId: string;
  accessToken: string;
  eventName: "EVENT_PURCHASE" | "EVENT_INITIATE_CHECKOUT" | "EVENT_CONTENT_VIEW";
  eventId: string; // dedup contra pixel client-side
  eventTime?: number; // unix seconds
  value?: number;
  currency?: string;
  contentId?: string;
  email?: string; // hashed sha256 server-side
  phone?: string;
}): Promise<void> {
  const payload = {
    pixel_id: opts.pixelId,
    access_token: opts.accessToken,
    event: opts.eventName,
    event_id: opts.eventId,
    event_time: opts.eventTime ?? Math.floor(Date.now() / 1000),
    properties: {
      value: opts.value,
      currency: opts.currency ?? "BRL",
      content_id: opts.contentId,
    },
    ...(opts.email || opts.phone
      ? {
          user_data: {
            ...(opts.email ? { em: await sha256(opts.email.toLowerCase().trim()) } : {}),
            ...(opts.phone ? { ph: await sha256(opts.phone.replace(/\D/g, "")) } : {}),
          },
        }
      : {}),
  };

  await fetch(EVENT_API, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(10_000),
  });
}

async function sha256(s: string): Promise<string> {
  const enc = new TextEncoder();
  const data = enc.encode(s);
  const buf = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}
