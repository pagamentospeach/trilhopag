/**
 * Google Ads API client.
 *
 * Docs:
 *  - OAuth: https://developers.google.com/identity/protocols/oauth2/web-server
 *  - Ads API: https://developers.google.com/google-ads/api/docs/start
 *  - Conversions: https://developers.google.com/google-ads/api/docs/conversions/upload-clicks
 *
 * OAuth flow:
 *   1. Redirect user pra accounts.google.com/o/oauth2/v2/auth?scope=adwords
 *   2. Google redirect back com ?code=XXX&state=YYY
 *   3. Troca code por refresh_token + access_token via /token endpoint
 *   4. Salvar refresh_token criptografado (access_token expira em 1h)
 *   5. Pra cada listAccessibleCustomers, criar uma AdAccount
 *
 * Conversion API:
 *   POST customers/{customer_id}/googleAds:uploadClickConversions
 *   Body: {
 *     conversions: [{
 *       gclid, conversion_action, conversion_date_time, conversion_value, currency_code
 *     }]
 *   }
 *
 * Pré-requisitos:
 *  - Developer Token (aprovado no Google Ads Center)
 *  - Manager Account (MCC) opcional pra acessar múltiplas contas
 *  - OAuth Client ID/Secret no Google Cloud Console
 */

const OAUTH_BASE = "https://accounts.google.com/o/oauth2";
const TOKEN_URL = "https://oauth2.googleapis.com/token";
const ADS_API_BASE = "https://googleads.googleapis.com/v18";

function clientId(): string {
  const v = process.env.GOOGLE_OAUTH_CLIENT_ID;
  if (!v) throw new Error("GOOGLE_OAUTH_CLIENT_ID env var não configurada");
  return v;
}

function clientSecret(): string {
  const v = process.env.GOOGLE_OAUTH_CLIENT_SECRET;
  if (!v) throw new Error("GOOGLE_OAUTH_CLIENT_SECRET env var não configurada");
  return v;
}

function developerToken(): string {
  const v = process.env.GOOGLE_ADS_DEVELOPER_TOKEN;
  if (!v) throw new Error("GOOGLE_ADS_DEVELOPER_TOKEN env var não configurada");
  return v;
}

function appUrl(): string {
  return process.env.NEXT_PUBLIC_APP_URL ?? "https://bravopay.club";
}

const REDIRECT_URI = () => `${appUrl()}/api/oauth/google/callback`;

/** URL de OAuth do Google Ads. Solicita scope `adwords` pra ler/gravar campanhas. */
export function googleAdsOAuthUrl(state: string): string {
  const params = new URLSearchParams({
    client_id: clientId(),
    redirect_uri: REDIRECT_URI(),
    response_type: "code",
    scope: "https://www.googleapis.com/auth/adwords",
    access_type: "offline", // pra receber refresh_token
    prompt: "consent", // força tela de consent pra garantir refresh_token
    state,
  });
  return `${OAUTH_BASE}/auth?${params.toString()}`;
}

/** Troca o auth code por refresh_token + access_token. */
export async function exchangeGoogleCode(code: string): Promise<{
  access_token: string;
  refresh_token: string;
  expires_in: number;
  token_type: string;
  scope: string;
}> {
  const body = new URLSearchParams({
    code,
    client_id: clientId(),
    client_secret: clientSecret(),
    redirect_uri: REDIRECT_URI(),
    grant_type: "authorization_code",
  });
  const res = await fetch(TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body,
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`Google OAuth: ${res.status} — ${text.slice(0, 200)}`);
  }
  return res.json();
}

/** Renova access_token usando refresh_token. */
export async function refreshGoogleAccessToken(refreshToken: string): Promise<{
  access_token: string;
  expires_in: number;
  token_type: string;
}> {
  const body = new URLSearchParams({
    refresh_token: refreshToken,
    client_id: clientId(),
    client_secret: clientSecret(),
    grant_type: "refresh_token",
  });
  const res = await fetch(TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body,
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) throw new Error(`refresh failed: ${res.status}`);
  return res.json();
}

/** Lista contas Google Ads acessíveis. */
export async function listAccessibleCustomers(accessToken: string): Promise<{
  resourceNames: string[];
}> {
  const res = await fetch(`${ADS_API_BASE}/customers:listAccessibleCustomers`, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "developer-token": developerToken(),
    },
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`Google Ads listCustomers: ${res.status} — ${text.slice(0, 200)}`);
  }
  return res.json();
}

/** Busca info detalhada de uma conta (customer_id). */
export async function getCustomerInfo(
  accessToken: string,
  customerId: string,
  loginCustomerId?: string,
): Promise<{ id: string; descriptiveName: string; currencyCode: string }> {
  const headers: HeadersInit = {
    Authorization: `Bearer ${accessToken}`,
    "developer-token": developerToken(),
  };
  if (loginCustomerId) {
    headers["login-customer-id"] = loginCustomerId.replace(/-/g, "");
  }
  const res = await fetch(
    `${ADS_API_BASE}/customers/${customerId.replace(/-/g, "")}/googleAds:searchStream`,
    {
      method: "POST",
      headers: { ...headers, "Content-Type": "application/json" },
      body: JSON.stringify({
        query:
          "SELECT customer.id, customer.descriptive_name, customer.currency_code FROM customer LIMIT 1",
      }),
      signal: AbortSignal.timeout(15_000),
    },
  );
  if (!res.ok) {
    throw new Error(`Google Ads getCustomerInfo: ${res.status}`);
  }
  const data = (await res.json()) as Array<{
    results?: Array<{
      customer?: { id: string; descriptiveName?: string; currencyCode?: string };
    }>;
  }>;
  const c = data?.[0]?.results?.[0]?.customer;
  if (!c) throw new Error("Conta sem dados retornados");
  return {
    id: c.id,
    descriptiveName: c.descriptiveName ?? `Conta ${c.id}`,
    currencyCode: c.currencyCode ?? "BRL",
  };
}

/**
 * Envia conversão pra Google Ads via Click Conversions API.
 * Requer `gclid` capturado no checkout (storage do click ID).
 */
export async function uploadGoogleClickConversion(opts: {
  accessToken: string;
  customerId: string;
  loginCustomerId?: string; // MCC se aplicável
  gclid: string;
  conversionActionId: string; // formato: customers/X/conversionActions/Y
  conversionValue: number;
  currencyCode?: string;
  conversionDateTime?: string; // formato: "2024-01-15 10:30:00-03:00"
  orderId?: string; // pra dedup
}): Promise<void> {
  const cid = opts.customerId.replace(/-/g, "");
  const headers: HeadersInit = {
    Authorization: `Bearer ${opts.accessToken}`,
    "developer-token": developerToken(),
    "Content-Type": "application/json",
  };
  if (opts.loginCustomerId) {
    headers["login-customer-id"] = opts.loginCustomerId.replace(/-/g, "");
  }

  const conversionDateTime =
    opts.conversionDateTime ??
    new Date().toISOString().replace("T", " ").replace(/\.\d{3}Z$/, "+00:00");

  const body = {
    conversions: [
      {
        gclid: opts.gclid,
        conversionAction: opts.conversionActionId.startsWith("customers/")
          ? opts.conversionActionId
          : `customers/${cid}/conversionActions/${opts.conversionActionId}`,
        conversionDateTime,
        conversionValue: opts.conversionValue,
        currencyCode: opts.currencyCode ?? "BRL",
        ...(opts.orderId ? { orderId: opts.orderId } : {}),
      },
    ],
    partialFailure: true,
    validateOnly: false,
  };

  const res = await fetch(
    `${ADS_API_BASE}/customers/${cid}:uploadClickConversions`,
    {
      method: "POST",
      headers,
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(15_000),
    },
  );
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`Google Ads uploadClickConversion: ${res.status} — ${text.slice(0, 200)}`);
  }
}
