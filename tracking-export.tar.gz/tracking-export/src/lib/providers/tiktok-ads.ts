/**
 * TikTok Marketing API client.
 * Docs: https://business-api.tiktok.com/portal/docs?id=1738373164380162
 *
 * OAuth flow:
 *   1. Redirect user para https://business-api.tiktok.com/portal/auth?app_id=XXX&state=YYY&redirect_uri=ZZZ
 *   2. TikTok redirect back com ?auth_code=XXX&state=YYY
 *   3. Trocar auth_code por access_token via POST /oauth2/access_token/
 *      Retorna access_token long-lived (sem expiração explícita) + advertiser_ids
 *   4. Salvar access_token criptografado
 *   5. Pra cada advertiser_id, criar uma AdAccount
 *
 * NOTA importante sobre o token:
 *   - TikTok retorna 1 access_token POR app + business center
 *   - Esse mesmo token funciona pra TODOS os advertisers (contas de anúncio) acessíveis
 *   - Diferente do Meta onde o token também é por usuário
 */

import { getTiktokApp } from "../platform-apps";

const API = "https://business-api.tiktok.com/open_api/v1.3";
const OAUTH = "https://business-api.tiktok.com/portal/auth";

/** Creds do app TikTok (DB → env fallback). Lança se não configurado. */
async function tiktokCreds(): Promise<{ appId: string; appSecret: string }> {
  const app = await getTiktokApp();
  if (!app) {
    throw new Error(
      "App TikTok não configurado. Configure em /admin01/apps (ou env TIKTOK_APP_ID/TIKTOK_APP_SECRET).",
    );
  }
  return { appId: app.appId, appSecret: app.appSecret };
}

function appUrl(): string {
  return process.env.NEXT_PUBLIC_APP_URL ?? "https://bravopay.club";
}

/** Monta a URL de OAuth do TikTok Business. */
export async function tiktokOAuthUrl(state: string): Promise<string> {
  const { appId } = await tiktokCreds();
  const params = new URLSearchParams({
    app_id: appId,
    state,
    redirect_uri: `${appUrl()}/api/oauth/tiktok/callback`,
    rid: "bravopay",
  });
  return `${OAUTH}?${params.toString()}`;
}

/** Troca o auth_code pelo access_token (long-lived). */
export async function exchangeCodeForToken(authCode: string): Promise<{
  accessToken: string;
  advertiserIds: string[];
}> {
  const { appId, appSecret } = await tiktokCreds();
  const res = await fetch(`${API}/oauth2/access_token/`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      app_id: appId,
      secret: appSecret,
      auth_code: authCode,
    }),
  });
  const data = await res.json();
  if (data.code !== 0) {
    throw new Error(`TikTok OAuth falhou: ${JSON.stringify(data)}`);
  }
  return {
    accessToken: data.data.access_token as string,
    advertiserIds: (data.data.advertiser_ids ?? []) as string[],
  };
}

/**
 * Headers padrão do TikTok Business API.
 * Sempre usa Access-Token (em vez de Authorization Bearer).
 */
function headers(accessToken: string): Record<string, string> {
  return {
    "Access-Token": accessToken,
    "Content-Type": "application/json",
  };
}

/**
 * GET no TikTok com RETRY no erro de QPS (code 40100 = "reaches the QPS
 * limit"). O app TikTok tem QPS baixo no report/list endpoints — sincronizar
 * varias contas/objetos estoura e TUDO falha. Backoff exponencial resolve.
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function ttGetJson(
  url: string,
  accessToken: string,
  maxRetries = 5,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
): Promise<any> {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  let last: any = {};
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    const res = await fetch(url, { headers: headers(accessToken) });
    const data = await res.json();
    last = data;
    // 40100 = QPS limit. Qualquer outro code (sucesso=0 ou erro real): devolve.
    if (data?.code !== 40100) return data;
    // backoff exponencial + JITTER aleatorio: de-correlaciona retries
    // simultaneos (Promise.all interno) pra nao re-colidir no QPS.
    await new Promise((r) =>
      setTimeout(r, 400 * Math.pow(2, attempt) + Math.floor(Math.random() * 600)),
    );
  }
  return last;
}

export type TiktokAdvertiserInfo = {
  advertiser_id: string;
  /** Antes era "advertiser_name", TikTok renomeou pra "name" em 2026.
   *  Mantive o alias `advertiser_name` opcional pra retrocompat com
   *  código antigo que lê da response. */
  name: string;
  advertiser_name?: string;
  company?: string;
  currency: string;
  status?: string;
  timezone?: string;
};

/** Lista detalhes dos advertisers (ad accounts) do TikTok. */
export async function listAdvertisers(
  accessToken: string,
  advertiserIds: string[],
): Promise<TiktokAdvertiserInfo[]> {
  if (advertiserIds.length === 0) return [];
  const url = new URL(`${API}/advertiser/info/`);
  url.searchParams.set("advertiser_ids", JSON.stringify(advertiserIds));
  // ⚠️ TikTok rejeitou `advertiser_name` em 2026 — renomearam pra `name`.
  // Lista válida atual: ['display_timezone', 'industry', 'cellphone_number',
  // 'status', 'role', 'owner_bc_id', 'advertiser_account_type', 'brand',
  // 'license_province', 'advertiser_id', 'description', 'license_city',
  // 'balance', 'timezone', 'company', 'create_time', ...] etc.
  url.searchParams.set(
    "fields",
    JSON.stringify([
      "advertiser_id",
      "name",
      "company",
      "currency",
      "status",
      "timezone",
    ]),
  );
  const data = await ttGetJson(url.toString(), accessToken);
  if (data.code !== 0) {
    throw new Error(`listAdvertisers: ${JSON.stringify(data)}`);
  }
  // Normaliza pra incluir advertiser_name como alias de name (retrocompat
  // com qualquer callsite antigo que ainda use advertiser_name).
  const list = (data.data?.list ?? []) as TiktokAdvertiserInfo[];
  return list.map((a) => ({
    ...a,
    advertiser_name: a.name,
  }));
}

/**
 * Pixel de TikTok cadastrado num advertiser. Permite o user escolher pelo
 * NOME ao montar mass campaigns (sem precisar do código).
 *
 * API: GET /pixel/list/?advertiser_id=<>
 * Docs: https://business-api.tiktok.com/portal/docs?id=1739585243264513
 */
export type TiktokPixelInfo = { id: string; name: string };

export async function listPixels(
  accessToken: string,
  advertiserId: string,
): Promise<TiktokPixelInfo[]> {
  const url = new URL(`${API}/pixel/list/`);
  url.searchParams.set("advertiser_id", advertiserId);
  const data = await ttGetJson(url.toString(), accessToken);
  if (data.code !== 0) {
    console.warn("[tiktok] listPixels failed:", data?.message);
    return [];
  }
  const list = (data.data?.pixels ?? []) as Array<{
    pixel_id?: string;
    pixel_code?: string;
    pixel_name: string;
  }>;
  return list.map((p) => ({
    id: p.pixel_id ?? p.pixel_code ?? "",
    name: p.pixel_name,
  }));
}

/** Lista todos os advertisers acessíveis pelo token (sem precisar dos IDs). */
export async function listAccessibleAdvertisers(
  accessToken: string,
): Promise<TiktokAdvertiserInfo[]> {
  const { appId, appSecret } = await tiktokCreds();
  const url = new URL(`${API}/oauth2/advertiser/get/`);
  url.searchParams.set("app_id", appId);
  url.searchParams.set("secret", appSecret);
  const data = await ttGetJson(url.toString(), accessToken);
  if (data.code !== 0) {
    throw new Error(`listAccessibleAdvertisers: ${JSON.stringify(data)}`);
  }
  // Esse endpoint ainda retorna `advertiser_name` (não foi renomeado em 2026,
  // só o `advertiser/info/`). Normaliza pra ter `name` também.
  const list = (data.data?.list ?? []) as Array<
    TiktokAdvertiserInfo & { advertiser_name?: string }
  >;
  return list.map((a) => ({
    ...a,
    name: a.name ?? a.advertiser_name ?? "",
    advertiser_name: a.advertiser_name ?? a.name,
  }));
}

export type TiktokCampaign = {
  campaign_id: string;
  campaign_name: string;
  status?: string;
  operation_status?: string;
  objective_type?: string;
  budget?: number;
  budget_mode?: string;
  modify_time?: string;
  create_time?: string;
};

/** Lista campanhas de um advertiser. */
export async function listCampaigns(
  accessToken: string,
  advertiserId: string,
): Promise<TiktokCampaign[]> {
  const url = new URL(`${API}/campaign/get/`);
  url.searchParams.set("advertiser_id", advertiserId);
  url.searchParams.set(
    "fields",
    JSON.stringify([
      "campaign_id",
      "campaign_name",
      "operation_status",
      "objective_type",
      "budget",
      "budget_mode",
      "modify_time",
      "create_time",
    ]),
  );
  url.searchParams.set("page_size", "200");
  const data = await ttGetJson(url.toString(), accessToken);
  if (data.code !== 0) {
    throw new Error(`tiktok listCampaigns: ${JSON.stringify(data)}`);
  }
  return (data.data?.list ?? []) as TiktokCampaign[];
}

export type TiktokAdgroup = {
  adgroup_id: string;
  adgroup_name: string;
  campaign_id: string;
  status?: string;
  operation_status?: string;
  budget?: number;
};

/** Lista adgroups (= adsets) de um advertiser, opcionalmente filtrado por campanha. */
export async function listAdgroups(
  accessToken: string,
  advertiserId: string,
  campaignId?: string,
): Promise<TiktokAdgroup[]> {
  const url = new URL(`${API}/adgroup/get/`);
  url.searchParams.set("advertiser_id", advertiserId);
  if (campaignId) {
    url.searchParams.set(
      "filtering",
      JSON.stringify({ campaign_ids: [campaignId] }),
    );
  }
  url.searchParams.set(
    "fields",
    JSON.stringify([
      "adgroup_id",
      "adgroup_name",
      "campaign_id",
      "operation_status",
      "budget",
    ]),
  );
  url.searchParams.set("page_size", "200");
  const data = await ttGetJson(url.toString(), accessToken);
  if (data.code !== 0) {
    throw new Error(`tiktok listAdgroups: ${JSON.stringify(data)}`);
  }
  return (data.data?.list ?? []) as TiktokAdgroup[];
}

export type TiktokAd = {
  ad_id: string;
  ad_name: string;
  adgroup_id: string;
  status?: string;
  operation_status?: string;
  /** Status de entrega/auditoria. Reprovado quando contém "DISAPPROVED"/"REJECT". */
  secondary_status?: string;
};

/** Lista ads de um advertiser, opcionalmente filtrado por adgroup. */
export async function listAds(
  accessToken: string,
  advertiserId: string,
  adgroupId?: string,
): Promise<TiktokAd[]> {
  const url = new URL(`${API}/ad/get/`);
  url.searchParams.set("advertiser_id", advertiserId);
  if (adgroupId) {
    url.searchParams.set(
      "filtering",
      JSON.stringify({ adgroup_ids: [adgroupId] }),
    );
  }
  url.searchParams.set(
    "fields",
    JSON.stringify([
      "ad_id",
      "ad_name",
      "adgroup_id",
      "operation_status",
      "secondary_status",
    ]),
  );
  url.searchParams.set("page_size", "200");
  const data = await ttGetJson(url.toString(), accessToken);
  if (data.code !== 0) {
    throw new Error(`tiktok listAds: ${JSON.stringify(data)}`);
  }
  return (data.data?.list ?? []) as TiktokAd[];
}

export type TiktokInsight = {
  spend?: number;
  impressions?: number;
  clicks?: number;
  ctr?: number;
  cpc?: number;
  cpm?: number;
};

/** Insights via /report/integrated/get/ */
export async function getInsights(
  accessToken: string,
  advertiserId: string,
  dataLevel: "AUCTION_CAMPAIGN" | "AUCTION_ADGROUP" | "AUCTION_AD",
  objectIdFieldName: "campaign_id" | "adgroup_id" | "ad_id",
  objectId: string,
  datePreset: "TODAY" | "YESTERDAY" | "LAST_7D" | "LAST_30D" = "TODAY",
): Promise<TiktokInsight | null> {
  const url = new URL(`${API}/report/integrated/get/`);
  url.searchParams.set("advertiser_id", advertiserId);
  url.searchParams.set("report_type", "BASIC");
  url.searchParams.set("data_level", dataLevel);
  url.searchParams.set(
    "dimensions",
    JSON.stringify([objectIdFieldName]),
  );
  url.searchParams.set(
    "metrics",
    JSON.stringify(["spend", "impressions", "clicks", "ctr", "cpc", "cpm"]),
  );
  url.searchParams.set(
    "filtering",
    JSON.stringify([
      {
        field_name: objectIdFieldName,
        filter_type: "IN",
        filter_value: JSON.stringify([objectId]),
      },
    ]),
  );
  url.searchParams.set("query_lifetime", "false");
  // TikTok usa date range — pra "TODAY" precisa de start_date/end_date
  const today = new Date().toISOString().slice(0, 10);
  url.searchParams.set("start_date", datePreset === "TODAY" ? today : computeStartDate(datePreset));
  url.searchParams.set("end_date", today);
  const data = await ttGetJson(url.toString(), accessToken);
  if (data.code !== 0) return null;
  const row = (data.data?.list ?? [])[0];
  if (!row) return null;
  const metrics = row.metrics ?? {};
  return {
    spend: Number(metrics.spend ?? 0),
    impressions: Number(metrics.impressions ?? 0),
    clicks: Number(metrics.clicks ?? 0),
    ctr: Number(metrics.ctr ?? 0),
    cpc: Number(metrics.cpc ?? 0),
    cpm: Number(metrics.cpm ?? 0),
  };
}

/**
 * Soma de spend num intervalo arbitrário pra um advertiser inteiro.
 * Faz 1 chamada cobrindo todas as campanhas. Retorna em unidade da moeda.
 */
export async function getInsightsForRange(
  accessToken: string,
  advertiserId: string,
  sinceISO: string,
  untilISO: string,
): Promise<TiktokInsight | null> {
  const url = new URL(`${API}/report/integrated/get/`);
  url.searchParams.set("advertiser_id", advertiserId);
  url.searchParams.set("report_type", "BASIC");
  url.searchParams.set("data_level", "AUCTION_ADVERTISER");
  url.searchParams.set("dimensions", JSON.stringify(["advertiser_id"]));
  url.searchParams.set(
    "metrics",
    JSON.stringify(["spend", "impressions", "clicks", "ctr", "cpc", "cpm"]),
  );
  url.searchParams.set("start_date", sinceISO);
  url.searchParams.set("end_date", untilISO);
  const data = await ttGetJson(url.toString(), accessToken);
  if (data.code !== 0) return null;
  const row = (data.data?.list ?? [])[0];
  if (!row) return null;
  const m = row.metrics ?? {};
  return {
    spend: Number(m.spend ?? 0),
    impressions: Number(m.impressions ?? 0),
    clicks: Number(m.clicks ?? 0),
    ctr: Number(m.ctr ?? 0),
    cpc: Number(m.cpc ?? 0),
    cpm: Number(m.cpm ?? 0),
  };
}

function computeStartDate(preset: string): string {
  const d = new Date();
  if (preset === "YESTERDAY") d.setDate(d.getDate() - 1);
  else if (preset === "LAST_7D") d.setDate(d.getDate() - 7);
  else if (preset === "LAST_30D") d.setDate(d.getDate() - 30);
  return d.toISOString().slice(0, 10);
}

/**
 * Insights de TODOS os objetos de um data_level (campaign/adgroup/ad) do
 * advertiser numa só chamada (paginada). Evita 1 report POR objeto, que com
 * o QPS baixo do TikTok deixava o gasto zerado/lento. Retorna Map id→insight.
 */
export async function getInsightsByLevel(
  accessToken: string,
  advertiserId: string,
  dataLevel: "AUCTION_CAMPAIGN" | "AUCTION_ADGROUP" | "AUCTION_AD",
  idField: "campaign_id" | "adgroup_id" | "ad_id",
  datePreset: "TODAY" | "YESTERDAY" | "LAST_7D" | "LAST_30D" = "TODAY",
): Promise<Map<string, TiktokInsight>> {
  const map = new Map<string, TiktokInsight>();
  const today = new Date().toISOString().slice(0, 10);
  const start = datePreset === "TODAY" ? today : computeStartDate(datePreset);
  let page = 1;
  let guard = 0;
  while (guard < 20) {
    guard++;
    const url = new URL(`${API}/report/integrated/get/`);
    url.searchParams.set("advertiser_id", advertiserId);
    url.searchParams.set("report_type", "BASIC");
    url.searchParams.set("data_level", dataLevel);
    url.searchParams.set("dimensions", JSON.stringify([idField]));
    url.searchParams.set(
      "metrics",
      JSON.stringify(["spend", "impressions", "clicks", "ctr", "cpc", "cpm"]),
    );
    url.searchParams.set("start_date", start);
    url.searchParams.set("end_date", today);
    url.searchParams.set("query_lifetime", "false");
    url.searchParams.set("page", String(page));
    url.searchParams.set("page_size", "200");
    const data = await ttGetJson(url.toString(), accessToken);
    if (data.code !== 0) break;
    const list = (data.data?.list ?? []) as Array<{
      dimensions?: Record<string, string>;
      metrics?: Record<string, string | number>;
    }>;
    for (const row of list) {
      const id = row.dimensions?.[idField];
      const m = row.metrics ?? {};
      if (id) {
        map.set(String(id), {
          spend: Number(m.spend ?? 0),
          impressions: Number(m.impressions ?? 0),
          clicks: Number(m.clicks ?? 0),
          ctr: Number(m.ctr ?? 0),
          cpc: Number(m.cpc ?? 0),
          cpm: Number(m.cpm ?? 0),
        });
      }
    }
    const pageInfo = data.data?.page_info as
      | { total_page?: number }
      | undefined;
    if (!pageInfo || page >= (pageInfo.total_page ?? 1)) break;
    page++;
  }
  return map;
}

/** Atualiza status (ENABLE/DISABLE) de um objeto. */
export async function updateObjectStatus(
  accessToken: string,
  advertiserId: string,
  objectKind: "campaign" | "adgroup" | "ad",
  objectId: string,
  status: "ACTIVE" | "PAUSED",
): Promise<void> {
  const endpoint =
    objectKind === "campaign"
      ? "campaign/status/update/"
      : objectKind === "adgroup"
        ? "adgroup/status/update/"
        : "ad/status/update/";
  const idField =
    objectKind === "campaign"
      ? "campaign_ids"
      : objectKind === "adgroup"
        ? "adgroup_ids"
        : "ad_ids";
  const operation = status === "ACTIVE" ? "ENABLE" : "DISABLE";

  const res = await fetch(`${API}/${endpoint}`, {
    method: "POST",
    headers: headers(accessToken),
    body: JSON.stringify({
      advertiser_id: advertiserId,
      [idField]: [objectId],
      operation_status: operation,
    }),
  });
  const data = await res.json();
  if (data.code !== 0) {
    throw new Error(`tiktok updateObjectStatus: ${JSON.stringify(data)}`);
  }
}

/** Ajusta budget de uma campanha (em micro-units: 1.00 = 100). */
export async function updateBudget(
  accessToken: string,
  advertiserId: string,
  campaignId: string,
  dailyBudgetCents: number,
): Promise<void> {
  // TikTok espera budget em unidade da moeda (decimal). Cents → unidade.
  const budgetInCurrency = dailyBudgetCents / 100;
  const res = await fetch(`${API}/campaign/update/`, {
    method: "POST",
    headers: headers(accessToken),
    body: JSON.stringify({
      advertiser_id: advertiserId,
      campaign_id: campaignId,
      budget: budgetInCurrency,
      budget_mode: "BUDGET_MODE_DAY",
    }),
  });
  const data = await res.json();
  if (data.code !== 0) {
    throw new Error(`tiktok updateBudget: ${JSON.stringify(data)}`);
  }
}

/** Moeda do advertiser (ISO, ex: "BRL", "CLP", "USD"). Best-effort. */
export async function getAdvertiserCurrency(
  accessToken: string,
  advertiserId: string,
): Promise<string | null> {
  const url = new URL(`${API}/advertiser/info/`);
  url.searchParams.set("advertiser_ids", JSON.stringify([advertiserId]));
  url.searchParams.set("fields", JSON.stringify(["currency"]));
  const data = await ttGetJson(url.toString(), accessToken);
  if (data.code !== 0) return null;
  const row = (data.data?.list ?? [])[0] as { currency?: string } | undefined;
  return row?.currency ?? null;
}

/** Renomeia uma campanha — POST /campaign/update/ {campaign_name}. */
export async function updateCampaignName(
  accessToken: string,
  advertiserId: string,
  campaignId: string,
  name: string,
): Promise<void> {
  const res = await fetch(`${API}/campaign/update/`, {
    method: "POST",
    headers: headers(accessToken),
    body: JSON.stringify({
      advertiser_id: advertiserId,
      campaign_id: campaignId,
      campaign_name: name,
    }),
  });
  const data = await res.json();
  if (data.code !== 0) {
    throw new Error(`tiktok updateCampaignName: ${JSON.stringify(data)}`);
  }
}

/** Renomeia um adgroup — POST /adgroup/update/ {adgroup_name}. */
export async function updateAdgroupName(
  accessToken: string,
  advertiserId: string,
  adgroupId: string,
  name: string,
): Promise<void> {
  const res = await fetch(`${API}/adgroup/update/`, {
    method: "POST",
    headers: headers(accessToken),
    body: JSON.stringify({
      advertiser_id: advertiserId,
      adgroup_id: adgroupId,
      adgroup_name: name,
    }),
  });
  const data = await res.json();
  if (data.code !== 0) {
    throw new Error(`tiktok updateAdgroupName: ${JSON.stringify(data)}`);
  }
}

/** Renomeia um ad — POST /ad/update/ {ad_name}. */
export async function updateAdName(
  accessToken: string,
  advertiserId: string,
  adId: string,
  name: string,
): Promise<void> {
  const res = await fetch(`${API}/ad/update/`, {
    method: "POST",
    headers: headers(accessToken),
    body: JSON.stringify({
      advertiser_id: advertiserId,
      ad_id: adId,
      ad_name: name,
    }),
  });
  const data = await res.json();
  if (data.code !== 0) {
    throw new Error(`tiktok updateAdName: ${JSON.stringify(data)}`);
  }
}

/** Ajusta o orçamento DIÁRIO de um adgroup (ABO — budget no conjunto). */
export async function updateAdgroupBudget(
  accessToken: string,
  advertiserId: string,
  adgroupId: string,
  dailyBudgetCents: number,
): Promise<void> {
  const budgetInCurrency = dailyBudgetCents / 100;
  const res = await fetch(`${API}/adgroup/update/`, {
    method: "POST",
    headers: headers(accessToken),
    body: JSON.stringify({
      advertiser_id: advertiserId,
      adgroup_id: adgroupId,
      budget: budgetInCurrency,
      budget_mode: "BUDGET_MODE_DAY",
    }),
  });
  const data = await res.json();
  if (data.code !== 0) {
    throw new Error(`tiktok updateAdgroupBudget: ${JSON.stringify(data)}`);
  }
}

/** True se o secondary_status indica anúncio REPROVADO. */
export function isRejectedStatus(secondaryStatus: string | undefined): boolean {
  if (!secondaryStatus) return false;
  const s = secondaryStatus.toUpperCase();
  return s.includes("DISAPPROVE") || s.includes("REJECT") || s.includes("DENIED");
}

/** Motivos de reprovação por ad (best-effort via /ad/review_info/).
 *  Se o endpoint mudar/falhar, retorna {} — o UI mostra só "Reprovado". */
export async function getAdRejectReasons(
  accessToken: string,
  advertiserId: string,
  adIds: string[],
): Promise<Record<string, string>> {
  if (adIds.length === 0) return {};
  try {
    const url = new URL(`${API}/ad/review_info/`);
    url.searchParams.set("advertiser_id", advertiserId);
    url.searchParams.set("ad_ids", JSON.stringify(adIds.slice(0, 100)));
    const res = await fetch(url.toString(), { headers: headers(accessToken) });
    const data = await res.json();
    if (data.code !== 0) return {};
    const list = (data.data?.list ?? data.data?.review_info ?? []) as Array<{
      ad_id?: string;
      reject_reason?: string;
      reject_reason_list?: string[];
      review_info?: { reject_reason?: string; reject_reason_list?: string[] };
    }>;
    const out: Record<string, string> = {};
    for (const r of list) {
      if (!r.ad_id) continue;
      const reasons =
        r.reject_reason_list ??
        r.review_info?.reject_reason_list ??
        (r.reject_reason
          ? [r.reject_reason]
          : r.review_info?.reject_reason
            ? [r.review_info.reject_reason]
            : []);
      if (reasons.length) out[r.ad_id] = reasons.join("; ").slice(0, 500);
    }
    return out;
  } catch {
    return {};
  }
}

/* ============================================================
 * CRIAÇÃO DE CAMPANHA (Subir Campanhas em Massa)
 * Docs: https://business-api.tiktok.com/portal/docs
 *
 * IMPORTANTE: tudo nasce PAUSED (operation_status: DISABLE) no nível
 * adgroup/ad — TikTok nao deixa setar status na campanha no create, mas
 * adgroup DISABLE = nada entrega = ZERO gasto ate o seller ativar.
 * ============================================================ */

/** POST helper que valida `code === 0` e devolve `data`. Erro carrega a
 *  mensagem exata do TikTok pra debug no resultado do job. */
async function ttCreatePost(
  accessToken: string,
  path: string,
  body: Record<string, unknown>,
): Promise<Record<string, unknown>> {
  const res = await fetch(`${API}/${path}`, {
    method: "POST",
    headers: headers(accessToken),
    body: JSON.stringify(body),
  });
  const data = await res.json();
  if (data.code !== 0) {
    throw new Error(
      `tiktok ${path} falhou: ${data.message || "erro"} (code ${data.code})`,
    );
  }
  return (data.data ?? {}) as Record<string, unknown>;
}

/** Cria campanha. Retorna campaign_id. */
export async function createCampaign(
  accessToken: string,
  advertiserId: string,
  opts: {
    name: string;
    objective: string; // ex "CONVERSIONS"
    budgetMode: string; // BUDGET_MODE_INFINITE | BUDGET_MODE_DAY | BUDGET_MODE_TOTAL
    budgetCents?: number | null;
  },
): Promise<string> {
  const body: Record<string, unknown> = {
    advertiser_id: advertiserId,
    campaign_name: opts.name,
    objective_type: opts.objective,
    budget_mode: opts.budgetMode,
  };
  if (opts.budgetMode !== "BUDGET_MODE_INFINITE" && opts.budgetCents) {
    body.budget = opts.budgetCents / 100;
  }
  const data = await ttCreatePost(accessToken, "campaign/create/", body);
  return String(data.campaign_id);
}

/** Resolve location_ids (TikTok usa IDs numéricos de região, NAO "BR").
 *  Mapeia country codes -> location_id consultando /tool/region/.
 *  Fallback: Brasil = "6252001"? NAO — TikTok tem ID proprio; por isso
 *  consultamos. Se a consulta falhar, lança erro claro. */
export async function getCountryLocationIds(
  accessToken: string,
  advertiserId: string,
  countryCodes: string[],
  objective: string,
): Promise<string[]> {
  const url = new URL(`${API}/tool/region/`);
  url.searchParams.set("advertiser_id", advertiserId);
  url.searchParams.set("objective_type", objective);
  url.searchParams.set("placements", JSON.stringify(["PLACEMENT_TIKTOK"]));
  const data = await ttGetJson(url.toString(), accessToken);
  if (data.code !== 0) {
    throw new Error(`tiktok tool/region falhou: ${data.message}`);
  }
  const regions = (data.data?.region_info ?? []) as Array<{
    location_id: number | string;
    region_code?: string;
    level?: string;
    area_type?: string;
  }>;
  const want = new Set(countryCodes.map((c) => c.toUpperCase()));
  const ids = regions
    .filter(
      (r) =>
        r.region_code &&
        want.has(r.region_code.toUpperCase()) &&
        (r.level === "COUNTRY" || r.area_type === "COUNTRY" || !r.level),
    )
    .map((r) => String(r.location_id));
  if (ids.length === 0) {
    throw new Error(
      `Nenhum location_id encontrado pros países ${countryCodes.join(",")} (objetivo ${objective})`,
    );
  }
  return ids;
}

/** Cria ad group (PAUSED). Retorna adgroup_id. */
export async function createAdgroup(
  accessToken: string,
  advertiserId: string,
  opts: {
    campaignId: string;
    name: string;
    locationIds: string[];
    budgetCents: number;
    budgetMode?: string; // BUDGET_MODE_DAY (default)
    scheduleStartTime?: string | null; // "YYYY-MM-DD HH:mm:ss"
    optimizationGoal: string; // ex "CONVERT"
    pixelId?: string | null;
    optimizationEvent?: string | null; // ex "ON_WEB_ORDER"
    placementType?: string;
    placements?: string[];
    ageGroups?: string[];
    genders?: string[];
  },
): Promise<string> {
  // schedule_start_time é OBRIGATÓRIO no TikTok (mesmo pra SCHEDULE_FROM_NOW).
  // Formato "YYYY-MM-DD HH:mm:ss". Default: ~5min no futuro.
  const startTime =
    opts.scheduleStartTime ||
    new Date(Date.now() + 5 * 60_000)
      .toISOString()
      .slice(0, 19)
      .replace("T", " ");
  const body: Record<string, unknown> = {
    advertiser_id: advertiserId,
    campaign_id: opts.campaignId,
    adgroup_name: opts.name,
    promotion_type: "WEBSITE",
    placement_type: opts.placementType ?? "PLACEMENT_TYPE_AUTOMATIC",
    location_ids: opts.locationIds,
    budget_mode: opts.budgetMode ?? "BUDGET_MODE_DAY",
    budget: opts.budgetCents / 100,
    schedule_type: opts.scheduleStartTime ? "SCHEDULE_START_END" : "SCHEDULE_FROM_NOW",
    schedule_start_time: startTime,
    optimization_goal: opts.optimizationGoal,
    billing_event: "OCPM",
    bid_type: "BID_TYPE_NO_BID",
    // PAUSED — nada entrega ate o seller ativar manualmente no TikTok
    operation_status: "DISABLE",
  };
  if (opts.placementType === "PLACEMENT_TYPE_NORMAL" && opts.placements?.length) {
    body.placements = opts.placements;
  }
  if (opts.pixelId) body.pixel_id = opts.pixelId;
  if (opts.optimizationEvent) body.optimization_event = opts.optimizationEvent;
  if (opts.ageGroups?.length) body.age_groups = opts.ageGroups;
  if (opts.genders?.length && !opts.genders.includes("all")) {
    body.gender = opts.genders[0] === "male" ? "GENDER_MALE" : "GENDER_FEMALE";
  }
  const data = await ttCreatePost(accessToken, "adgroup/create/", body);
  return String(data.adgroup_id);
}

/** Faz upload de vídeo por URL. Retorna video_id. */
export async function uploadVideoByUrl(
  accessToken: string,
  advertiserId: string,
  videoUrl: string,
  fileName: string,
): Promise<string> {
  const data = await ttCreatePost(accessToken, "file/video/ad/upload/", {
    advertiser_id: advertiserId,
    upload_type: "UPLOAD_BY_URL",
    video_url: videoUrl,
    file_name: fileName.slice(0, 100),
  });
  const list = (data as { list?: Array<{ video_id?: string }> }).list ??
    (data as unknown as Array<{ video_id?: string }>);
  const first = Array.isArray(list) ? list[0] : undefined;
  const videoId = first?.video_id;
  if (!videoId) throw new Error("tiktok upload de vídeo sem video_id no retorno");
  return videoId;
}

/** Pega um cover sugerido pro vídeo (TikTok exige image_id de capa). */
export async function suggestVideoCover(
  accessToken: string,
  advertiserId: string,
  videoId: string,
): Promise<string | null> {
  try {
    const url = new URL(`${API}/file/video/suggestcover/`);
    url.searchParams.set("advertiser_id", advertiserId);
    url.searchParams.set("video_id", videoId);
    const res = await fetch(url.toString(), { headers: headers(accessToken) });
    const data = await res.json();
    if (data.code !== 0) return null;
    const list = (data.data?.list ?? []) as Array<{ id?: string }>;
    return list[0]?.id ?? null;
  } catch {
    return null;
  }
}

/** Pega a primeira identity CUSTOMIZED_USER existente ou cria uma. */
export async function getOrCreateIdentity(
  accessToken: string,
  advertiserId: string,
  displayName: string,
): Promise<{ identityId: string; identityType: string }> {
  // 1. tenta listar existentes
  try {
    const url = new URL(`${API}/identity/get/`);
    url.searchParams.set("advertiser_id", advertiserId);
    const res = await fetch(url.toString(), { headers: headers(accessToken) });
    const data = await res.json();
    if (data.code === 0) {
      const list = (data.data?.identity_list ?? []) as Array<{
        identity_id?: string;
        identity_type?: string;
      }>;
      if (list[0]?.identity_id) {
        return {
          identityId: list[0].identity_id,
          identityType: list[0].identity_type ?? "CUSTOMIZED_USER",
        };
      }
    }
  } catch {
    // segue pro create
  }
  // 2. cria uma CUSTOMIZED_USER
  const created = await ttCreatePost(accessToken, "identity/create/", {
    advertiser_id: advertiserId,
    identity_type: "CUSTOMIZED_USER",
    display_name: displayName.slice(0, 60),
  });
  return {
    identityId: String(created.identity_id),
    identityType: "CUSTOMIZED_USER",
  };
}

/** Cria o anúncio (creative) dentro do adgroup. Retorna ad_ids.
 *  Dois modos:
 *   - VÍDEO normal: passa videoId (+ coverImageId) — vídeo subido via upload.
 *   - SPARK AD: passa tiktokItemId (post orgânico já existente) + identity
 *     TT_USER do dono do post. Não sobe vídeo. */
export async function createAd(
  accessToken: string,
  advertiserId: string,
  opts: {
    adgroupId: string;
    adName: string;
    identityId: string;
    identityType: string;
    adText: string;
    callToAction: string;
    landingUrl: string;
    /** modo vídeo */
    videoId?: string | null;
    coverImageId?: string | null;
    /** modo SPARK — id do post orgânico do TikTok */
    tiktokItemId?: string | null;
  },
): Promise<string[]> {
  const creative: Record<string, unknown> = {
    ad_name: opts.adName,
    identity_id: opts.identityId,
    identity_type: opts.identityType,
    ad_format: "SINGLE_VIDEO",
    ad_text: opts.adText.slice(0, 100),
    call_to_action: opts.callToAction,
    landing_page_url: opts.landingUrl,
    operation_status: "DISABLE",
  };
  if (opts.tiktokItemId) {
    // SPARK AD: usa o post orgânico existente (não sobe vídeo).
    creative.tiktok_item_id = opts.tiktokItemId;
  } else {
    creative.video_id = opts.videoId;
    if (opts.coverImageId) creative.image_ids = [opts.coverImageId];
  }
  const data = await ttCreatePost(accessToken, "ad/create/", {
    advertiser_id: advertiserId,
    adgroup_id: opts.adgroupId,
    creatives: [creative],
  });
  const list = (data.ad_ids ?? data.creatives ?? []) as unknown;
  if (Array.isArray(list)) {
    return list.map((x) =>
      typeof x === "string" ? x : String((x as { ad_id?: string }).ad_id ?? ""),
    ).filter(Boolean);
  }
  return [];
}
