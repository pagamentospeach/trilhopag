/**
 * Meta Marketing API client.
 * Docs: https://developers.facebook.com/docs/marketing-apis/
 *
 * OAuth flow:
 *   1. Redirect user to https://www.facebook.com/v18.0/dialog/oauth
 *      com client_id + redirect_uri + scope + state
 *   2. FB redirect back com ?code=XYZ
 *   3. Trocar code por short-lived token (1h)
 *   4. Trocar short-lived por long-lived (60 dias)
 *   5. Salvar long-lived (criptografado) + refresh diário antes de expirar
 *
 * Permissões necessárias: ads_read, ads_management, business_management
 */

import { getMetaApp } from "../platform-apps";

const GRAPH = "https://graph.facebook.com/v19.0";
const OAUTH = "https://www.facebook.com/v19.0/dialog/oauth";

export const META_SCOPES = [
  "ads_read",
  "ads_management",
  "business_management",
  "email",
  "public_profile",
].join(",");

/** Creds do app Meta (DB → env fallback). Lança se não configurado. */
async function metaCreds(): Promise<{
  appId: string;
  appSecret: string;
  configId: string | null;
}> {
  const app = await getMetaApp();
  if (!app) {
    throw new Error(
      "App Meta não configurado. Configure em /admin01/apps (ou env META_APP_ID/META_APP_SECRET).",
    );
  }
  return { appId: app.appId, appSecret: app.appSecret, configId: app.configId };
}

function appUrl(): string {
  return process.env.NEXT_PUBLIC_APP_URL ?? "https://bravopay.club";
}

export async function metaOAuthUrl(state: string): Promise<string> {
  const { appId, configId } = await metaCreds();
  const params = new URLSearchParams({
    client_id: appId,
    redirect_uri: `${appUrl()}/api/oauth/meta/callback`,
    response_type: "code",
    state,
  });
  // Facebook Login for Business: usa config_id em vez de scope.
  // As permissões são definidas dentro da Login Configuration no FB Developers.
  if (configId) {
    params.set("config_id", configId);
  } else {
    // Fallback pra Facebook Login clássico (com scopes na URL)
    params.set("scope", META_SCOPES);
  }
  return `${OAUTH}?${params.toString()}`;
}

export async function exchangeCodeForToken(
  code: string,
): Promise<{ accessToken: string; expiresInSec: number }> {
  const { appId, appSecret } = await metaCreds();
  const url = new URL(`${GRAPH}/oauth/access_token`);
  url.searchParams.set("client_id", appId);
  url.searchParams.set("client_secret", appSecret);
  url.searchParams.set("redirect_uri", `${appUrl()}/api/oauth/meta/callback`);
  url.searchParams.set("code", code);
  const res = await fetch(url.toString());
  const data = await res.json();
  if (!res.ok) {
    throw new Error(
      `Meta OAuth code exchange falhou: ${JSON.stringify(data)}`,
    );
  }
  return {
    accessToken: data.access_token as string,
    expiresInSec: Number(data.expires_in ?? 3600),
  };
}

export async function exchangeForLongLivedToken(
  shortToken: string,
): Promise<{ accessToken: string; expiresInSec: number }> {
  const { appId, appSecret } = await metaCreds();
  const url = new URL(`${GRAPH}/oauth/access_token`);
  url.searchParams.set("grant_type", "fb_exchange_token");
  url.searchParams.set("client_id", appId);
  url.searchParams.set("client_secret", appSecret);
  url.searchParams.set("fb_exchange_token", shortToken);
  const res = await fetch(url.toString());
  const data = await res.json();
  if (!res.ok) {
    throw new Error(
      `Meta long-lived exchange falhou: ${JSON.stringify(data)}`,
    );
  }
  return {
    accessToken: data.access_token as string,
    expiresInSec: Number(data.expires_in ?? 60 * 24 * 3600),
  };
}

export type MetaAdAccountInfo = {
  id: string; // "act_1234567890"
  account_id: string;
  name: string;
  currency: string;
  account_status: number;
  business_name?: string;
};

/**
 * Pixel cadastrado em uma ad account Meta. Permite o user escolher
 * pelo NOME ao montar mass campaigns (sem precisar do ID manual).
 *
 * API: GET /act_<account_id>/adspixels?fields=id,name
 * Docs: https://developers.facebook.com/docs/marketing-api/reference/ads-pixel/
 */
export type MetaPixelInfo = { id: string; name: string };

export async function listAdsPixels(
  accessToken: string,
  /** Aceita "act_123..." ou só "123..." — normaliza pra "act_" */
  accountId: string,
): Promise<MetaPixelInfo[]> {
  const normalized = accountId.startsWith("act_") ? accountId : `act_${accountId}`;
  const url = new URL(`${GRAPH}/${normalized}/adspixels`);
  url.searchParams.set("fields", "id,name");
  url.searchParams.set("access_token", accessToken);
  url.searchParams.set("limit", "100");
  const res = await fetch(url.toString());
  const data = await res.json();
  if (!res.ok) {
    // Algumas contas não têm permissão pra listar pixels — não é fatal
    console.warn("[meta] listAdsPixels failed:", data?.error?.message);
    return [];
  }
  return (data.data ?? []).map((p: { id: string; name: string }) => ({
    id: p.id,
    name: p.name,
  }));
}

export async function listAdAccounts(
  accessToken: string,
): Promise<MetaAdAccountInfo[]> {
  const url = new URL(`${GRAPH}/me/adaccounts`);
  url.searchParams.set(
    "fields",
    "id,account_id,name,currency,account_status,business_name",
  );
  url.searchParams.set("access_token", accessToken);
  url.searchParams.set("limit", "100");
  const res = await fetch(url.toString());
  const data = await res.json();
  if (!res.ok) {
    throw new Error(`listAdAccounts: ${JSON.stringify(data)}`);
  }
  return data.data ?? [];
}

export async function getMe(
  accessToken: string,
): Promise<{ id: string; name: string }> {
  const res = await fetch(
    `${GRAPH}/me?fields=id,name&access_token=${encodeURIComponent(accessToken)}`,
  );
  const data = await res.json();
  if (!res.ok) throw new Error(`getMe: ${JSON.stringify(data)}`);
  return { id: data.id, name: data.name };
}

export type MetaCampaign = {
  id: string;
  name: string;
  status: string;
  effective_status?: string;
  objective?: string;
  daily_budget?: string;
  lifetime_budget?: string;
  updated_time?: string;
  created_time?: string;
};

export async function listCampaigns(
  accessToken: string,
  adAccountId: string,
): Promise<MetaCampaign[]> {
  const url = new URL(`${GRAPH}/${adAccountId}/campaigns`);
  url.searchParams.set(
    "fields",
    "id,name,status,effective_status,objective,daily_budget,lifetime_budget,updated_time,created_time",
  );
  url.searchParams.set("limit", "200");
  url.searchParams.set("access_token", accessToken);
  const res = await fetch(url.toString());
  const data = await res.json();
  if (!res.ok) throw new Error(`listCampaigns: ${JSON.stringify(data)}`);
  return data.data ?? [];
}

export type MetaAdset = {
  id: string;
  name: string;
  status: string;
  campaign_id: string;
  daily_budget?: string;
};

export async function listAdsets(
  accessToken: string,
  campaignId: string,
): Promise<MetaAdset[]> {
  const url = new URL(`${GRAPH}/${campaignId}/adsets`);
  url.searchParams.set("fields", "id,name,status,campaign_id,daily_budget");
  url.searchParams.set("limit", "200");
  url.searchParams.set("access_token", accessToken);
  const res = await fetch(url.toString());
  const data = await res.json();
  if (!res.ok) throw new Error(`listAdsets: ${JSON.stringify(data)}`);
  return data.data ?? [];
}

export type MetaAd = {
  id: string;
  name: string;
  status: string;
  adset_id: string;
};

export async function listAds(
  accessToken: string,
  adsetId: string,
): Promise<MetaAd[]> {
  const url = new URL(`${GRAPH}/${adsetId}/ads`);
  url.searchParams.set("fields", "id,name,status,adset_id");
  url.searchParams.set("limit", "200");
  url.searchParams.set("access_token", accessToken);
  const res = await fetch(url.toString());
  const data = await res.json();
  if (!res.ok) throw new Error(`listAds: ${JSON.stringify(data)}`);
  return data.data ?? [];
}

export type MetaInsight = {
  spend?: string;
  impressions?: string;
  clicks?: string;
  ctr?: string;
  cpc?: string;
  cpm?: string;
};

/** Pega insights de gasto/impressões/cliques pra um objeto (campaign/adset/ad). */
export async function getInsights(
  accessToken: string,
  objectId: string,
  datePreset: string = "today",
): Promise<MetaInsight | null> {
  const url = new URL(`${GRAPH}/${objectId}/insights`);
  url.searchParams.set("fields", "spend,impressions,clicks,ctr,cpc,cpm");
  url.searchParams.set("date_preset", datePreset);
  url.searchParams.set("access_token", accessToken);
  const res = await fetch(url.toString());
  const data = await res.json();
  if (!res.ok) {
    // Insights pode retornar 400 se o objeto não rodou ainda — não é erro fatal
    return null;
  }
  return (data.data ?? [])[0] ?? null;
}

/**
 * Insights de TODOS os objetos de um nível (campaign/adset/ad) da conta numa
 * ÚNICA chamada (com paginação). ISSO EVITA RATE LIMIT: antes fazíamos 1
 * chamada de insights POR objeto (centenas), o que estourava o limite da Meta
 * (code 17 "User request limit reached") e zerava o gasto. Agora são ~3
 * chamadas por conta. Retorna um Map id→insight.
 */
export async function getInsightsByLevel(
  accessToken: string,
  adAccountId: string,
  level: "campaign" | "adset" | "ad",
  datePreset: string = "today",
): Promise<Map<string, MetaInsight>> {
  const idField =
    level === "campaign"
      ? "campaign_id"
      : level === "adset"
        ? "adset_id"
        : "ad_id";
  const map = new Map<string, MetaInsight>();

  const first = new URL(`${GRAPH}/${adAccountId}/insights`);
  first.searchParams.set("level", level);
  first.searchParams.set(
    "fields",
    `${idField},spend,impressions,clicks,ctr,cpc,cpm`,
  );
  first.searchParams.set("date_preset", datePreset);
  first.searchParams.set("limit", "500");
  first.searchParams.set("access_token", accessToken);

  let next: string | null = first.toString();
  let guard = 0;
  while (next && guard < 20) {
    guard++;
    const res = await fetch(next);
    const data: {
      data?: Array<MetaInsight & Record<string, string>>;
      paging?: { next?: string };
    } = await res.json();
    if (!res.ok) break;
    for (const row of data.data ?? []) {
      const id = row[idField];
      if (id) map.set(String(id), row);
    }
    next = data.paging?.next ?? null;
  }
  return map;
}

/**
 * Soma de spend pra um intervalo arbitrário de datas (YYYY-MM-DD). Usa
 * insights no nível da ad account — 1 chamada cobre todas as campanhas.
 * Retorna em centavos da moeda (BRL geralmente).
 */
export async function getInsightsForRange(
  accessToken: string,
  adAccountId: string,
  sinceISO: string,
  untilISO: string,
): Promise<MetaInsight | null> {
  const url = new URL(`${GRAPH}/${adAccountId}/insights`);
  url.searchParams.set("fields", "spend,impressions,clicks,ctr,cpc,cpm");
  url.searchParams.set(
    "time_range",
    JSON.stringify({ since: sinceISO, until: untilISO }),
  );
  url.searchParams.set("access_token", accessToken);
  const res = await fetch(url.toString());
  const data = await res.json();
  if (!res.ok) return null;
  return (data.data ?? [])[0] ?? null;
}

/** Renomeia um objeto (campaign/adset/ad) — POST /{id} {name}. */
export async function updateObjectName(
  accessToken: string,
  objectId: string,
  name: string,
): Promise<void> {
  const url = new URL(`${GRAPH}/${objectId}`);
  url.searchParams.set("access_token", accessToken);
  const res = await fetch(url.toString(), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name }),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(`updateObjectName: ${JSON.stringify(data)}`);
  }
}

/** Moeda da conta de anúncio (ISO, ex: "BRL", "USD"). Best-effort. */
export async function getAccountCurrency(
  accessToken: string,
  adAccountId: string,
): Promise<string | null> {
  const url = new URL(`${GRAPH}/${adAccountId}`);
  url.searchParams.set("fields", "currency");
  url.searchParams.set("access_token", accessToken);
  const res = await fetch(url.toString());
  const data = await res.json();
  if (!res.ok) return null;
  return typeof data.currency === "string" ? data.currency : null;
}

/** Atualiza status de um objeto (campaign/adset/ad). PAUSED ou ACTIVE. */
export async function updateObjectStatus(
  accessToken: string,
  objectId: string,
  status: "ACTIVE" | "PAUSED",
): Promise<void> {
  const url = new URL(`${GRAPH}/${objectId}`);
  url.searchParams.set("access_token", accessToken);
  const res = await fetch(url.toString(), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ status }),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(`updateObjectStatus: ${JSON.stringify(data)}`);
  }
}

/** Ajusta orçamento (apenas daily_budget; em cents — Meta usa unidade da moeda, ajuste se BRL). */
export async function updateBudget(
  accessToken: string,
  objectId: string,
  dailyBudgetCents: number,
): Promise<void> {
  const url = new URL(`${GRAPH}/${objectId}`);
  url.searchParams.set("access_token", accessToken);
  const res = await fetch(url.toString(), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ daily_budget: dailyBudgetCents }),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(`updateBudget: ${JSON.stringify(data)}`);
  }
}
