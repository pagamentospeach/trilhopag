/**
 * UTMify dispatcher.
 * Docs: POST https://api.utmify.com.br/api-credentials/orders
 * Header: x-api-token
 */

import { prisma } from "./prisma";

const UTMIFY_URL = "https://api.utmify.com.br/api-credentials/orders";

type Status = "waiting_payment" | "paid" | "refused" | "refunded" | "chargedback";

type PaymentMethod = "credit_card" | "boleto" | "pix" | "paypal" | "free_price";

function toUTC(date: Date | null | undefined): string | null {
  if (!date) return null;
  const d = new Date(date);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}`;
}

function mapMethod(method: string): PaymentMethod {
  const m = method.toUpperCase();
  if (m === "PIX") return "pix";
  if (m === "CARD") return "credit_card";
  if (m === "BOLETO") return "boleto";
  return "pix";
}

function mapStatus(status: string): Status {
  const s = status.toUpperCase();
  if (s === "PAID") return "paid";
  if (s === "REFUNDED") return "refunded";
  if (s === "CHARGEBACK") return "chargedback";
  if (s === "FAILED" || s === "CANCELED" || s === "EXPIRED") return "refused";
  return "waiting_payment";
}

export type DispatchUtmifyInput = {
  userId: string;
  transaction: {
    id: string;
    productId: string;
    amountCents: number;
    feeCents: number;
    netCents: number;
    currency: string;
    method: string;
    status: string;
    customerEmail: string;
    customerName: string | null;
    customerPhone: string | null;
    customerCpf: string | null;
    customerIp: string | null;
    utmSource: string | null;
    utmCampaign: string | null;
    utmMedium: string | null;
    utmContent: string | null;
    utmTerm: string | null;
    createdAt: Date;
    paidAt: Date | null;
    refundedAt: Date | null;
  };
  product: { id: string; name: string };
};

export async function dispatchUtmify(input: DispatchUtmifyInput): Promise<{
  ok: boolean;
  status?: number;
  body?: unknown;
  skipped?: string;
}> {
  const config = await prisma.utmifyConfig.findUnique({
    where: { userId: input.userId },
  });
  if (!config || !config.active) {
    return { ok: false, skipped: "not_configured" };
  }

  // Filtro por produto: se enabledProductIds tem itens, só envia para os listados.
  // Se estiver vazio, envia para TODOS (back-compat).
  if (
    config.enabledProductIds &&
    config.enabledProductIds.length > 0 &&
    !config.enabledProductIds.includes(input.product.id)
  ) {
    return { ok: false, skipped: "product_not_enabled" };
  }

  const t = input.transaction;
  const payload = {
    orderId: t.id,
    platform: config.platform || "BravoPay",
    paymentMethod: mapMethod(t.method),
    status: mapStatus(t.status),
    createdAt: toUTC(t.createdAt),
    approvedDate: toUTC(t.paidAt),
    refundedAt: toUTC(t.refundedAt),
    customer: {
      name: t.customerName ?? "Cliente",
      email: t.customerEmail,
      phone: t.customerPhone,
      document: t.customerCpf,
      country: "BR",
      ip: t.customerIp ?? undefined,
    },
    products: [
      {
        id: input.product.id,
        name: input.product.name,
        planId: null,
        planName: null,
        quantity: 1,
        priceInCents: t.amountCents,
      },
    ],
    trackingParameters: {
      src: null,
      sck: null,
      utm_source: t.utmSource,
      utm_campaign: t.utmCampaign,
      utm_medium: t.utmMedium,
      utm_content: t.utmContent,
      utm_term: t.utmTerm,
    },
    commission: {
      totalPriceInCents: t.amountCents,
      gatewayFeeInCents: t.feeCents,
      userCommissionInCents: t.netCents,
      ...(t.currency !== "BRL" ? { currency: t.currency } : {}),
    },
  };

  try {
    const res = await fetch(UTMIFY_URL, {
      method: "POST",
      headers: {
        "x-api-token": config.apiToken,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(10000),
    });
    const body = await res.json().catch(() => ({}));
    return { ok: res.ok, status: res.status, body };
  } catch (e) {
    return {
      ok: false,
      body: { error: e instanceof Error ? e.message : "network" },
    };
  }
}
