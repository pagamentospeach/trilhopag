import { ShieldAlert } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { requireUserId } from "@/lib/auth-helpers";
import { ApelacaoClient } from "./client";

export const dynamic = "force-dynamic";

/**
 * Apelação em Massa — lista os anúncios REPROVADOS (capturados no sync via
 * secondary_status do TikTok) com o motivo, deixa o seller selecionar vários
 * e abrir a tela de apelação no TikTok em massa (deep-link por advertiser).
 *
 * NOTA: o TikTok não expõe API de apelação (é só na UI do Ads Manager), então
 * o gateway centraliza + leva o seller direto pro botão de apelar.
 */
export default async function ApelacaoPage() {
  const userId = await requireUserId();

  const rejected = await prisma.ad.findMany({
    where: {
      OR: [
        { secondaryStatus: { contains: "DISAPPROVE", mode: "insensitive" } },
        { secondaryStatus: { contains: "REJECT", mode: "insensitive" } },
        { secondaryStatus: { contains: "DENIED", mode: "insensitive" } },
      ],
      adset: { campaign: { adAccount: { userId } } },
    },
    select: {
      id: true,
      externalId: true,
      name: true,
      secondaryStatus: true,
      rejectReason: true,
      adset: {
        select: {
          campaign: {
            select: {
              name: true,
              adAccount: {
                select: { platform: true, accountId: true, accountName: true },
              },
            },
          },
        },
      },
    },
    orderBy: { updatedAt: "desc" },
    take: 300,
  });

  const ads = rejected.map((a) => ({
    id: a.id,
    externalId: a.externalId,
    name: a.name,
    reason: a.rejectReason,
    campaignName: a.adset.campaign.name,
    platform: a.adset.campaign.adAccount.platform,
    advertiserId: a.adset.campaign.adAccount.accountId,
    accountName: a.adset.campaign.adAccount.accountName,
  }));

  return (
    <div className="max-w-5xl space-y-6">
      <header>
        <h1 className="flex items-center gap-2 text-2xl font-semibold text-white">
          <ShieldAlert className="size-5 text-amber-400" />
          Apelação em Massa
        </h1>
        <p className="mt-1 text-sm text-zinc-400 max-w-2xl">
          Anúncios reprovados nas suas contas. Selecione e abra a apelação no
          TikTok em massa. (O TikTok só permite apelar pela interface deles — o
          gateway centraliza e te leva direto pro botão.)
        </p>
      </header>

      <ApelacaoClient ads={ads} />
    </div>
  );
}
