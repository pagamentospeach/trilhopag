"use client";

import { useState, useMemo } from "react";
import { ExternalLink, ShieldAlert, CheckSquare, Square, Info } from "lucide-react";

type RejectedAd = {
  id: string;
  externalId: string;
  name: string;
  reason: string | null;
  campaignName: string;
  platform: string;
  advertiserId: string;
  accountName: string;
};

/** Monta o link do Ads Manager (onde fica o botão de apelar) por plataforma. */
function appealUrl(platform: string, advertiserId: string): string {
  if (platform === "meta") {
    return `https://business.facebook.com/adsmanager/manage/ads?act=${advertiserId.replace(/^act_/, "")}`;
  }
  // TikTok: abre a tela de anúncios do advertiser (filtra reprovados + Appeal)
  return `https://ads.tiktok.com/i18n/perf/ad?aadvid=${advertiserId}`;
}

export function ApelacaoClient({ ads }: { ads: RejectedAd[] }) {
  const [selected, setSelected] = useState<Set<string>>(new Set());

  // Agrupa por conta
  const groups = useMemo(() => {
    const m = new Map<string, { accountName: string; platform: string; advertiserId: string; ads: RejectedAd[] }>();
    for (const a of ads) {
      const key = `${a.platform}:${a.advertiserId}`;
      if (!m.has(key))
        m.set(key, { accountName: a.accountName, platform: a.platform, advertiserId: a.advertiserId, ads: [] });
      m.get(key)!.ads.push(a);
    }
    return Array.from(m.values());
  }, [ads]);

  function toggle(id: string) {
    setSelected((prev) => {
      const n = new Set(prev);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });
  }

  function toggleAll() {
    setSelected((prev) =>
      prev.size === ads.length ? new Set() : new Set(ads.map((a) => a.id)),
    );
  }

  function openAppeals() {
    // Abre 1 aba por advertiser ÚNICO dos selecionados (evita 50 abas).
    const advertisers = new Map<string, { platform: string; advertiserId: string }>();
    for (const a of ads) {
      if (selected.has(a.id)) {
        advertisers.set(`${a.platform}:${a.advertiserId}`, {
          platform: a.platform,
          advertiserId: a.advertiserId,
        });
      }
    }
    if (advertisers.size === 0) return;
    for (const { platform, advertiserId } of advertisers.values()) {
      window.open(appealUrl(platform, advertiserId), "_blank", "noopener,noreferrer");
    }
  }

  if (ads.length === 0) {
    return (
      <div className="rounded-2xl border border-white/[0.08] bg-white/[0.02] px-5 py-12 text-center">
        <ShieldAlert className="mx-auto size-8 text-zinc-600" />
        <p className="mt-3 text-sm text-zinc-300">Nenhum anúncio reprovado.</p>
        <p className="text-xs text-zinc-500">
          Sincronize suas contas na aba <strong>Integrações</strong> pra atualizar
          o status de reprovação.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Barra de ações */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-white/[0.08] bg-white/[0.02] px-4 py-3">
        <button
          type="button"
          onClick={toggleAll}
          className="inline-flex items-center gap-2 text-sm text-zinc-300 hover:text-white"
        >
          {selected.size === ads.length ? (
            <CheckSquare className="size-4 text-amber-400" />
          ) : (
            <Square className="size-4" />
          )}
          {selected.size === ads.length ? "Desmarcar todos" : "Selecionar todos"}
          <span className="text-zinc-500">({selected.size}/{ads.length})</span>
        </button>
        <button
          type="button"
          onClick={openAppeals}
          disabled={selected.size === 0}
          className="inline-flex items-center gap-2 rounded-lg bg-amber-400 px-4 py-2 text-sm font-semibold text-black hover:bg-amber-300 transition disabled:opacity-40"
        >
          <ExternalLink className="size-4" />
          Abrir no TikTok pra apelar ({selected.size})
        </button>
      </div>

      <div className="flex items-start gap-2 rounded-lg border border-blue-400/20 bg-blue-400/[0.04] px-3 py-2 text-[11px] text-blue-200/80">
        <Info className="size-3.5 shrink-0 mt-0.5" />
        <span>
          Ao abrir, o TikTok pode pedir pra permitir pop-ups. Lá, filtre por
          “Reprovado” e clique em <strong>Appeal</strong> — abre 1 aba por conta.
        </span>
      </div>

      {/* Grupos por conta */}
      {groups.map((g) => (
        <div
          key={`${g.platform}:${g.advertiserId}`}
          className="rounded-2xl border border-white/[0.08] bg-white/[0.02] overflow-hidden"
        >
          <div className="flex items-center justify-between border-b border-white/[0.06] px-4 py-2.5">
            <p className="text-sm font-medium text-white">
              {g.accountName}{" "}
              <span className="text-[10px] uppercase text-zinc-500">{g.platform}</span>
            </p>
            <span className="text-[11px] text-amber-300">{g.ads.length} reprovado(s)</span>
          </div>
          <div className="divide-y divide-white/[0.04]">
            {g.ads.map((a) => (
              <label
                key={a.id}
                className="flex cursor-pointer items-start gap-3 px-4 py-3 hover:bg-white/[0.02]"
              >
                <input
                  type="checkbox"
                  checked={selected.has(a.id)}
                  onChange={() => toggle(a.id)}
                  className="mt-0.5 size-4 accent-amber-400"
                />
                <div className="min-w-0 flex-1">
                  <p className="text-sm text-white truncate">{a.name}</p>
                  <p className="text-[11px] text-zinc-500 truncate">
                    {a.campaignName} · ad {a.externalId}
                  </p>
                  {a.reason && (
                    <p className="mt-1 text-[11px] text-red-300/90">{a.reason}</p>
                  )}
                </div>
              </label>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
