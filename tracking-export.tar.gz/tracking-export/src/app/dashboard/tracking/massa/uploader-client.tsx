"use client";

import { useMemo, useState, useTransition } from "react";
import {
  Music2,
  Save,
  Trash2,
  Rocket,
  CheckCircle2,
  Loader2,
  AlertCircle,
  Layers,
  FolderTree,
  Megaphone,
  ChevronDown,
  ChevronRight,
  Target,
  Users,
  Sparkles,
  Image as ImageIcon,
  Globe2,
  Plus,
} from "lucide-react";
import {
  saveMassCampaignTemplate,
  deleteMassCampaignTemplate,
  queueMassCampaignJob,
} from "./actions";

type Platform = "meta" | "tiktok";

type Pixel = { id: string; name: string };

type AdAccount = {
  id: string;
  platform: Platform;
  accountId: string;
  accountName: string;
  profileName: string;
  pixels: Pixel[];
};

type Template = {
  id: string;
  name: string;
  platform: Platform;
  config: Record<string, unknown>;
  updatedAt: string;
};

type Job = {
  id: string;
  platform: Platform;
  status: string;
  targetAdAccountIds: string[];
  campaignsPerAccount: number;
  successCount: number;
  failureCount: number;
  createdAt: string;
  completedAt: string | null;
};

/* =================== META DEFAULTS =================== */

type MetaConfig = {
  // Campaign
  campaignName: string;
  objective: string;
  buyingType: "AUCTION" | "RESERVED";
  specialAdCategories: string[];
  budgetMode: "abo" | "cbo";
  campaignDailyBudgetCents?: number;
  // Ad Set
  adSetName: string;
  adSetDailyBudgetCents: number;
  startDate?: string | null;
  endDate?: string | null;
  optimizationGoal: string;
  bidStrategy: string;
  bidAmountCents?: number | null;
  conversionEvent: string;
  pixelId?: string | null;
  pixelName?: string | null;
  catalogId?: string | null;
  useCatalog: boolean;
  placementMode: "advantage_plus" | "manual";
  placements: string[];
  targeting: {
    countries: string[];
    ageMin: number;
    ageMax: number;
    genders: ("all" | "male" | "female")[];
    languages: string[];
    interests: string[];
    behaviors: string[];
    customAudiences: string[];
    lookalikes: string[];
    excludeCustomAudiences: string[];
    locationType: "everyone" | "people_living" | "recent_visitors";
  };
  // Ad
  adName: string;
  pageId?: string | null;
  instagramAccountId?: string | null;
  adFormat: "SINGLE_IMAGE" | "SINGLE_VIDEO" | "CAROUSEL" | "COLLECTION";
  creativeMediaUrls: string[];
  primaryText: string;
  headline: string;
  description: string;
  callToAction: string;
  landingUrl: string;
  displayLink?: string | null;
  utmSource: string;
  utmMedium: string;
  utmCampaign: string;
  notes?: string | null;
};

const META_OBJECTIVES = [
  { value: "OUTCOME_SALES", label: "Vendas (Conversões)" },
  { value: "OUTCOME_LEADS", label: "Leads" },
  { value: "OUTCOME_AWARENESS", label: "Reconhecimento" },
  { value: "OUTCOME_TRAFFIC", label: "Tráfego" },
  { value: "OUTCOME_ENGAGEMENT", label: "Engajamento" },
  { value: "OUTCOME_APP_PROMOTION", label: "Promoção de App" },
];

const META_OPTIMIZATION_GOALS = [
  { value: "OFFSITE_CONVERSIONS", label: "Conversões (Pixel)" },
  { value: "PURCHASE", label: "Compras" },
  { value: "ADD_TO_CART", label: "Adicionar ao Carrinho" },
  { value: "INITIATE_CHECKOUT", label: "Iniciar checkout" },
  { value: "LEAD", label: "Lead" },
  { value: "LANDING_PAGE_VIEWS", label: "Visualizações da landing page" },
  { value: "LINK_CLICKS", label: "Cliques no link" },
  { value: "REACH", label: "Alcance" },
  { value: "IMPRESSIONS", label: "Impressões" },
  { value: "POST_ENGAGEMENT", label: "Engajamento de publicação" },
  { value: "VIDEO_VIEWS", label: "Visualizações de vídeo" },
];

const META_BID_STRATEGIES = [
  { value: "LOWEST_COST_WITHOUT_CAP", label: "Custo mais baixo (sem limite)" },
  { value: "LOWEST_COST_WITH_BID_CAP", label: "Custo mais baixo (com limite de lance)" },
  { value: "COST_CAP", label: "Limite de custo (CPA alvo)" },
  { value: "LOWEST_COST_WITH_MIN_ROAS", label: "ROAS mínimo" },
];

const META_CONVERSION_EVENTS = [
  "Purchase",
  "AddToCart",
  "InitiateCheckout",
  "Lead",
  "AddPaymentInfo",
  "CompleteRegistration",
  "ViewContent",
  "Subscribe",
  "StartTrial",
];

const META_PLACEMENTS = [
  { value: "facebook_feed", label: "Facebook Feed" },
  { value: "instagram_feed", label: "Instagram Feed" },
  { value: "instagram_stories", label: "Instagram Stories" },
  { value: "facebook_stories", label: "Facebook Stories" },
  { value: "instagram_reels", label: "Instagram Reels" },
  { value: "facebook_reels", label: "Facebook Reels" },
  { value: "facebook_marketplace", label: "Facebook Marketplace" },
  { value: "facebook_video_feeds", label: "Facebook Video Feeds" },
  { value: "instagram_explore", label: "Instagram Explore" },
  { value: "messenger_inbox", label: "Messenger" },
  { value: "audience_network", label: "Audience Network" },
];

const META_CTA = [
  { value: "SHOP_NOW", label: "Comprar agora" },
  { value: "LEARN_MORE", label: "Saiba mais" },
  { value: "SIGN_UP", label: "Cadastre-se" },
  { value: "SUBSCRIBE", label: "Assinar" },
  { value: "DOWNLOAD", label: "Baixar" },
  { value: "GET_OFFER", label: "Obter oferta" },
  { value: "ORDER_NOW", label: "Pedir agora" },
  { value: "BOOK_TRAVEL", label: "Reservar" },
  { value: "CONTACT_US", label: "Fale conosco" },
  { value: "APPLY_NOW", label: "Inscreva-se" },
  { value: "GET_QUOTE", label: "Pedir orçamento" },
];

const META_AD_FORMATS = [
  { value: "SINGLE_IMAGE", label: "Imagem única" },
  { value: "SINGLE_VIDEO", label: "Vídeo único" },
  { value: "CAROUSEL", label: "Carrossel" },
  { value: "COLLECTION", label: "Coleção (Catálogo)" },
];

const SPECIAL_AD_CATEGORIES = [
  "Habitação",
  "Crédito",
  "Emprego",
  "Eleições/Política",
  "Saúde",
];

const DEFAULT_META_CONFIG: MetaConfig = {
  campaignName: "",
  objective: "OUTCOME_SALES",
  buyingType: "AUCTION",
  specialAdCategories: [],
  budgetMode: "abo",
  campaignDailyBudgetCents: undefined,
  adSetName: "",
  adSetDailyBudgetCents: 5000,
  startDate: null,
  endDate: null,
  optimizationGoal: "OFFSITE_CONVERSIONS",
  bidStrategy: "LOWEST_COST_WITHOUT_CAP",
  bidAmountCents: null,
  conversionEvent: "Purchase",
  pixelId: "",
  pixelName: "",
  catalogId: "",
  useCatalog: false,
  placementMode: "advantage_plus",
  placements: [],
  targeting: {
    countries: ["BR"],
    ageMin: 18,
    ageMax: 65,
    genders: ["all"],
    languages: [],
    interests: [],
    behaviors: [],
    customAudiences: [],
    lookalikes: [],
    excludeCustomAudiences: [],
    locationType: "everyone",
  },
  adName: "",
  pageId: "",
  instagramAccountId: "",
  adFormat: "SINGLE_VIDEO",
  creativeMediaUrls: [],
  primaryText: "",
  headline: "",
  description: "",
  callToAction: "SHOP_NOW",
  landingUrl: "",
  displayLink: "",
  utmSource: "facebook",
  utmMedium: "paid",
  utmCampaign: "",
  notes: "",
};

/* =================== TIKTOK DEFAULTS =================== */

type TiktokConfig = {
  campaignName: string;
  objective: string;
  campaignType: "regular" | "smart_plus";
  campaignBudgetMode:
    | "BUDGET_MODE_INFINITE"
    | "BUDGET_MODE_DAY"
    | "BUDGET_MODE_TOTAL";
  campaignBudgetCents?: number | null;
  specialIndustries: string[];

  adGroupName: string;
  adGroupBudgetMode: "BUDGET_MODE_DAY" | "BUDGET_MODE_TOTAL";
  adGroupDailyBudgetCents: number;
  startDate?: string | null;
  endDate?: string | null;
  scheduleType: "SCHEDULE_FROM_NOW" | "SCHEDULE_START_END";
  optimizationGoal: string;
  pixelId?: string | null;
  pixelName?: string | null;
  conversionEvent: string;
  attributionWindow: string;
  biddingType: string;
  bidPriceCents?: number | null;
  placementType: "PLACEMENT_TYPE_AUTOMATIC" | "PLACEMENT_TYPE_NORMAL";
  placements: string[];
  targeting: {
    countries: string[];
    ageGroups: string[];
    genders: ("all" | "male" | "female")[];
    languages: string[];
    interestCategories: string[];
    behaviorCategories: string[];
    hashtags: string[];
    customAudiences: string[];
    lookalikes: string[];
    excludeCustomAudiences: string[];
  };
  frequencyCap?: number | null;
  frequencyCapDays?: number | null;

  adName: string;
  identityType: "CUSTOMIZED_USER" | "AUTH_CODE" | "TT_USER";
  identityDisplayName?: string | null;
  identityImageUrl?: string | null;
  adFormat: "SINGLE_VIDEO" | "CAROUSEL" | "SPARK_AD" | "COLLECTION";
  sparkTiktokItemId?: string | null;
  sparkIdentityId?: string | null;
  creativeMediaUrls: string[];
  adText: string;
  callToAction: string;
  landingUrl: string;
  utmSource: string;
  utmMedium: string;
  utmCampaign: string;
  notes?: string | null;
};

const TIKTOK_OBJECTIVES = [
  { value: "CONVERSIONS", label: "Conversões" },
  { value: "LEAD_GENERATION", label: "Geração de Leads" },
  { value: "TRAFFIC", label: "Tráfego" },
  { value: "REACH", label: "Alcance" },
  { value: "VIDEO_VIEWS", label: "Visualizações de vídeo" },
  { value: "APP_PROMOTION", label: "Promoção de App" },
  { value: "ENGAGEMENT", label: "Engajamento na comunidade" },
];

const TIKTOK_OPTIMIZATION_GOALS = [
  { value: "CONVERSION", label: "Conversão" },
  { value: "CLICK", label: "Clique" },
  { value: "REACH", label: "Alcance" },
  { value: "VALUE", label: "Valor (ROAS)" },
  { value: "INSTALL", label: "Instalação" },
  { value: "VIDEO_VIEW", label: "Visualização de vídeo" },
  { value: "FOLLOWERS", label: "Seguidores" },
  { value: "LEAD_GENERATION", label: "Lead" },
];

const TIKTOK_CONVERSION_EVENTS = [
  "COMPLETE_PAYMENT",
  "ADD_TO_CART",
  "INITIATE_CHECKOUT",
  "ADD_PAYMENT_INFO",
  "PLACE_ORDER",
  "FORM",
  "DOWNLOAD",
  "SUBSCRIBE",
  "VIEW_CONTENT",
];

const TIKTOK_AGE_GROUPS = [
  { value: "AGE_13_17", label: "13–17" },
  { value: "AGE_18_24", label: "18–24" },
  { value: "AGE_25_34", label: "25–34" },
  { value: "AGE_35_44", label: "35–44" },
  { value: "AGE_45_54", label: "45–54" },
  { value: "AGE_55_100", label: "55+" },
];

const TIKTOK_PLACEMENTS = [
  { value: "PLACEMENT_TIKTOK", label: "TikTok" },
  { value: "PLACEMENT_PANGLE", label: "Pangle Network" },
  { value: "PLACEMENT_GLOBAL_APP_BUNDLE", label: "Global App Bundle" },
];

const TIKTOK_CTA = [
  { value: "SHOP_NOW", label: "Comprar agora" },
  { value: "LEARN_MORE", label: "Saiba mais" },
  { value: "SIGN_UP", label: "Cadastre-se" },
  { value: "DOWNLOAD_NOW", label: "Baixar" },
  { value: "ORDER_NOW", label: "Pedir agora" },
  { value: "CONTACT_US", label: "Fale conosco" },
  { value: "APPLY_NOW", label: "Inscreva-se" },
  { value: "GET_QUOTE", label: "Pedir orçamento" },
  { value: "INSTALL_NOW", label: "Instalar agora" },
  { value: "PLAY_GAME", label: "Jogar" },
  { value: "VIEW_NOW", label: "Ver agora" },
];

const TIKTOK_AD_FORMATS = [
  { value: "SINGLE_VIDEO", label: "Vídeo único" },
  { value: "CAROUSEL", label: "Carrossel" },
  { value: "SPARK_AD", label: "Spark Ad (post existente)" },
  { value: "COLLECTION", label: "Coleção" },
];

const DEFAULT_TIKTOK_CONFIG: TiktokConfig = {
  campaignName: "",
  objective: "CONVERSIONS",
  campaignType: "regular",
  campaignBudgetMode: "BUDGET_MODE_INFINITE",
  campaignBudgetCents: null,
  specialIndustries: [],
  adGroupName: "",
  adGroupBudgetMode: "BUDGET_MODE_DAY",
  adGroupDailyBudgetCents: 5000,
  startDate: null,
  endDate: null,
  scheduleType: "SCHEDULE_FROM_NOW",
  optimizationGoal: "CONVERSION",
  pixelId: "",
  pixelName: "",
  conversionEvent: "COMPLETE_PAYMENT",
  attributionWindow: "CLICK_7D",
  biddingType: "BID_TYPE_NO_BID",
  bidPriceCents: null,
  placementType: "PLACEMENT_TYPE_AUTOMATIC",
  placements: [],
  targeting: {
    countries: ["BR"],
    ageGroups: ["AGE_18_24", "AGE_25_34", "AGE_35_44", "AGE_45_54"],
    genders: ["all"],
    languages: [],
    interestCategories: [],
    behaviorCategories: [],
    hashtags: [],
    customAudiences: [],
    lookalikes: [],
    excludeCustomAudiences: [],
  },
  frequencyCap: null,
  frequencyCapDays: null,
  adName: "",
  identityType: "CUSTOMIZED_USER",
  identityDisplayName: "",
  identityImageUrl: "",
  adFormat: "SINGLE_VIDEO",
  sparkTiktokItemId: "",
  sparkIdentityId: "",
  creativeMediaUrls: [],
  adText: "",
  callToAction: "SHOP_NOW",
  landingUrl: "",
  utmSource: "tiktok",
  utmMedium: "paid",
  utmCampaign: "",
  notes: "",
};

/* =================== COMPONENTE PRINCIPAL =================== */

export function MassUploaderClient({
  adAccounts,
  templates,
  recentJobs,
}: {
  adAccounts: AdAccount[];
  templates: Template[];
  recentJobs: Job[];
}) {
  const [platform, setPlatform] = useState<Platform>("meta");
  const [isPending, startTransition] = useTransition();
  const [metaConfig, setMetaConfig] = useState<MetaConfig>(DEFAULT_META_CONFIG);
  const [tiktokConfig, setTiktokConfig] = useState<TiktokConfig>(
    DEFAULT_TIKTOK_CONFIG,
  );
  const [selectedAccounts, setSelectedAccounts] = useState<Set<string>>(
    new Set(),
  );
  const [campaignsPerAccount, setCampaignsPerAccount] = useState(1);
  const [adsetsPerCampaign, setAdsetsPerCampaign] = useState(1);
  const [adsPerAdset, setAdsPerAdset] = useState(1);
  const [templateName, setTemplateName] = useState("");
  const [feedback, setFeedback] = useState<
    { ok: true; msg: string } | { ok: false; msg: string } | null
  >(null);

  const accountsForPlatform = useMemo(
    () => adAccounts.filter((a) => a.platform === platform),
    [adAccounts, platform],
  );

  // Pixels disponíveis = união dos pixels de TODAS as contas selecionadas
  // (dedupe por id+name). Quando user seleciona, fica armazenado nome.
  const availablePixels = useMemo(() => {
    const map = new Map<string, Pixel>();
    for (const a of accountsForPlatform) {
      if (selectedAccounts.has(a.id)) {
        for (const p of a.pixels) {
          map.set(`${p.id}:${p.name}`, p);
        }
      }
    }
    return Array.from(map.values());
  }, [accountsForPlatform, selectedAccounts]);

  const grouped = useMemo(() => {
    const map = new Map<string, AdAccount[]>();
    for (const a of accountsForPlatform) {
      const key = a.profileName || "(sem perfil)";
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(a);
    }
    return Array.from(map.entries());
  }, [accountsForPlatform]);

  const templatesForPlatform = templates.filter(
    (t) => t.platform === platform,
  );

  function toggleAccount(id: string) {
    setSelectedAccounts((s) => {
      const next = new Set(s);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }
  function selectAllInGroup(profileName: string) {
    const ids = accountsForPlatform
      .filter((a) => (a.profileName || "(sem perfil)") === profileName)
      .map((a) => a.id);
    setSelectedAccounts((s) => {
      const next = new Set(s);
      const allSelected = ids.every((id) => next.has(id));
      if (allSelected) {
        ids.forEach((id) => next.delete(id));
      } else {
        ids.forEach((id) => next.add(id));
      }
      return next;
    });
  }
  function selectAll() {
    setSelectedAccounts(new Set(accountsForPlatform.map((a) => a.id)));
  }
  function clearAll() {
    setSelectedAccounts(new Set());
  }

  function applyTemplate(t: Template) {
    if (t.platform === "meta") {
      setMetaConfig({
        ...DEFAULT_META_CONFIG,
        ...(t.config as Partial<MetaConfig>),
      });
    } else {
      setTiktokConfig({
        ...DEFAULT_TIKTOK_CONFIG,
        ...(t.config as Partial<TiktokConfig>),
      });
    }
    setTemplateName(t.name);
    setFeedback({ ok: true, msg: `Template "${t.name}" carregado` });
    setTimeout(() => setFeedback(null), 2500);
  }

  function saveTemplate() {
    if (!templateName.trim()) {
      setFeedback({ ok: false, msg: "Dê um nome ao template" });
      return;
    }
    const config = platform === "meta" ? metaConfig : tiktokConfig;
    startTransition(async () => {
      const r = await saveMassCampaignTemplate({
        name: templateName.trim(),
        platform,
        config: config as never,
      });
      if (r.ok) {
        setFeedback({ ok: true, msg: "Template salvo" });
      } else {
        setFeedback({ ok: false, msg: r.error });
      }
    });
  }

  function removeTemplate(id: string) {
    if (!confirm("Apagar este template?")) return;
    startTransition(async () => {
      await deleteMassCampaignTemplate(id);
    });
  }

  function launch() {
    if (selectedAccounts.size === 0) {
      setFeedback({ ok: false, msg: "Selecione ao menos 1 conta de anúncio" });
      return;
    }
    const config = platform === "meta" ? metaConfig : tiktokConfig;
    if (!config.campaignName.trim()) {
      setFeedback({ ok: false, msg: "Defina o nome da campanha" });
      return;
    }
    if (!config.landingUrl.trim()) {
      setFeedback({ ok: false, msg: "Defina a URL de destino" });
      return;
    }
    startTransition(async () => {
      const r = await queueMassCampaignJob({
        platform,
        targetAdAccountIds: Array.from(selectedAccounts),
        campaignsPerAccount,
        adsetsPerCampaign,
        adsPerAdset,
        config: config as never,
      });
      if (r.ok) {
        setFeedback({
          ok: true,
          msg: `Job enfileirado! Subindo em ${selectedAccounts.size} conta(s)`,
        });
        setSelectedAccounts(new Set());
      } else {
        setFeedback({ ok: false, msg: r.error });
      }
    });
  }

  const dailyBudget =
    platform === "meta"
      ? metaConfig.budgetMode === "cbo"
        ? metaConfig.campaignDailyBudgetCents ?? 0
        : metaConfig.adSetDailyBudgetCents
      : tiktokConfig.adGroupDailyBudgetCents;
  const totalCampaigns = selectedAccounts.size * campaignsPerAccount;
  const totalAdsets = totalCampaigns * adsetsPerCampaign;
  const totalAds = totalAdsets * adsPerAdset;
  const totalDailyBudget = totalCampaigns * dailyBudget;

  return (
    <section className="space-y-6">
      <header className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <p className="text-xs uppercase tracking-[0.2em] text-lime-400 mb-1">
            Nova publicação em massa
          </p>
          <h2 className="text-2xl font-semibold tracking-tight text-white">
            Espelhe o gerenciador de anúncios
          </h2>
          <p className="mt-1 text-sm text-zinc-400 max-w-2xl">
            Configure 1 campanha completa (Campaign → Ad Set → Ad) e publique
            em N contas simultaneamente. Cada plataforma usa sua estrutura
            nativa.
          </p>
        </div>
      </header>

      {/* TABS PLATAFORMA */}
      <div className="flex border-b border-white/[0.06]">
        <PlatformTab
          active={platform === "meta"}
          onClick={() => {
            setPlatform("meta");
            setSelectedAccounts(new Set());
          }}
          icon={Megaphone}
          color="blue"
          label="Meta Ads"
          count={adAccounts.filter((a) => a.platform === "meta").length}
        />
        <PlatformTab
          active={platform === "tiktok"}
          onClick={() => {
            setPlatform("tiktok");
            setSelectedAccounts(new Set());
          }}
          icon={Music2}
          color="pink"
          label="TikTok Ads"
          count={adAccounts.filter((a) => a.platform === "tiktok").length}
        />
      </div>

      {accountsForPlatform.length === 0 ? (
        <div className="rounded-2xl border border-amber-400/30 bg-amber-400/[0.04] p-8 text-center">
          <AlertCircle className="mx-auto size-10 text-amber-300" />
          <p className="mt-4 text-base font-semibold text-white">
            Nenhuma conta {platform === "meta" ? "Meta" : "TikTok"} conectada
          </p>
          <p className="mt-1 text-sm text-zinc-400 max-w-md mx-auto">
            Conecte sua conta em{" "}
            <strong className="text-amber-200">
              Tracking → Integrações
            </strong>{" "}
            primeiro pra liberar a publicação em massa.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* LEFT: Multi-select de contas + templates */}
          <div className="lg:col-span-1 space-y-3">
            <div className="rounded-2xl border border-white/[0.08] bg-white/[0.02] p-4">
              <div className="flex items-center justify-between mb-3">
                <p className="text-xs font-semibold text-white inline-flex items-center gap-2">
                  <FolderTree className="size-3.5 text-lime-400" />
                  Contas de anúncio
                  <span className="text-zinc-500 font-normal">
                    ({selectedAccounts.size}/{accountsForPlatform.length})
                  </span>
                </p>
                <div className="flex gap-1">
                  <button
                    type="button"
                    onClick={selectAll}
                    className="text-[10px] text-lime-300 hover:underline"
                  >
                    Todas
                  </button>
                  <span className="text-zinc-700">·</span>
                  <button
                    type="button"
                    onClick={clearAll}
                    className="text-[10px] text-zinc-400 hover:underline"
                  >
                    Limpar
                  </button>
                </div>
              </div>

              <div className="max-h-[500px] overflow-y-auto space-y-3 pr-1">
                {grouped.map(([profileName, accounts]) => {
                  const allSelected = accounts.every((a) =>
                    selectedAccounts.has(a.id),
                  );
                  const someSelected = accounts.some((a) =>
                    selectedAccounts.has(a.id),
                  );
                  return (
                    <div
                      key={profileName}
                      className="rounded-lg border border-white/[0.06] bg-black/30 p-2"
                    >
                      <button
                        type="button"
                        onClick={() => selectAllInGroup(profileName)}
                        className="w-full flex items-center gap-2 px-1 py-1 hover:bg-white/[0.04] rounded"
                      >
                        <input
                          type="checkbox"
                          checked={allSelected}
                          ref={(el) => {
                            if (el) {
                              el.indeterminate = !allSelected && someSelected;
                            }
                          }}
                          readOnly
                          className="size-3.5 rounded border-white/15 bg-white/[0.05] text-lime-400"
                        />
                        <span className="text-xs font-semibold text-zinc-200 uppercase tracking-wide truncate flex-1 text-left">
                          {profileName}
                        </span>
                        <span className="text-[10px] text-zinc-500">
                          {accounts.length}
                        </span>
                      </button>
                      <div className="mt-1 space-y-0.5 pl-5">
                        {accounts.map((a) => (
                          <label
                            key={a.id}
                            className="flex items-center gap-2 px-1 py-1 hover:bg-white/[0.04] rounded cursor-pointer"
                          >
                            <input
                              type="checkbox"
                              checked={selectedAccounts.has(a.id)}
                              onChange={() => toggleAccount(a.id)}
                              className="size-3.5 rounded border-white/15 bg-white/[0.05] text-lime-400"
                            />
                            <span className="text-xs text-zinc-300 truncate flex-1">
                              {a.accountName}
                            </span>
                            <span className="text-[9px] text-zinc-600 font-mono">
                              {a.pixels.length}px
                            </span>
                          </label>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Templates salvos */}
            {templatesForPlatform.length > 0 && (
              <div className="rounded-2xl border border-white/[0.08] bg-white/[0.02] p-4">
                <p className="text-xs font-semibold text-white inline-flex items-center gap-2 mb-3">
                  <Layers className="size-3.5 text-lime-400" />
                  Templates salvos
                </p>
                <div className="space-y-1.5 max-h-60 overflow-y-auto pr-1">
                  {templatesForPlatform.map((t) => (
                    <div
                      key={t.id}
                      className="flex items-center gap-2 rounded-md border border-white/[0.06] bg-black/20 px-2 py-1.5"
                    >
                      <button
                        type="button"
                        onClick={() => applyTemplate(t)}
                        className="flex-1 text-left text-xs text-zinc-200 hover:text-lime-300 truncate"
                      >
                        {t.name}
                      </button>
                      <button
                        type="button"
                        onClick={() => removeTemplate(t.id)}
                        className="text-zinc-500 hover:text-red-300"
                      >
                        <Trash2 className="size-3" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* RIGHT: Form da campanha */}
          <div className="lg:col-span-2 space-y-3">
            {platform === "meta" ? (
              <MetaForm
                config={metaConfig}
                setConfig={setMetaConfig}
                pixels={availablePixels}
              />
            ) : (
              <TiktokForm
                config={tiktokConfig}
                setConfig={setTiktokConfig}
                pixels={availablePixels}
              />
            )}

            {feedback && (
              <div
                className={`rounded-lg border p-2.5 text-xs flex items-start gap-2 ${
                  feedback.ok
                    ? "border-lime-400/30 bg-lime-400/[0.06] text-lime-200"
                    : "border-red-400/30 bg-red-400/[0.06] text-red-200"
                }`}
              >
                {feedback.ok ? (
                  <CheckCircle2 className="size-4 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="size-4 shrink-0 mt-0.5" />
                )}
                <span>{feedback.msg}</span>
              </div>
            )}

            {/* Footer: Save template + Launch */}
            <div className="rounded-2xl border border-white/[0.08] bg-white/[0.02] p-3 flex items-center gap-2 flex-wrap">
              <input
                type="text"
                value={templateName}
                onChange={(e) => setTemplateName(e.target.value)}
                placeholder="Nome do template"
                className="flex-1 min-w-[160px] rounded-lg border border-white/[0.08] bg-black/30 px-3 py-1.5 text-xs text-white placeholder:text-zinc-500"
              />
              <button
                type="button"
                onClick={saveTemplate}
                disabled={isPending}
                className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5 text-xs text-zinc-200 hover:bg-white/[0.08] disabled:opacity-50"
              >
                <Save className="size-3.5" /> Salvar template
              </button>

              <div className="flex items-center gap-2 flex-wrap">
                <div className="flex items-center gap-1.5">
                  <label className="text-[9px] uppercase tracking-wider text-zinc-500" title="Quantas campanhas serão criadas por conta de anúncio">
                    Camp/conta
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={20}
                    value={campaignsPerAccount}
                    onChange={(e) =>
                      setCampaignsPerAccount(
                        Math.min(20, Math.max(1, Number(e.target.value) || 1)),
                      )
                    }
                    className="w-14 rounded-lg border border-white/[0.08] bg-black/30 px-2 py-1.5 text-xs text-white tabular-nums"
                  />
                </div>
                <span className="text-zinc-600 text-xs">×</span>
                <div className="flex items-center gap-1.5">
                  <label className="text-[9px] uppercase tracking-wider text-zinc-500" title="Conjuntos de anúncios (ad sets) por campanha">
                    Conj/camp
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={20}
                    value={adsetsPerCampaign}
                    onChange={(e) =>
                      setAdsetsPerCampaign(
                        Math.min(20, Math.max(1, Number(e.target.value) || 1)),
                      )
                    }
                    className="w-14 rounded-lg border border-white/[0.08] bg-black/30 px-2 py-1.5 text-xs text-white tabular-nums"
                  />
                </div>
                <span className="text-zinc-600 text-xs">×</span>
                <div className="flex items-center gap-1.5">
                  <label className="text-[9px] uppercase tracking-wider text-zinc-500" title="Anúncios por conjunto">
                    Ads/conj
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={20}
                    value={adsPerAdset}
                    onChange={(e) =>
                      setAdsPerAdset(
                        Math.min(20, Math.max(1, Number(e.target.value) || 1)),
                      )
                    }
                    className="w-14 rounded-lg border border-white/[0.08] bg-black/30 px-2 py-1.5 text-xs text-white tabular-nums"
                  />
                </div>
              </div>

              <div className="ml-auto inline-flex items-center gap-3">
                <span className="text-[11px] text-zinc-400">
                  <strong className="text-white">{totalCampaigns}</strong> camp ·{" "}
                  <strong className="text-white">{totalAdsets}</strong> conj ·{" "}
                  <strong className="text-white">{totalAds}</strong> ads · R${" "}
                  <strong className="text-white">
                    {(totalDailyBudget / 100).toFixed(2)}
                  </strong>
                  /dia
                </span>
                <button
                  type="button"
                  onClick={launch}
                  disabled={isPending || selectedAccounts.size === 0}
                  className="inline-flex items-center gap-1.5 rounded-full bg-lime-400 px-4 py-2 text-xs font-bold text-black hover:bg-lime-300 disabled:opacity-50"
                >
                  {isPending ? (
                    <Loader2 className="size-3.5 animate-spin" />
                  ) : (
                    <Rocket className="size-3.5" />
                  )}
                  Subir em massa
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Histórico de jobs */}
      {recentJobs.length > 0 && (
        <section className="rounded-2xl border border-white/[0.08] bg-white/[0.02] p-5">
          <p className="text-xs font-semibold text-white mb-3">
            Últimos uploads
          </p>
          <div className="space-y-2">
            {recentJobs.map((j) => (
              <div
                key={j.id}
                className="flex items-center gap-3 rounded-lg border border-white/[0.06] bg-black/20 p-2.5 text-xs"
              >
                <JobStatusBadge status={j.status} />
                <span className="capitalize text-zinc-300">{j.platform}</span>
                <span className="text-zinc-500">
                  {j.targetAdAccountIds.length} conta(s) ·{" "}
                  {j.campaignsPerAccount} camp/conta
                </span>
                <span className="text-zinc-500 ml-auto">
                  {new Date(j.createdAt).toLocaleString("pt-BR", {
                    day: "2-digit",
                    month: "2-digit",
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </span>
                {j.status === "completed" && (
                  <span className="text-lime-300">
                    {j.successCount} ok{" "}
                    {j.failureCount > 0 && (
                      <span className="text-red-300">
                        · {j.failureCount} falha(s)
                      </span>
                    )}
                  </span>
                )}
              </div>
            ))}
          </div>
        </section>
      )}
    </section>
  );
}

/* =================== META FORM =================== */

function MetaForm({
  config,
  setConfig,
  pixels,
}: {
  config: MetaConfig;
  setConfig: React.Dispatch<React.SetStateAction<MetaConfig>>;
  pixels: Pixel[];
}) {
  const set = <K extends keyof MetaConfig>(k: K, v: MetaConfig[K]) =>
    setConfig((c) => ({ ...c, [k]: v }));
  const setT = <K extends keyof MetaConfig["targeting"]>(
    k: K,
    v: MetaConfig["targeting"][K],
  ) => setConfig((c) => ({ ...c, targeting: { ...c.targeting, [k]: v } }));

  return (
    <>
      {/* CAMPAIGN LEVEL */}
      <Section
        title="Campanha"
        icon={Megaphone}
        subtitle="Define objetivo + estrutura de orçamento (CBO/ABO)"
        defaultOpen
      >
        <Grid2>
          <Field
            label="Nome da campanha"
            value={config.campaignName}
            onChange={(v) => set("campaignName", v)}
            placeholder="Ex: ABO Q4 — Cosmético"
            icon={Rocket}
          />
          <SelectField
            label="Objetivo"
            value={config.objective}
            onChange={(v) => set("objective", v)}
            options={META_OBJECTIVES}
            icon={Target}
          />
        </Grid2>
        <Grid2>
          <SelectField
            label="Tipo de compra"
            value={config.buyingType}
            onChange={(v) =>
              set("buyingType", v as MetaConfig["buyingType"])
            }
            options={[
              { value: "AUCTION", label: "Leilão" },
              { value: "RESERVED", label: "Reservado" },
            ]}
          />
          <SelectField
            label="Modo de orçamento"
            value={config.budgetMode}
            onChange={(v) =>
              set("budgetMode", v as MetaConfig["budgetMode"])
            }
            options={[
              { value: "abo", label: "ABO (orçamento por ad set)" },
              { value: "cbo", label: "CBO (orçamento da campanha)" },
            ]}
          />
        </Grid2>
        {config.budgetMode === "cbo" && (
          <MoneyField
            label="Orçamento diário da campanha (R$)"
            value={config.campaignDailyBudgetCents ?? 0}
            onChange={(c) =>
              set("campaignDailyBudgetCents", c > 0 ? c : undefined)
            }
          />
        )}
        <MultiChipField
          label="Categorias especiais (Política, Crédito, Habitação, Emprego, Saúde)"
          options={SPECIAL_AD_CATEGORIES}
          value={config.specialAdCategories}
          onChange={(v) => set("specialAdCategories", v)}
        />
      </Section>

      {/* AD SET LEVEL */}
      <Section
        title="Conjunto de Anúncios (Ad Set)"
        icon={Layers}
        subtitle="Orçamento, otimização, segmentação, posicionamentos, pixel"
      >
        <Grid2>
          <Field
            label="Nome do ad set"
            value={config.adSetName}
            onChange={(v) => set("adSetName", v)}
            placeholder="Ex: Mulheres BR 25-45"
          />
          <MoneyField
            label="Orçamento diário do ad set (R$)"
            value={config.adSetDailyBudgetCents}
            onChange={(c) => set("adSetDailyBudgetCents", c)}
          />
        </Grid2>
        <Grid2>
          <Field
            label="Início (opcional)"
            type="date"
            value={config.startDate ?? ""}
            onChange={(v) => set("startDate", v || null)}
          />
          <Field
            label="Fim (opcional)"
            type="date"
            value={config.endDate ?? ""}
            onChange={(v) => set("endDate", v || null)}
          />
        </Grid2>
        <Grid2>
          <SelectField
            label="Meta de otimização"
            value={config.optimizationGoal}
            onChange={(v) => set("optimizationGoal", v)}
            options={META_OPTIMIZATION_GOALS}
          />
          <SelectField
            label="Evento de conversão"
            value={config.conversionEvent}
            onChange={(v) => set("conversionEvent", v)}
            options={META_CONVERSION_EVENTS.map((e) => ({
              value: e,
              label: e,
            }))}
          />
        </Grid2>
        <Grid2>
          <SelectField
            label="Estratégia de lance"
            value={config.bidStrategy}
            onChange={(v) => set("bidStrategy", v)}
            options={META_BID_STRATEGIES}
          />
          {config.bidStrategy !== "LOWEST_COST_WITHOUT_CAP" && (
            <MoneyField
              label="Lance / Limite (R$)"
              value={config.bidAmountCents ?? 0}
              onChange={(c) => set("bidAmountCents", c > 0 ? c : null)}
            />
          )}
        </Grid2>

        {/* PIXEL POR NOME */}
        <PixelPicker
          pixels={pixels}
          selectedId={config.pixelId ?? ""}
          onChange={(p) => {
            set("pixelId", p?.id ?? null);
            set("pixelName", p?.name ?? null);
          }}
        />

        {/* PLACEMENTS */}
        <div className="space-y-2">
          <p className="text-[10px] uppercase tracking-wider text-zinc-500 font-semibold">
            Posicionamentos
          </p>
          <div className="flex gap-2">
            {(
              [
                { v: "advantage_plus", label: "Advantage+ (auto)" },
                { v: "manual", label: "Manual" },
              ] as const
            ).map((opt) => (
              <button
                key={opt.v}
                type="button"
                onClick={() => set("placementMode", opt.v)}
                className={`px-3 py-1.5 rounded-full border text-xs ${
                  config.placementMode === opt.v
                    ? "border-lime-400 bg-lime-400/10 text-lime-200"
                    : "border-white/10 bg-white/[0.04] text-zinc-400"
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
          {config.placementMode === "manual" && (
            <MultiCheckField
              options={META_PLACEMENTS}
              value={config.placements}
              onChange={(v) => set("placements", v)}
            />
          )}
        </div>

        {/* TARGETING */}
        <div className="space-y-3 rounded-lg border border-white/[0.06] bg-black/20 p-3">
          <p className="text-[10px] uppercase tracking-wider text-zinc-500 font-semibold inline-flex items-center gap-1.5">
            <Users className="size-3" /> Segmentação detalhada
          </p>
          <Grid2>
            <Field
              label="Países (ISO, vírgulas)"
              value={config.targeting.countries.join(", ")}
              onChange={(v) =>
                setT(
                  "countries",
                  v
                    .split(",")
                    .map((s) => s.trim().toUpperCase())
                    .filter(Boolean),
                )
              }
              placeholder="BR, PT, AR"
            />
            <SelectField
              label="Tipo de localização"
              value={config.targeting.locationType}
              onChange={(v) =>
                setT(
                  "locationType",
                  v as MetaConfig["targeting"]["locationType"],
                )
              }
              options={[
                { value: "everyone", label: "Todos nessa localização" },
                { value: "people_living", label: "Moradores" },
                { value: "recent_visitors", label: "Visitantes recentes" },
              ]}
            />
          </Grid2>
          <Grid2>
            <Field
              label="Idade mínima"
              type="number"
              value={String(config.targeting.ageMin)}
              onChange={(v) => setT("ageMin", Number(v) || 18)}
            />
            <Field
              label="Idade máxima"
              type="number"
              value={String(config.targeting.ageMax)}
              onChange={(v) => setT("ageMax", Number(v) || 65)}
            />
          </Grid2>
          <MultiChipField
            label="Gêneros"
            options={["all", "male", "female"]}
            value={config.targeting.genders}
            onChange={(v) =>
              setT("genders", v as ("all" | "male" | "female")[])
            }
            labelMap={{ all: "Todos", male: "Masculino", female: "Feminino" }}
          />
          <Field
            label="Idiomas (vírgulas)"
            value={config.targeting.languages.join(", ")}
            onChange={(v) =>
              setT(
                "languages",
                v.split(",").map((s) => s.trim()).filter(Boolean),
              )
            }
            placeholder="pt, en, es"
          />
          <Field
            label="Interesses (vírgulas)"
            value={config.targeting.interests.join(", ")}
            onChange={(v) =>
              setT(
                "interests",
                v.split(",").map((s) => s.trim()).filter(Boolean),
              )
            }
            placeholder="skincare, beleza, autoestima"
          />
          <Field
            label="Comportamentos (vírgulas)"
            value={config.targeting.behaviors.join(", ")}
            onChange={(v) =>
              setT(
                "behaviors",
                v.split(",").map((s) => s.trim()).filter(Boolean),
              )
            }
            placeholder="frequent_travelers, online_shoppers"
          />
          <Grid2>
            <Field
              label="Públicos personalizados (IDs, vírgulas)"
              value={config.targeting.customAudiences.join(", ")}
              onChange={(v) =>
                setT(
                  "customAudiences",
                  v.split(",").map((s) => s.trim()).filter(Boolean),
                )
              }
              mono
            />
            <Field
              label="Lookalikes (IDs)"
              value={config.targeting.lookalikes.join(", ")}
              onChange={(v) =>
                setT(
                  "lookalikes",
                  v.split(",").map((s) => s.trim()).filter(Boolean),
                )
              }
              mono
            />
          </Grid2>
          <Field
            label="Excluir públicos (IDs)"
            value={config.targeting.excludeCustomAudiences.join(", ")}
            onChange={(v) =>
              setT(
                "excludeCustomAudiences",
                v.split(",").map((s) => s.trim()).filter(Boolean),
              )
            }
            mono
          />
        </div>

        {/* CATÁLOGO */}
        <div className="space-y-2">
          <label className="flex items-center gap-2 cursor-pointer text-xs text-zinc-300">
            <input
              type="checkbox"
              checked={config.useCatalog}
              onChange={(e) => set("useCatalog", e.target.checked)}
              className="size-4 rounded border-white/15 bg-white/[0.05] text-lime-400"
            />
            Usar catálogo (Advantage+ Shopping / DSA)
          </label>
          {config.useCatalog && (
            <Field
              label="ID do catálogo"
              value={config.catalogId ?? ""}
              onChange={(v) => set("catalogId", v)}
              placeholder="Ex: 1234567890"
              mono
            />
          )}
        </div>
      </Section>

      {/* AD LEVEL */}
      <Section
        title="Anúncio (Ad)"
        icon={ImageIcon}
        subtitle="Identidade, criativos, texto, CTA, URL de destino"
      >
        <Grid2>
          <Field
            label="Nome do anúncio"
            value={config.adName}
            onChange={(v) => set("adName", v)}
            placeholder="Ex: Anúncio 01"
          />
          <SelectField
            label="Formato"
            value={config.adFormat}
            onChange={(v) =>
              set("adFormat", v as MetaConfig["adFormat"])
            }
            options={META_AD_FORMATS}
          />
        </Grid2>
        <Grid2>
          <Field
            label="ID da Página Facebook"
            value={config.pageId ?? ""}
            onChange={(v) => set("pageId", v)}
            mono
            placeholder="Ex: 1234567890"
          />
          <Field
            label="ID da Conta Instagram"
            value={config.instagramAccountId ?? ""}
            onChange={(v) => set("instagramAccountId", v)}
            mono
            placeholder="Ex: 17841412345678901"
          />
        </Grid2>
        <UrlListField
          label="URLs dos criativos (vídeo/imagem — máx 20)"
          value={config.creativeMediaUrls}
          onChange={(v) => set("creativeMediaUrls", v)}
          placeholder="https://cdn.suamarca.com/video.mp4"
        />
        <Field
          label="Texto principal (primary text)"
          value={config.primaryText}
          onChange={(v) => set("primaryText", v)}
          multiline
          placeholder="O texto que vai aparecer acima do criativo."
        />
        <Grid2>
          <Field
            label="Título (headline)"
            value={config.headline}
            onChange={(v) => set("headline", v)}
            placeholder="Ex: Pele perfeita em 30 dias"
          />
          <Field
            label="Descrição"
            value={config.description}
            onChange={(v) => set("description", v)}
            placeholder="Ex: Garantia de 7 dias"
          />
        </Grid2>
        <Grid2>
          <SelectField
            label="Call to Action"
            value={config.callToAction}
            onChange={(v) => set("callToAction", v)}
            options={META_CTA}
          />
          <Field
            label="Link de exibição (display link)"
            value={config.displayLink ?? ""}
            onChange={(v) => set("displayLink", v)}
            placeholder="suamarca.com.br"
            mono
          />
        </Grid2>
        <Field
          label="URL de destino (landing/checkout)"
          value={config.landingUrl}
          onChange={(v) => set("landingUrl", v)}
          placeholder="https://checkout.suamarca.com/c/produto"
          mono
        />

        {/* UTM */}
        <Grid2>
          <Field
            label="UTM source"
            value={config.utmSource}
            onChange={(v) => set("utmSource", v)}
            mono
          />
          <Field
            label="UTM medium"
            value={config.utmMedium}
            onChange={(v) => set("utmMedium", v)}
            mono
          />
        </Grid2>
        <Field
          label="UTM campaign"
          value={config.utmCampaign}
          onChange={(v) => set("utmCampaign", v)}
          mono
          placeholder="Ex: black-friday-2024"
        />

        <Field
          label="Notas internas (não vai pra API)"
          value={config.notes ?? ""}
          onChange={(v) => set("notes", v)}
          multiline
        />
      </Section>
    </>
  );
}

/* =================== TIKTOK FORM =================== */

function TiktokForm({
  config,
  setConfig,
  pixels,
}: {
  config: TiktokConfig;
  setConfig: React.Dispatch<React.SetStateAction<TiktokConfig>>;
  pixels: Pixel[];
}) {
  const set = <K extends keyof TiktokConfig>(k: K, v: TiktokConfig[K]) =>
    setConfig((c) => ({ ...c, [k]: v }));
  const setT = <K extends keyof TiktokConfig["targeting"]>(
    k: K,
    v: TiktokConfig["targeting"][K],
  ) => setConfig((c) => ({ ...c, targeting: { ...c.targeting, [k]: v } }));

  return (
    <>
      <Section
        title="Campanha"
        icon={Music2}
        subtitle="Objetivo, tipo (Regular/Smart+), orçamento"
        defaultOpen
      >
        <Grid2>
          <Field
            label="Nome da campanha"
            value={config.campaignName}
            onChange={(v) => set("campaignName", v)}
            placeholder="Ex: CONV BR — Black Friday"
            icon={Rocket}
          />
          <SelectField
            label="Objetivo"
            value={config.objective}
            onChange={(v) => set("objective", v)}
            options={TIKTOK_OBJECTIVES}
            icon={Target}
          />
        </Grid2>
        <Grid2>
          <SelectField
            label="Tipo de campanha"
            value={config.campaignType}
            onChange={(v) =>
              set("campaignType", v as TiktokConfig["campaignType"])
            }
            options={[
              { value: "regular", label: "Regular" },
              { value: "smart_plus", label: "Smart+ (IA TikTok)" },
            ]}
          />
          <SelectField
            label="Modo de orçamento da campanha"
            value={config.campaignBudgetMode}
            onChange={(v) =>
              set("campaignBudgetMode", v as TiktokConfig["campaignBudgetMode"])
            }
            options={[
              { value: "BUDGET_MODE_INFINITE", label: "Sem limite" },
              { value: "BUDGET_MODE_DAY", label: "Diário (CBO)" },
              { value: "BUDGET_MODE_TOTAL", label: "Total" },
            ]}
          />
        </Grid2>
        {config.campaignBudgetMode !== "BUDGET_MODE_INFINITE" && (
          <MoneyField
            label="Orçamento da campanha (R$)"
            value={config.campaignBudgetCents ?? 0}
            onChange={(c) => set("campaignBudgetCents", c > 0 ? c : null)}
          />
        )}
      </Section>

      <Section
        title="Grupo de Anúncios (Ad Group)"
        icon={Layers}
        subtitle="Orçamento, otimização, segmentação, pixel, posicionamento"
      >
        <Grid2>
          <Field
            label="Nome do ad group"
            value={config.adGroupName}
            onChange={(v) => set("adGroupName", v)}
            placeholder="Ex: BR 18-44 — Conversão"
          />
          <MoneyField
            label="Orçamento diário do ad group (R$ — mín R$ 20)"
            value={config.adGroupDailyBudgetCents}
            onChange={(c) => set("adGroupDailyBudgetCents", c)}
          />
        </Grid2>
        <Grid2>
          <SelectField
            label="Schedule"
            value={config.scheduleType}
            onChange={(v) =>
              set("scheduleType", v as TiktokConfig["scheduleType"])
            }
            options={[
              { value: "SCHEDULE_FROM_NOW", label: "Iniciar agora (sem fim)" },
              { value: "SCHEDULE_START_END", label: "Definir início + fim" },
            ]}
          />
          <Field
            label="Início (opcional)"
            type="date"
            value={config.startDate ?? ""}
            onChange={(v) => set("startDate", v || null)}
          />
        </Grid2>
        {config.scheduleType === "SCHEDULE_START_END" && (
          <Field
            label="Fim"
            type="date"
            value={config.endDate ?? ""}
            onChange={(v) => set("endDate", v || null)}
          />
        )}
        <Grid2>
          <SelectField
            label="Meta de otimização"
            value={config.optimizationGoal}
            onChange={(v) => set("optimizationGoal", v)}
            options={TIKTOK_OPTIMIZATION_GOALS}
          />
          <SelectField
            label="Evento de conversão"
            value={config.conversionEvent}
            onChange={(v) => set("conversionEvent", v)}
            options={TIKTOK_CONVERSION_EVENTS.map((e) => ({
              value: e,
              label: e,
            }))}
          />
        </Grid2>
        <Grid2>
          <SelectField
            label="Janela de atribuição"
            value={config.attributionWindow}
            onChange={(v) => set("attributionWindow", v)}
            options={[
              { value: "CLICK_1D", label: "Clique 1 dia" },
              { value: "CLICK_7D", label: "Clique 7 dias" },
              { value: "CLICK_28D", label: "Clique 28 dias" },
              { value: "VIEW_1D", label: "Visualização 1 dia" },
              { value: "VIEW_7D", label: "Visualização 7 dias" },
            ]}
          />
          <SelectField
            label="Estratégia de lance"
            value={config.biddingType}
            onChange={(v) => set("biddingType", v)}
            options={[
              { value: "BID_TYPE_NO_BID", label: "Sem lance manual (custo mais baixo)" },
              { value: "BID_TYPE_CUSTOM", label: "Lance customizado (Cost Cap)" },
              { value: "BID_TYPE_MAX_CONVERSION", label: "Max conversões" },
            ]}
          />
        </Grid2>
        {config.biddingType !== "BID_TYPE_NO_BID" && (
          <MoneyField
            label="Preço de lance (R$)"
            value={config.bidPriceCents ?? 0}
            onChange={(c) => set("bidPriceCents", c > 0 ? c : null)}
          />
        )}

        <PixelPicker
          pixels={pixels}
          selectedId={config.pixelId ?? ""}
          onChange={(p) => {
            set("pixelId", p?.id ?? null);
            set("pixelName", p?.name ?? null);
          }}
        />

        <div className="space-y-2">
          <p className="text-[10px] uppercase tracking-wider text-zinc-500 font-semibold">
            Posicionamentos
          </p>
          <div className="flex gap-2">
            {(
              [
                { v: "PLACEMENT_TYPE_AUTOMATIC", label: "Automático" },
                { v: "PLACEMENT_TYPE_NORMAL", label: "Manual" },
              ] as const
            ).map((opt) => (
              <button
                key={opt.v}
                type="button"
                onClick={() => set("placementType", opt.v)}
                className={`px-3 py-1.5 rounded-full border text-xs ${
                  config.placementType === opt.v
                    ? "border-pink-400 bg-pink-400/10 text-pink-200"
                    : "border-white/10 bg-white/[0.04] text-zinc-400"
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
          {config.placementType === "PLACEMENT_TYPE_NORMAL" && (
            <MultiCheckField
              options={TIKTOK_PLACEMENTS}
              value={config.placements}
              onChange={(v) => set("placements", v)}
            />
          )}
        </div>

        {/* TARGETING TIKTOK */}
        <div className="space-y-3 rounded-lg border border-white/[0.06] bg-black/20 p-3">
          <p className="text-[10px] uppercase tracking-wider text-zinc-500 font-semibold inline-flex items-center gap-1.5">
            <Users className="size-3" /> Segmentação
          </p>
          <Field
            label="Países (ISO, vírgulas)"
            value={config.targeting.countries.join(", ")}
            onChange={(v) =>
              setT(
                "countries",
                v
                  .split(",")
                  .map((s) => s.trim().toUpperCase())
                  .filter(Boolean),
              )
            }
            placeholder="BR, PT, AR"
          />
          <MultiChipField
            label="Faixas etárias"
            options={TIKTOK_AGE_GROUPS.map((a) => a.value)}
            value={config.targeting.ageGroups}
            onChange={(v) => setT("ageGroups", v)}
            labelMap={Object.fromEntries(
              TIKTOK_AGE_GROUPS.map((a) => [a.value, a.label]),
            )}
          />
          <MultiChipField
            label="Gêneros"
            options={["all", "male", "female"]}
            value={config.targeting.genders}
            onChange={(v) =>
              setT("genders", v as ("all" | "male" | "female")[])
            }
            labelMap={{ all: "Todos", male: "Masculino", female: "Feminino" }}
          />
          <Field
            label="Idiomas"
            value={config.targeting.languages.join(", ")}
            onChange={(v) =>
              setT(
                "languages",
                v.split(",").map((s) => s.trim()).filter(Boolean),
              )
            }
            placeholder="pt, en"
          />
          <Field
            label="Categorias de interesse"
            value={config.targeting.interestCategories.join(", ")}
            onChange={(v) =>
              setT(
                "interestCategories",
                v.split(",").map((s) => s.trim()).filter(Boolean),
              )
            }
            placeholder="beauty, fashion, fitness"
          />
          <Field
            label="Categorias de comportamento"
            value={config.targeting.behaviorCategories.join(", ")}
            onChange={(v) =>
              setT(
                "behaviorCategories",
                v.split(",").map((s) => s.trim()).filter(Boolean),
              )
            }
            placeholder="recent_purchasers, video_viewers"
          />
          <Field
            label="Hashtags-alvo (#hashtag, vírgulas)"
            value={config.targeting.hashtags.join(", ")}
            onChange={(v) =>
              setT(
                "hashtags",
                v.split(",").map((s) => s.trim()).filter(Boolean),
              )
            }
            placeholder="#fyp, #skincare"
          />
          <Grid2>
            <Field
              label="Públicos personalizados (IDs)"
              value={config.targeting.customAudiences.join(", ")}
              onChange={(v) =>
                setT(
                  "customAudiences",
                  v.split(",").map((s) => s.trim()).filter(Boolean),
                )
              }
              mono
            />
            <Field
              label="Lookalikes (IDs)"
              value={config.targeting.lookalikes.join(", ")}
              onChange={(v) =>
                setT(
                  "lookalikes",
                  v.split(",").map((s) => s.trim()).filter(Boolean),
                )
              }
              mono
            />
          </Grid2>
        </div>

        <Grid2>
          <Field
            label="Frequência máx (impressões)"
            type="number"
            value={String(config.frequencyCap ?? "")}
            onChange={(v) => set("frequencyCap", v ? Number(v) : null)}
            placeholder="Ex: 3"
          />
          <Field
            label="Janela frequência (dias)"
            type="number"
            value={String(config.frequencyCapDays ?? "")}
            onChange={(v) => set("frequencyCapDays", v ? Number(v) : null)}
            placeholder="Ex: 7"
          />
        </Grid2>
      </Section>

      <Section
        title="Anúncio (Ad)"
        icon={ImageIcon}
        subtitle="Identidade, vídeo, texto, CTA"
      >
        <Grid2>
          <Field
            label="Nome do ad"
            value={config.adName}
            onChange={(v) => set("adName", v)}
          />
          <SelectField
            label="Formato"
            value={config.adFormat}
            onChange={(v) =>
              set("adFormat", v as TiktokConfig["adFormat"])
            }
            options={TIKTOK_AD_FORMATS}
          />
        </Grid2>
        {config.adFormat === "SPARK_AD" && (
          <div className="rounded-lg border border-pink-400/20 bg-pink-400/[0.04] p-3 space-y-3">
            <p className="text-[11px] text-pink-200/80">
              Spark Ad impulsiona um <strong>post orgânico já existente</strong>.
              Cole o <strong>item ID</strong> do post + a <strong>identity
              TT_User</strong> (conta dona, autorizada pra ads). Nesse modo o
              upload de vídeo abaixo é ignorado.
            </p>
            <Grid2>
              <Field
                label="Post TikTok (item ID)"
                value={config.sparkTiktokItemId ?? ""}
                onChange={(v) => set("sparkTiktokItemId", v)}
                mono
                placeholder="ex: 7300000000000000000"
              />
              <Field
                label="Identity TT_User (ID)"
                value={config.sparkIdentityId ?? ""}
                onChange={(v) => set("sparkIdentityId", v)}
                mono
                placeholder="identity_id da conta autorizada"
              />
            </Grid2>
          </div>
        )}
        <Grid2>
          <SelectField
            label="Tipo de identidade"
            value={config.identityType}
            onChange={(v) =>
              set("identityType", v as TiktokConfig["identityType"])
            }
            options={[
              { value: "CUSTOMIZED_USER", label: "Usuário customizado" },
              { value: "TT_USER", label: "Conta TikTok autenticada" },
              { value: "AUTH_CODE", label: "Auth code (Spark Ad)" },
            ]}
          />
          <Field
            label="Nome de exibição"
            value={config.identityDisplayName ?? ""}
            onChange={(v) => set("identityDisplayName", v)}
            placeholder="Ex: SuaMarca Oficial"
          />
        </Grid2>
        <Field
          label="URL da foto de perfil"
          value={config.identityImageUrl ?? ""}
          onChange={(v) => set("identityImageUrl", v)}
          mono
          placeholder="https://cdn.suamarca.com/logo.png"
        />
        {config.adFormat !== "SPARK_AD" && (
          <UrlListField
            label="URLs dos vídeos (máx 20)"
            value={config.creativeMediaUrls}
            onChange={(v) => set("creativeMediaUrls", v)}
            placeholder="https://cdn.suamarca.com/tiktok-001.mp4"
          />
        )}
        <Field
          label="Texto do anúncio (máx 100 chars)"
          value={config.adText}
          onChange={(v) => set("adText", v.slice(0, 100))}
          multiline
          placeholder="Pele perfeita em 30 dias. Garantia."
        />
        <SelectField
          label="Call to Action"
          value={config.callToAction}
          onChange={(v) => set("callToAction", v)}
          options={TIKTOK_CTA}
        />
        <Field
          label="URL de destino"
          value={config.landingUrl}
          onChange={(v) => set("landingUrl", v)}
          mono
          placeholder="https://checkout.suamarca.com/c/produto"
        />
        <Grid2>
          <Field
            label="UTM source"
            value={config.utmSource}
            onChange={(v) => set("utmSource", v)}
            mono
          />
          <Field
            label="UTM medium"
            value={config.utmMedium}
            onChange={(v) => set("utmMedium", v)}
            mono
          />
        </Grid2>
        <Field
          label="UTM campaign"
          value={config.utmCampaign}
          onChange={(v) => set("utmCampaign", v)}
          mono
        />
        <Field
          label="Notas internas (não vai pra API)"
          value={config.notes ?? ""}
          onChange={(v) => set("notes", v)}
          multiline
        />
      </Section>
    </>
  );
}

/* =================== HELPERS =================== */

function Section({
  title,
  subtitle,
  icon: Icon,
  defaultOpen = false,
  children,
}: {
  title: string;
  subtitle?: string;
  icon: React.ComponentType<{ className?: string }>;
  defaultOpen?: boolean;
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="rounded-2xl border border-white/[0.08] bg-white/[0.02] overflow-hidden">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-3 px-4 py-3 hover:bg-white/[0.03] transition"
      >
        <span className="inline-flex size-8 items-center justify-center rounded-lg bg-lime-400/10 text-lime-300">
          <Icon className="size-4" />
        </span>
        <div className="flex-1 text-left">
          <p className="text-sm font-semibold text-white">{title}</p>
          {subtitle && (
            <p className="text-[11px] text-zinc-500">{subtitle}</p>
          )}
        </div>
        {open ? (
          <ChevronDown className="size-4 text-zinc-500" />
        ) : (
          <ChevronRight className="size-4 text-zinc-500" />
        )}
      </button>
      {open && (
        <div className="border-t border-white/[0.06] p-4 space-y-3">{children}</div>
      )}
    </div>
  );
}

function Grid2({ children }: { children: React.ReactNode }) {
  return <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">{children}</div>;
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
  icon: Icon,
  mono,
  multiline,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
  icon?: React.ComponentType<{ className?: string }>;
  mono?: boolean;
  multiline?: boolean;
}) {
  return (
    <label className="block">
      <span className="text-[10px] uppercase tracking-wider text-zinc-500 inline-flex items-center gap-1">
        {Icon && <Icon className="size-3" />}
        {label}
      </span>
      {multiline ? (
        <textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          rows={3}
          className={`mt-1 w-full rounded-lg border border-white/[0.08] bg-white/[0.02] px-3 py-2 text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-lime-400/40 ${
            mono ? "font-mono" : ""
          }`}
        />
      ) : (
        <input
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className={`mt-1 w-full rounded-lg border border-white/[0.08] bg-white/[0.02] px-3 py-2 text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-lime-400/40 ${
            mono ? "font-mono" : ""
          }`}
        />
      )}
    </label>
  );
}

function SelectField({
  label,
  value,
  onChange,
  options,
  icon: Icon,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
  icon?: React.ComponentType<{ className?: string }>;
}) {
  return (
    <label className="block">
      <span className="text-[10px] uppercase tracking-wider text-zinc-500 inline-flex items-center gap-1">
        {Icon && <Icon className="size-3" />}
        {label}
      </span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full rounded-lg border border-white/[0.08] bg-white/[0.02] px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-lime-400/40"
      >
        {options.map((o) => (
          <option key={o.value} value={o.value} className="bg-zinc-900">
            {o.label}
          </option>
        ))}
      </select>
    </label>
  );
}

function MoneyField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: number;
  onChange: (cents: number) => void;
}) {
  const [text, setText] = useState((value / 100).toFixed(2));
  return (
    <label className="block">
      <span className="text-[10px] uppercase tracking-wider text-zinc-500 inline-flex items-center gap-1">
        {label}
      </span>
      <input
        type="text"
        inputMode="decimal"
        value={text}
        onChange={(e) => {
          setText(e.target.value);
          const n = Number(e.target.value.replace(",", "."));
          if (Number.isFinite(n)) onChange(Math.round(n * 100));
        }}
        className="mt-1 w-full rounded-lg border border-white/[0.08] bg-white/[0.02] px-3 py-2 text-sm text-white tabular-nums focus:outline-none focus:ring-2 focus:ring-lime-400/40"
      />
    </label>
  );
}

function MultiCheckField({
  options,
  value,
  onChange,
}: {
  options: { value: string; label: string }[];
  value: string[];
  onChange: (v: string[]) => void;
}) {
  function toggle(v: string) {
    if (value.includes(v)) onChange(value.filter((x) => x !== v));
    else onChange([...value, v]);
  }
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
      {options.map((o) => {
        const active = value.includes(o.value);
        return (
          <button
            key={o.value}
            type="button"
            onClick={() => toggle(o.value)}
            className={`text-left text-[11px] px-2.5 py-1.5 rounded border ${
              active
                ? "border-lime-400/40 bg-lime-400/10 text-lime-200"
                : "border-white/[0.08] bg-black/30 text-zinc-300 hover:bg-white/[0.04]"
            }`}
          >
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

function MultiChipField({
  label,
  options,
  value,
  onChange,
  labelMap,
}: {
  label?: string;
  options: string[];
  value: string[];
  onChange: (v: string[]) => void;
  labelMap?: Record<string, string>;
}) {
  function toggle(v: string) {
    if (value.includes(v)) onChange(value.filter((x) => x !== v));
    else onChange([...value, v]);
  }
  return (
    <div>
      {label && (
        <p className="text-[10px] uppercase tracking-wider text-zinc-500 mb-1">
          {label}
        </p>
      )}
      <div className="flex flex-wrap gap-1.5">
        {options.map((o) => {
          const active = value.includes(o);
          return (
            <button
              key={o}
              type="button"
              onClick={() => toggle(o)}
              className={`text-[11px] px-2.5 py-1 rounded-full border ${
                active
                  ? "border-lime-400/40 bg-lime-400/10 text-lime-200"
                  : "border-white/[0.08] bg-black/30 text-zinc-300 hover:bg-white/[0.04]"
              }`}
            >
              {labelMap?.[o] ?? o}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function UrlListField({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string[];
  onChange: (v: string[]) => void;
  placeholder?: string;
}) {
  const [draft, setDraft] = useState("");
  return (
    <div>
      <p className="text-[10px] uppercase tracking-wider text-zinc-500 inline-flex items-center gap-1 mb-1">
        <ImageIcon className="size-3" /> {label}
      </p>
      <div className="flex gap-2 mb-2">
        <input
          type="text"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && draft.trim() && value.length < 20) {
              e.preventDefault();
              onChange([...value, draft.trim()]);
              setDraft("");
            }
          }}
          placeholder={placeholder}
          className="flex-1 rounded-lg border border-white/[0.08] bg-white/[0.02] px-3 py-2 text-sm text-white placeholder:text-zinc-500 font-mono"
        />
        <button
          type="button"
          onClick={() => {
            if (draft.trim() && value.length < 20) {
              onChange([...value, draft.trim()]);
              setDraft("");
            }
          }}
          className="inline-flex items-center gap-1 rounded-lg bg-white/[0.06] px-3 text-xs text-zinc-200 hover:bg-white/[0.10]"
        >
          <Plus className="size-3" /> Add
        </button>
      </div>
      {value.length > 0 && (
        <ul className="space-y-1">
          {value.map((url, i) => (
            <li
              key={`${url}-${i}`}
              className="flex items-center gap-2 rounded-md border border-white/[0.06] bg-black/20 px-2 py-1.5 text-[11px]"
            >
              <span className="font-mono text-zinc-400 truncate flex-1">
                {url}
              </span>
              <button
                type="button"
                onClick={() => onChange(value.filter((_, j) => j !== i))}
                className="text-zinc-500 hover:text-red-300"
              >
                <Trash2 className="size-3" />
              </button>
            </li>
          ))}
        </ul>
      )}
      <p className="text-[9px] text-zinc-600 mt-1">
        {value.length}/20 — Enter pra adicionar
      </p>
    </div>
  );
}

function PixelPicker({
  pixels,
  selectedId,
  onChange,
}: {
  pixels: Pixel[];
  selectedId: string;
  onChange: (p: Pixel | null) => void;
}) {
  return (
    <div className="rounded-lg border border-blue-400/20 bg-blue-400/[0.04] p-3 space-y-2">
      <p className="text-[10px] uppercase tracking-wider text-blue-200/80 font-semibold inline-flex items-center gap-1.5">
        <Sparkles className="size-3" /> Pixel de Conversão
      </p>
      {pixels.length === 0 ? (
        <p className="text-[11px] text-zinc-400">
          Selecione contas de anúncio à esquerda pra ver os pixels
          disponíveis. Nenhum pixel detectado nas contas atuais.
        </p>
      ) : (
        <>
          <p className="text-[11px] text-zinc-400">
            Escolha o pixel pelo nome — não precisa do ID. Mostra pixels
            comuns nas contas selecionadas ({pixels.length} pixel(s)
            disponível(is)).
          </p>
          <select
            value={selectedId}
            onChange={(e) => {
              const id = e.target.value;
              if (id === "") onChange(null);
              else {
                const p = pixels.find((x) => x.id === id);
                onChange(p ?? null);
              }
            }}
            className="w-full rounded-lg border border-white/[0.08] bg-black/30 px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-blue-400/40"
          >
            <option value="" className="bg-zinc-900">
              — Não usar pixel —
            </option>
            {pixels.map((p) => (
              <option key={p.id} value={p.id} className="bg-zinc-900">
                {p.name} ({p.id.slice(0, 12)}…)
              </option>
            ))}
          </select>
        </>
      )}
    </div>
  );
}

function PlatformTab({
  active,
  onClick,
  icon: Icon,
  color,
  label,
  count,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ComponentType<{ className?: string }>;
  color: "blue" | "pink";
  label: string;
  count: number;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`inline-flex items-center gap-2 border-b-2 px-5 py-3 text-sm font-medium transition ${
        active
          ? color === "blue"
            ? "border-blue-400 text-blue-300 bg-blue-400/[0.05]"
            : "border-pink-400 text-pink-300 bg-pink-400/[0.05]"
          : "border-transparent text-zinc-400 hover:text-white"
      }`}
    >
      <Icon className="size-4" />
      {label}
      <span className="text-[10px] text-zinc-500">({count})</span>
    </button>
  );
}

function JobStatusBadge({ status }: { status: string }) {
  const cfg: Record<string, { label: string; cls: string }> = {
    queued: { label: "Na fila", cls: "bg-zinc-700/40 text-zinc-300" },
    running: { label: "Subindo", cls: "bg-yellow-400/15 text-yellow-200" },
    completed: { label: "Concluído", cls: "bg-lime-400/15 text-lime-200" },
    failed: { label: "Falhou", cls: "bg-red-400/15 text-red-200" },
    partial: { label: "Parcial", cls: "bg-amber-400/15 text-amber-200" },
  };
  const c = cfg[status] ?? cfg.queued;
  return (
    <span
      className={`shrink-0 inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider ${c.cls}`}
    >
      {c.label}
    </span>
  );
}
