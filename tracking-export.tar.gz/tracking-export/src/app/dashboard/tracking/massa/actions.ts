"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireSessionUserId } from "@/lib/auth-helpers";
import {
  subscribeMassCampaignWithBalance,
  createInternalPixCharge,
  hasActiveMassCampaignSubscription,
  MASS_CAMPAIGN_MONTHLY_CENTS,
  MASS_CAMPAIGN_EXTRA_UPLOAD_CENTS,
} from "@/lib/internal-purchases";
import { rateLimit, formatRetryIn } from "@/lib/rate-limit";
import { assertSafeOrigin } from "@/lib/security/origin";

/**
 * Assina mass campaign cobrando R$ 197,90 DO SALDO. Estende
 * massCampaignSubscriptionUntil em +30 dias.
 *
 * Rate-limited (3/min por user) + origin-checked pra evitar:
 *  - Double-click duplicando cobrança (race em duas abas)
 *  - CSRF (assertSafeOrigin valida origin/referer)
 */
export async function subscribeMassCampaignBalanceAction() {
  try {
    await assertSafeOrigin();
  } catch {
    return { ok: false as const, error: "Origem da requisição inválida" };
  }
  const userId = await requireSessionUserId();
  const rl = rateLimit(`mass-campaign-sub:${userId}`, 3, 60_000);
  if (!rl.ok) {
    return {
      ok: false as const,
      error: `Muitas tentativas. ${formatRetryIn(rl.resetIn)}`,
    };
  }
  const r = await subscribeMassCampaignWithBalance(userId);
  if (r.ok) {
    revalidatePath("/dashboard/tracking/massa");
    revalidatePath("/dashboard/perfil");
  }
  return r;
}

/**
 * Cria PIX (via Mercado Pago white) pra assinar mass campaign.
 * Retorna QR code / copy-paste pro cliente pagar. Webhook MP estende
 * a subscription quando PIX for confirmado.
 *
 * Rate-limited (5/min por user) + origin-checked pra evitar spam de
 * PIX (cada chamada cria InternalPurchase + chama MP API real).
 */
export async function createMassCampaignPixAction() {
  try {
    await assertSafeOrigin();
  } catch {
    return { ok: false as const, error: "Origem da requisição inválida" };
  }
  const userId = await requireSessionUserId();
  const rl = rateLimit(`mass-campaign-pix:${userId}`, 5, 60_000);
  if (!rl.ok) {
    return {
      ok: false as const,
      error: `Muitas tentativas. ${formatRetryIn(rl.resetIn)}`,
    };
  }
  const { getMassCampaignMonthlyCentsAsync } = await import("@/lib/pricing");
  const amountCents = await getMassCampaignMonthlyCentsAsync();
  return await createInternalPixCharge({
    userId,
    feature: "mass_campaign_30d",
    amountCents,
    description: "BravoPay · Subir Campanhas em Massa (30 dias)",
  });
}

/* ========== TEMPLATES + JOBS ========== */

/**
 * Estrutura COMPLETA de Mass Campaign — espelha o ad manager de Meta e
 * TikTok com 3 niveis (Campaign / Ad Set ou Ad Group / Ad).
 *
 * Plataforma-especifico: cada plataforma tem objetivos diferentes,
 * placements proprios, formatos de criativo, etc. O front escolhe qual
 * shape preencher; o backend valida ambos via discriminated union no
 * `JobInput`.
 *
 * Pixel: a pessoa escolhe PELO NOME na UI. Aqui guardamos pixelId+pixelName
 * pra rastreabilidade e pra mostrar bonito nos historicos.
 */

/* --- META ADS (Facebook Ads Manager) --- */
const MetaConfigSchema = z.object({
  /** Campaign level */
  campaignName: z.string().min(1).max(120),
  /** OUTCOME_SALES, OUTCOME_LEADS, etc */
  objective: z.string().max(40),
  /** "AUCTION" (default) | "RESERVED" */
  buyingType: z.enum(["AUCTION", "RESERVED"]).default("AUCTION"),
  /** Special ad category (Habitação, Crédito, Emprego, Issues políticas) */
  specialAdCategories: z.array(z.string()).default([]),
  /** ABO = Ad set budget / CBO = Campaign budget */
  budgetMode: z.enum(["abo", "cbo"]).default("abo"),
  /** Quando CBO, define budget na campanha */
  campaignDailyBudgetCents: z.number().int().min(100).max(10_000_000).optional(),

  /** Ad Set level */
  adSetName: z.string().min(1).max(120),
  /** Budget do AD SET — usado quando budgetMode=abo. Pra cbo ignora. */
  adSetDailyBudgetCents: z.number().int().min(100).max(10_000_000),
  /** ISO YYYY-MM-DD start date */
  startDate: z.string().max(20).optional().nullable(),
  endDate: z.string().max(20).optional().nullable(),
  /** Optimization goal (LANDING_PAGE_VIEWS, OFFSITE_CONVERSIONS, PURCHASE, etc) */
  optimizationGoal: z.string().max(60).default("OFFSITE_CONVERSIONS"),
  /** Bid strategy */
  bidStrategy: z
    .enum([
      "LOWEST_COST_WITHOUT_CAP",
      "LOWEST_COST_WITH_BID_CAP",
      "COST_CAP",
      "LOWEST_COST_WITH_MIN_ROAS",
    ])
    .default("LOWEST_COST_WITHOUT_CAP"),
  bidAmountCents: z.number().int().min(0).max(10_000_000).optional().nullable(),
  /** Conversion event (Purchase, AddToCart, Lead, etc) */
  conversionEvent: z.string().max(60).default("Purchase"),
  /** Pixel ESCOLHIDO pelo nome (UI). Backend guarda id + name pra historico. */
  pixelId: z.string().max(200).optional().nullable(),
  pixelName: z.string().max(120).optional().nullable(),
  /** Catalog ID (opcional — DSA/Advantage+) */
  catalogId: z.string().max(200).optional().nullable(),
  useCatalog: z.boolean().default(false),
  /** Placements: Advantage+ (auto) ou manual com lista */
  placementMode: z.enum(["advantage_plus", "manual"]).default("advantage_plus"),
  placements: z
    .array(
      z.enum([
        "facebook_feed",
        "instagram_feed",
        "instagram_stories",
        "facebook_stories",
        "instagram_reels",
        "facebook_reels",
        "facebook_marketplace",
        "facebook_video_feeds",
        "instagram_explore",
        "messenger_inbox",
        "audience_network",
      ]),
    )
    .default([]),
  /** Targeting */
  targeting: z.object({
    countries: z.array(z.string()).default(["BR"]),
    ageMin: z.number().int().min(13).max(65).default(18),
    ageMax: z.number().int().min(13).max(65).default(65),
    genders: z.array(z.enum(["all", "male", "female"])).default(["all"]),
    languages: z.array(z.string()).default([]),
    interests: z.array(z.string()).default([]),
    behaviors: z.array(z.string()).default([]),
    customAudiences: z.array(z.string()).default([]),
    lookalikes: z.array(z.string()).default([]),
    excludeCustomAudiences: z.array(z.string()).default([]),
    locationType: z.enum(["everyone", "people_living", "recent_visitors"]).default("everyone"),
  }),

  /** Ad level */
  adName: z.string().min(1).max(120),
  /** Identity: page Facebook + Instagram account (IDs string) */
  pageId: z.string().max(120).optional().nullable(),
  instagramAccountId: z.string().max(120).optional().nullable(),
  /** Creative — formato e mídia */
  adFormat: z
    .enum(["SINGLE_IMAGE", "SINGLE_VIDEO", "CAROUSEL", "COLLECTION"])
    .default("SINGLE_VIDEO"),
  /** URLs das mídias (cada upload é distribuido pra todas as contas) */
  creativeMediaUrls: z.array(z.string().max(500)).max(20).default([]),
  primaryText: z.string().max(500).default(""),
  headline: z.string().max(120).default(""),
  description: z.string().max(200).default(""),
  /** CTA button (SHOP_NOW, LEARN_MORE, SIGN_UP, etc) */
  callToAction: z.string().max(40).default("SHOP_NOW"),
  /** URL de destino (link da oferta) */
  landingUrl: z.string().max(500),
  displayLink: z.string().max(200).optional().nullable(),
  /** UTM tags (vai pra URL via append) */
  utmSource: z.string().max(60).default("facebook"),
  utmMedium: z.string().max(60).default("paid"),
  utmCampaign: z.string().max(120).default(""),

  /** Notas pra historico (nao vai pra API) */
  notes: z.string().max(500).optional().nullable(),
});

/* --- TIKTOK ADS (TikTok Ads Manager) --- */
const TiktokConfigSchema = z.object({
  /** Campaign level */
  campaignName: z.string().min(1).max(120),
  /** CONVERSIONS, REACH, TRAFFIC, VIDEO_VIEWS, LEAD_GENERATION, APP_PROMOTION */
  objective: z.string().max(40),
  /** "Regular" (default) | "Smart+" */
  campaignType: z.enum(["regular", "smart_plus"]).default("regular"),
  /** Budget mode: BUDGET_MODE_INFINITE | BUDGET_MODE_DAY | BUDGET_MODE_TOTAL */
  campaignBudgetMode: z
    .enum(["BUDGET_MODE_INFINITE", "BUDGET_MODE_DAY", "BUDGET_MODE_TOTAL"])
    .default("BUDGET_MODE_INFINITE"),
  campaignBudgetCents: z
    .number()
    .int()
    .min(0)
    .max(10_000_000)
    .optional()
    .nullable(),
  /** Special category (Habitação, etc) */
  specialIndustries: z.array(z.string()).default([]),

  /** Ad Group level */
  adGroupName: z.string().min(1).max(120),
  /** Ad Group budget */
  adGroupBudgetMode: z
    .enum(["BUDGET_MODE_DAY", "BUDGET_MODE_TOTAL"])
    .default("BUDGET_MODE_DAY"),
  adGroupDailyBudgetCents: z.number().int().min(2000).max(10_000_000), // TikTok mínimo $20/dia
  /** ISO date strings */
  startDate: z.string().max(20).optional().nullable(),
  endDate: z.string().max(20).optional().nullable(),
  /** Schedule: ALL_DAY | DAY_PARTING */
  scheduleType: z.enum(["SCHEDULE_FROM_NOW", "SCHEDULE_START_END"]).default("SCHEDULE_FROM_NOW"),
  /** Optimization goal: CONVERSION, CLICK, REACH, etc */
  optimizationGoal: z.string().max(60).default("CONVERSION"),
  /** Pixel pelo NOME */
  pixelId: z.string().max(200).optional().nullable(),
  pixelName: z.string().max(120).optional().nullable(),
  /** Conversion event (COMPLETE_PAYMENT, ADD_TO_CART, etc) */
  conversionEvent: z.string().max(60).default("COMPLETE_PAYMENT"),
  /** Attribution window */
  attributionWindow: z
    .enum(["CLICK_1D", "CLICK_7D", "CLICK_28D", "VIEW_1D", "VIEW_7D"])
    .default("CLICK_7D"),
  /** Bidding */
  biddingType: z
    .enum(["BID_TYPE_NO_BID", "BID_TYPE_CUSTOM", "BID_TYPE_MAX_CONVERSION"])
    .default("BID_TYPE_NO_BID"),
  bidPriceCents: z.number().int().min(0).max(10_000_000).optional().nullable(),
  /** Placements */
  placementType: z.enum(["PLACEMENT_TYPE_AUTOMATIC", "PLACEMENT_TYPE_NORMAL"]).default(
    "PLACEMENT_TYPE_AUTOMATIC",
  ),
  placements: z
    .array(z.enum(["PLACEMENT_TIKTOK", "PLACEMENT_PANGLE", "PLACEMENT_GLOBAL_APP_BUNDLE"]))
    .default([]),
  /** Targeting */
  targeting: z.object({
    countries: z.array(z.string()).default(["BR"]),
    ageGroups: z
      .array(
        z.enum([
          "AGE_13_17",
          "AGE_18_24",
          "AGE_25_34",
          "AGE_35_44",
          "AGE_45_54",
          "AGE_55_100",
        ]),
      )
      .default(["AGE_18_24", "AGE_25_34", "AGE_35_44", "AGE_45_54"]),
    genders: z.array(z.enum(["all", "male", "female"])).default(["all"]),
    languages: z.array(z.string()).default([]),
    interestCategories: z.array(z.string()).default([]),
    behaviorCategories: z.array(z.string()).default([]),
    hashtags: z.array(z.string()).default([]),
    customAudiences: z.array(z.string()).default([]),
    lookalikes: z.array(z.string()).default([]),
    excludeCustomAudiences: z.array(z.string()).default([]),
  }),
  /** Spending budget (frequencia) */
  frequencyCap: z.number().int().min(0).max(100).optional().nullable(),
  frequencyCapDays: z.number().int().min(1).max(30).optional().nullable(),

  /** Ad level (TikTok ad) */
  adName: z.string().min(1).max(120),
  /** Identity (TikTok account) */
  identityType: z.enum(["CUSTOMIZED_USER", "AUTH_CODE", "TT_USER"]).default("CUSTOMIZED_USER"),
  identityDisplayName: z.string().max(60).optional().nullable(),
  identityImageUrl: z.string().max(500).optional().nullable(),
  /** SPARK AD: id do post orgânico do TikTok a impulsionar (tiktok_item_id) */
  sparkTiktokItemId: z.string().max(120).optional().nullable(),
  /** SPARK AD: identity TT_USER (conta dona do post autorizado) */
  sparkIdentityId: z.string().max(120).optional().nullable(),
  /** Creative */
  adFormat: z
    .enum(["SINGLE_VIDEO", "CAROUSEL", "SPARK_AD", "COLLECTION"])
    .default("SINGLE_VIDEO"),
  creativeMediaUrls: z.array(z.string().max(500)).max(20).default([]),
  adText: z.string().max(100).default(""), // TikTok limit 100 chars
  callToAction: z.string().max(40).default("SHOP_NOW"),
  landingUrl: z.string().max(500),
  /** UTM */
  utmSource: z.string().max(60).default("tiktok"),
  utmMedium: z.string().max(60).default("paid"),
  utmCampaign: z.string().max(120).default(""),

  notes: z.string().max(500).optional().nullable(),
});

/**
 * Config union — discriminated por platform (no parent). Cada plataforma
 * tem seu shape proprio.
 */
const ConfigSchema = z.union([MetaConfigSchema, TiktokConfigSchema]);

const TemplateInput = z
  .object({
    name: z.string().min(2).max(120),
    platform: z.enum(["meta", "tiktok"]),
    config: z.unknown(),
  })
  .superRefine((data, ctx) => {
    // Valida o config conforme a plataforma — cada uma tem shape proprio
    const schema =
      data.platform === "meta" ? MetaConfigSchema : TiktokConfigSchema;
    const parsed = schema.safeParse(data.config);
    if (!parsed.success) {
      for (const issue of parsed.error.issues) {
        ctx.addIssue({
          ...issue,
          path: ["config", ...(issue.path ?? [])],
        });
      }
    }
  });

/**
 * Salva ou atualiza um template de mass campaign.
 * Templates podem ser reusados pra publicar a mesma config em batches
 * diferentes ao longo do tempo.
 */
export async function saveMassCampaignTemplate(
  input: z.infer<typeof TemplateInput> & { id?: string },
) {
  const userId = await requireSessionUserId();
  // Paywall
  const hasSub = await hasActiveMassCampaignSubscription(userId);
  if (!hasSub) {
    return { ok: false as const, error: "Assinatura inativa" };
  }
  const parsed = TemplateInput.safeParse(input);
  if (!parsed.success) {
    return { ok: false as const, error: "Dados inválidos" };
  }

  if (input.id) {
    const own = await prisma.massCampaignTemplate.findFirst({
      where: { id: input.id, userId },
      select: { id: true },
    });
    if (!own) return { ok: false as const, error: "Template não encontrado" };
    await prisma.massCampaignTemplate.update({
      where: { id: input.id },
      data: {
        name: parsed.data.name,
        platform: parsed.data.platform,
        config: parsed.data.config as never,
      },
    });
    revalidatePath("/dashboard/tracking/massa");
    return { ok: true as const, id: input.id };
  }

  const t = await prisma.massCampaignTemplate.create({
    data: {
      userId,
      name: parsed.data.name,
      platform: parsed.data.platform,
      config: parsed.data.config as never,
    },
  });
  revalidatePath("/dashboard/tracking/massa");
  return { ok: true as const, id: t.id };
}

export async function deleteMassCampaignTemplate(id: string) {
  const userId = await requireSessionUserId();
  await prisma.massCampaignTemplate.deleteMany({ where: { id, userId } });
  revalidatePath("/dashboard/tracking/massa");
  return { ok: true as const };
}

const JobInput = z
  .object({
    platform: z.enum(["meta", "tiktok"]),
    templateId: z.string().optional().nullable(),
    targetAdAccountIds: z.array(z.string()).min(1, "Selecione ao menos 1 conta"),
    campaignsPerAccount: z.number().int().min(1).max(20).default(1),
    adsetsPerCampaign: z.number().int().min(1).max(20).default(1),
    adsPerAdset: z.number().int().min(1).max(20).default(1),
    config: z.unknown(),
  })
  .superRefine((data, ctx) => {
    const schema =
      data.platform === "meta" ? MetaConfigSchema : TiktokConfigSchema;
    const parsed = schema.safeParse(data.config);
    if (!parsed.success) {
      for (const issue of parsed.error.issues) {
        ctx.addIssue({
          ...issue,
          path: ["config", ...(issue.path ?? [])],
        });
      }
    }
  });

/**
 * Enfileira um job de mass campaign upload. O processador (cron) le os
 * jobs com status=queued e dispara chamadas reais pra Meta/TikTok API.
 *
 * Status inicial: "queued" — o cron pega na proxima rodada.
 */
export async function queueMassCampaignJob(input: z.infer<typeof JobInput>) {
  const userId = await requireSessionUserId();
  const hasSub = await hasActiveMassCampaignSubscription(userId);
  if (!hasSub) {
    return { ok: false as const, error: "Assinatura inativa" };
  }
  const parsed = JobInput.safeParse(input);
  if (!parsed.success) {
    return {
      ok: false as const,
      error: parsed.error.flatten().formErrors[0] ?? "Dados inválidos",
    };
  }

  // Verifica que todas as ad accounts sao do user
  const owned = await prisma.adAccount.findMany({
    where: {
      id: { in: parsed.data.targetAdAccountIds },
      userId,
      platform: parsed.data.platform,
    },
    select: { id: true },
  });
  if (owned.length !== parsed.data.targetAdAccountIds.length) {
    return {
      ok: false as const,
      error: "Uma ou mais contas de anúncio não pertencem a você",
    };
  }

  // BILLING (auditoria jun/2026): consome 1 upload. Antes NADA era cobrado —
  // qualquer assinante fazia uploads ILIMITADOS de graça (bypass de receita).
  // Agora: se há free uploads do ciclo, decrementa 1 (atômico); senão cobra
  // MASS_CAMPAIGN_EXTRA_UPLOAD_CENTS do saldo (atômico, não-negativo). Se não
  // tem free nem saldo, bloqueia.
  const freeClaim = await prisma.user.updateMany({
    where: { id: userId, massCampaignFreeUploadsLeft: { gt: 0 } },
    data: { massCampaignFreeUploadsLeft: { decrement: 1 } },
  });
  if (freeClaim.count === 0) {
    const paid = await prisma.user.updateMany({
      where: { id: userId, balanceCents: { gte: MASS_CAMPAIGN_EXTRA_UPLOAD_CENTS } },
      data: { balanceCents: { decrement: MASS_CAMPAIGN_EXTRA_UPLOAD_CENTS } },
    });
    if (paid.count === 0) {
      return {
        ok: false as const,
        error: `Sem uploads grátis no ciclo e saldo insuficiente (R$${(
          MASS_CAMPAIGN_EXTRA_UPLOAD_CENTS / 100
        ).toFixed(2)} por upload extra).`,
      };
    }
  }

  const job = await prisma.massCampaignJob.create({
    data: {
      userId,
      templateId: parsed.data.templateId ?? null,
      platform: parsed.data.platform,
      status: "queued",
      targetAdAccountIds: parsed.data.targetAdAccountIds,
      campaignsPerAccount: parsed.data.campaignsPerAccount,
      adsetsPerCampaign: parsed.data.adsetsPerCampaign,
      adsPerAdset: parsed.data.adsPerAdset,
      config: parsed.data.config as never,
    },
  });

  // Incrementa contador de uploads do user (UX/metric)
  await prisma.user.update({
    where: { id: userId },
    data: { massCampaignUploadsCount: { increment: 1 } },
  });

  revalidatePath("/dashboard/tracking/massa");
  return { ok: true as const, id: job.id };
}
