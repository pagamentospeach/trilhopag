import {
  Rocket,
  Layers,
  Target,
  Zap,
  CheckCircle2,
} from "lucide-react";
import { prisma } from "@/lib/prisma";
import { requireSessionUserId } from "@/lib/auth-helpers";
import {
  hasActiveMassCampaignSubscription,
  MASS_CAMPAIGN_MONTHLY_CENTS,
} from "@/lib/internal-purchases";
import { MassaSubscriptionClient } from "./client";
import { MassUploaderClient } from "./uploader-client";

export const dynamic = "force-dynamic";

export default async function MassaPage() {
  const userId = await requireSessionUserId();
  const [user, hasSubscription, pendingPix, adAccounts, templates, recentJobs] =
    await Promise.all([
      prisma.user.findUnique({
        where: { id: userId },
        select: {
          balanceCents: true,
          massCampaignSubscriptionUntil: true,
          massCampaignUploadsCount: true,
          massCampaignFreeUploadsLeft: true,
        },
      }),
      hasActiveMassCampaignSubscription(userId),
      prisma.internalPurchase.findFirst({
        where: {
          userId,
          feature: "mass_campaign_30d",
          status: "pending",
          paymentMethod: "pix",
          pixExpiresAt: { gt: new Date() },
        },
        orderBy: { createdAt: "desc" },
      }),
      prisma.adAccount.findMany({
        where: {
          userId,
          platform: { in: ["meta", "tiktok"] },
          status: "active",
          enabled: true,
        },
        select: {
          id: true,
          platform: true,
          accountId: true,
          accountName: true,
          profileName: true,
          pixels: true,
        },
        orderBy: [{ platform: "asc" }, { profileName: "asc" }],
      }),
      prisma.massCampaignTemplate.findMany({
        where: { userId },
        orderBy: { updatedAt: "desc" },
        take: 30,
      }),
      prisma.massCampaignJob.findMany({
        where: { userId },
        orderBy: { createdAt: "desc" },
        take: 10,
      }),
    ]);

  // Quando NÃO comprou: mostra header + paywall + cards informativos.
  // Quando comprou: SOMENTE o uploader (sem ruído visual).
  if (!hasSubscription) {
    return (
      <div className="mx-auto max-w-5xl space-y-6">
        <header>
          <p className="text-xs uppercase tracking-[0.2em] text-yellow-400">
            Recurso pago · R$ 697,00/mês
          </p>
          <h1 className="mt-2 flex items-center gap-3 text-3xl font-semibold tracking-tight">
            <Rocket className="size-6 text-yellow-400" />
            Subir Campanhas em Massa
          </h1>
          <p className="mt-1 text-sm text-zinc-400 max-w-2xl">
            Crie campanhas Meta Ads e TikTok Ads em todas as suas contas de
            anúncio de uma vez. Defina uma vez, publique em N contas
            simultaneamente. Inclui <strong>20 uploads grátis</strong> a cada
            renovação.
          </p>
        </header>

        <MassaSubscriptionClient
          balanceCents={user?.balanceCents ?? 0}
          priceCents={MASS_CAMPAIGN_MONTHLY_CENTS}
          hasSubscription={false}
          subscriptionUntil={
            user?.massCampaignSubscriptionUntil?.toISOString() ?? null
          }
          uploadsCount={user?.massCampaignUploadsCount ?? 0}
          freeUploadsLeft={user?.massCampaignFreeUploadsLeft ?? 0}
          pendingPix={
            pendingPix
              ? {
                  id: pendingPix.id,
                  pixCopyPaste: pendingPix.pixCopyPaste ?? "",
                  pixQrCodeBase64: pendingPix.pixQrCodeBase64 ?? null,
                  expiresAt: pendingPix.pixExpiresAt?.toISOString() ?? null,
                }
              : null
          }
        />

        {/* Cards informativos — só pré-venda */}
        <div>
          <p className="text-[10px] uppercase tracking-[0.2em] text-zinc-500 mb-3">
            O que você vai poder fazer
          </p>
          <div className="grid gap-3 md:grid-cols-2">
            <FeatureCard
              Icon={Layers}
              title="N contas, 1 clique"
              description="Publique a mesma campanha em todas as suas contas Meta Ads + TikTok Ads ao mesmo tempo. Sem precisar refazer setup em cada uma."
            />
            <FeatureCard
              Icon={Target}
              title="Segmentação personalizada"
              description="Por conta, ajuste públicos, lookalikes e geo automaticamente — ou herde do template default."
            />
            <FeatureCard
              Icon={Zap}
              title="Criativos sincronizados"
              description="Upload de criativos único; o sistema distribui pra todas as contas, respeitando os limites de cada plataforma."
            />
            <FeatureCard
              Icon={CheckCircle2}
              title="Acompanhamento centralizado"
              description="Dashboard único pra ver performance de TODAS as campanhas espelhadas — ROAS, CPA, CTR consolidados."
            />
          </div>
        </div>
      </div>
    );
  }

  // SUBSCRIBED MODE: somente uploader + status compacto da subscription
  const subUntil = user?.massCampaignSubscriptionUntil;
  return (
    <div className="mx-auto max-w-6xl space-y-5">
      {/* Status compacto da subscription (1 linha) */}
      <div className="flex flex-wrap items-center gap-3 rounded-xl border border-lime-400/20 bg-lime-400/[0.04] px-4 py-2.5 text-xs">
        <span className="inline-flex items-center gap-1.5 text-lime-300 font-semibold">
          <CheckCircle2 className="size-3.5" />
          Plano ativo
        </span>
        <span className="text-zinc-400">
          até{" "}
          <strong className="text-zinc-200">
            {subUntil ? new Date(subUntil).toLocaleDateString("pt-BR") : "—"}
          </strong>
        </span>
        <span className="text-zinc-500">·</span>
        <span className="text-zinc-400">
          <strong className="text-white">
            {user?.massCampaignFreeUploadsLeft ?? 0}
          </strong>{" "}
          upload(s) grátis restantes
        </span>
        <span className="text-zinc-500">·</span>
        <span className="text-zinc-400">
          <strong className="text-white">
            {user?.massCampaignUploadsCount ?? 0}
          </strong>{" "}
          uploads no histórico
        </span>
      </div>

      <MassUploaderClient
        adAccounts={adAccounts.map((a) => ({
          id: a.id,
          platform: a.platform as "meta" | "tiktok",
          accountId: a.accountId,
          accountName: a.accountName,
          profileName: a.profileName ?? "(sem nome)",
          pixels: Array.isArray(a.pixels)
            ? (a.pixels as Array<{ id: string; name: string }>)
            : [],
        }))}
        templates={templates.map((t) => ({
          id: t.id,
          name: t.name,
          platform: t.platform as "meta" | "tiktok",
          config: t.config as Record<string, unknown>,
          updatedAt: t.updatedAt.toISOString(),
        }))}
        recentJobs={recentJobs.map((j) => ({
          id: j.id,
          platform: j.platform as "meta" | "tiktok",
          status: j.status,
          targetAdAccountIds: j.targetAdAccountIds,
          campaignsPerAccount: j.campaignsPerAccount,
          successCount: j.successCount,
          failureCount: j.failureCount,
          createdAt: j.createdAt.toISOString(),
          completedAt: j.completedAt?.toISOString() ?? null,
        }))}
      />
    </div>
  );
}

function FeatureCard({
  Icon,
  title,
  description,
}: {
  Icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
}) {
  return (
    <div className="rounded-2xl border border-white/[0.06] bg-white/[0.02] p-4 flex items-start gap-3 hover:border-white/[0.12] transition">
      <span className="inline-flex size-10 shrink-0 items-center justify-center rounded-xl bg-yellow-400/10 text-yellow-300">
        <Icon className="size-5" />
      </span>
      <div>
        <p className="text-sm font-semibold text-white">{title}</p>
        <p className="mt-1 text-xs text-zinc-400 leading-relaxed">
          {description}
        </p>
      </div>
    </div>
  );
}
