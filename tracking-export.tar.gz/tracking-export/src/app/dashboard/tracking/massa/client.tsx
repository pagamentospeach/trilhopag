"use client";

import { useState, useTransition, useEffect } from "react";
import { useRouter } from "next/navigation";
import {
  Wallet,
  Zap,
  CheckCircle2,
  Loader2,
  Copy,
  Check,
  Clock,
} from "lucide-react";
import {
  subscribeMassCampaignBalanceAction,
  createMassCampaignPixAction,
} from "./actions";

type PendingPix = {
  id: string;
  pixCopyPaste: string;
  pixQrCodeBase64: string | null;
  expiresAt: string | null;
};

export function MassaSubscriptionClient({
  balanceCents,
  priceCents,
  hasSubscription,
  subscriptionUntil,
  uploadsCount,
  freeUploadsLeft = 0,
  pendingPix,
}: {
  balanceCents: number;
  priceCents: number;
  hasSubscription: boolean;
  subscriptionUntil: string | null;
  uploadsCount: number;
  freeUploadsLeft?: number;
  pendingPix: PendingPix | null;
}) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [err, setErr] = useState<string | null>(null);
  const [activePix, setActivePix] = useState<PendingPix | null>(pendingPix);
  const [mode, setMode] = useState<"choose" | "balance" | "pix">("choose");
  const canPayBalance = balanceCents >= priceCents;

  // Poll pra detectar quando o PIX é pago (a cada 8s).
  // PERF: so polla quando a aba esta VISIVEL (document.hidden=false).
  // Antes pollava aba em background a vida toda — consumia CPU + rede
  // a toa em PCs com varias abas abertas.
  useEffect(() => {
    if (!activePix) return;
    let timer: number | null = null;
    const start = () => {
      if (timer !== null) return;
      timer = window.setInterval(() => {
        if (!document.hidden) router.refresh();
      }, 8000);
    };
    const stop = () => {
      if (timer !== null) {
        window.clearInterval(timer);
        timer = null;
      }
    };
    const onVisibility = () => {
      if (document.hidden) stop();
      else start();
    };
    if (!document.hidden) start();
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      stop();
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [activePix, router]);

  function payBalance() {
    setErr(null);
    startTransition(async () => {
      const r = await subscribeMassCampaignBalanceAction();
      if (r.ok) {
        router.refresh();
      } else {
        setErr(r.error ?? "Erro");
      }
    });
  }

  function generatePix() {
    setErr(null);
    startTransition(async () => {
      const r = await createMassCampaignPixAction();
      if (r.ok) {
        setActivePix({
          id: r.purchaseId,
          pixCopyPaste: r.pixCopyPaste,
          pixQrCodeBase64: r.pixQrCodeBase64 ?? null,
          expiresAt: r.expiresAt,
        });
        setMode("pix");
      } else {
        setErr(r.error ?? "Erro");
      }
    });
  }

  // Subscription ativa
  if (hasSubscription) {
    const expiresAt = subscriptionUntil ? new Date(subscriptionUntil) : null;
    const daysLeft = expiresAt
      ? Math.max(
          0,
          Math.ceil((expiresAt.getTime() - Date.now()) / (1000 * 60 * 60 * 24)),
        )
      : 0;
    return (
      <section className="rounded-2xl border border-lime-400/30 bg-gradient-to-br from-lime-400/[0.08] via-lime-400/[0.04] to-transparent p-6 relative overflow-hidden">
        <div className="absolute -top-12 -right-12 size-40 rounded-full bg-lime-400/20 blur-3xl pointer-events-none" />
        <div className="relative space-y-3">
          <div className="flex items-start gap-3">
            <span className="inline-flex size-12 shrink-0 items-center justify-center rounded-2xl bg-lime-400/20 text-lime-300">
              <CheckCircle2 className="size-6" />
            </span>
            <div>
              <p className="text-[10px] uppercase tracking-[0.2em] text-lime-300 font-semibold">
                ATIVO
              </p>
              <p className="mt-0.5 text-lg font-bold text-white">
                Você tem assinatura de Subir Campanhas em Massa
              </p>
              <p className="mt-1 text-sm text-zinc-300">
                {daysLeft > 0 ? (
                  <>
                    Acesso válido até{" "}
                    <strong className="text-lime-300">
                      {expiresAt?.toLocaleDateString("pt-BR")}
                    </strong>{" "}
                    ({daysLeft} dia{daysLeft !== 1 ? "s" : ""})
                  </>
                ) : (
                  "Subscription expirada — renove abaixo"
                )}
              </p>
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 rounded-xl bg-black/30 p-3 mt-3">
            <Stat label="Uploads grátis" value={String(freeUploadsLeft)} />
            <Stat label="Uploads totais" value={String(uploadsCount)} />
            <Stat label="Mensalidade" value="R$ 697,00" />
            <Stat label="Por upload extra" value="R$ 1,00" />
          </div>
          <p className="text-[11px] text-zinc-400 mt-2">
            ⚠️ A integração técnica ainda está em desenvolvimento.
            Funcionalidade vai aparecer aqui em breve.
          </p>
          {/* Renovar antecipadamente */}
          <div className="mt-2 pt-3 border-t border-white/[0.06] flex flex-col sm:flex-row items-center justify-between gap-2">
            <p className="text-[11px] text-zinc-400">
              Renovar antecipadamente · estende +30 dias
            </p>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={payBalance}
                disabled={pending || !canPayBalance}
                className="rounded-full bg-lime-400 px-3 py-1.5 text-[11px] font-bold text-black hover:bg-lime-300 disabled:opacity-50"
              >
                {pending ? (
                  <Loader2 className="size-3 animate-spin" />
                ) : (
                  "+ 30 dias (saldo)"
                )}
              </button>
              <button
                type="button"
                onClick={generatePix}
                disabled={pending}
                className="rounded-full border border-lime-400/40 bg-lime-400/10 px-3 py-1.5 text-[11px] font-bold text-lime-300 hover:bg-lime-400/20 disabled:opacity-50"
              >
                + 30 dias (PIX)
              </button>
            </div>
          </div>
        </div>
      </section>
    );
  }

  // PIX gerado, aguardando pagamento
  if (activePix && mode !== "choose") {
    return (
      <section className="rounded-2xl border border-blue-400/30 bg-gradient-to-br from-blue-400/[0.06] to-transparent p-6 space-y-4">
        <div className="flex items-start gap-3">
          <span className="inline-flex size-12 shrink-0 items-center justify-center rounded-2xl bg-blue-400/15 text-blue-300">
            <Clock className="size-6 animate-pulse" />
          </span>
          <div>
            <p className="text-[10px] uppercase tracking-[0.2em] text-blue-300 font-semibold">
              Aguardando pagamento
            </p>
            <p className="mt-0.5 text-lg font-bold text-white">
              Pague R$ 697,00 via PIX pra ativar
            </p>
            <p className="mt-1 text-xs text-zinc-400">
              Esta página atualiza automaticamente quando o pagamento for
              confirmado.
            </p>
          </div>
        </div>

        {activePix.pixQrCodeBase64 && (
          <div className="rounded-xl border border-white/[0.06] bg-white p-4 flex items-center justify-center">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={`data:image/png;base64,${activePix.pixQrCodeBase64}`}
              alt="QR Code PIX"
              className="size-56 object-contain"
            />
          </div>
        )}

        <CopyPixCode code={activePix.pixCopyPaste} />

        <button
          type="button"
          onClick={() => setMode("choose")}
          className="text-xs text-zinc-400 hover:text-white underline"
        >
          Voltar
        </button>
      </section>
    );
  }

  // Choose payment method
  return (
    <section className="rounded-2xl border border-yellow-400/30 bg-gradient-to-br from-yellow-400/[0.06] via-yellow-400/[0.02] to-transparent p-6 space-y-4">
      <div className="flex items-start gap-3">
        <span className="inline-flex size-12 shrink-0 items-center justify-center rounded-2xl bg-yellow-400/15 text-yellow-300">
          <Zap className="size-6" />
        </span>
        <div>
          <p className="text-[10px] uppercase tracking-[0.2em] text-yellow-300 font-semibold">
            Plano mensal · R$ 697,00/mês
          </p>
          <p className="mt-0.5 text-lg font-bold text-white">
            Ative pra subir campanhas em massa
          </p>
          <p className="mt-1 text-xs text-zinc-400">
            Acesso por 30 dias. Renovação manual (não cobra automaticamente
            no fim do período).
          </p>
        </div>
      </div>

      {err && (
        <p className="rounded-lg bg-red-500/10 px-3 py-2 text-xs text-red-300">
          {err}
        </p>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {/* Saldo */}
        <button
          type="button"
          onClick={payBalance}
          disabled={pending || !canPayBalance}
          className="text-left rounded-xl border-2 border-white/[0.08] bg-black/30 p-4 hover:border-lime-400/40 transition disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <div className="flex items-center gap-2 mb-2">
            <Wallet className="size-5 text-lime-300" />
            <p className="text-sm font-bold text-white">Pagar com saldo</p>
          </div>
          <p className="text-[11px] text-zinc-400 mb-3">
            Débito imediato. Acesso liberado na hora.
          </p>
          <div className="flex items-baseline justify-between">
            <p className="text-xs text-zinc-500">Saldo disponível</p>
            <p
              className={`text-lg font-bold tabular-nums ${
                canPayBalance ? "text-lime-300" : "text-red-300"
              }`}
            >
              R${" "}
              {(balanceCents / 100).toLocaleString("pt-BR", {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2,
              })}
            </p>
          </div>
          {!canPayBalance && (
            <p className="mt-2 text-[10px] text-red-300">
              Faltam R${" "}
              {((priceCents - balanceCents) / 100).toFixed(2).replace(".", ",")}{" "}
              · use PIX
            </p>
          )}
          {pending && mode === "balance" && (
            <Loader2 className="mx-auto mt-3 size-4 animate-spin text-lime-300" />
          )}
        </button>

        {/* PIX */}
        <button
          type="button"
          onClick={generatePix}
          disabled={pending}
          className="text-left rounded-xl border-2 border-white/[0.08] bg-black/30 p-4 hover:border-blue-400/40 transition disabled:opacity-50"
        >
          <div className="flex items-center gap-2 mb-2">
            <Zap className="size-5 text-blue-300" />
            <p className="text-sm font-bold text-white">
              Pagar com PIX
            </p>
          </div>
          <p className="text-[11px] text-zinc-400 mb-3">
            QR Code gerado na hora. Acesso liberado em segundos após o
            pagamento.
          </p>
          <div className="flex items-baseline justify-between">
            <p className="text-xs text-zinc-500">Total</p>
            <p className="text-lg font-bold text-blue-300 tabular-nums">
              R$ 697,00
            </p>
          </div>
          {pending && mode === "pix" && (
            <Loader2 className="mx-auto mt-3 size-4 animate-spin text-blue-300" />
          )}
        </button>
      </div>
    </section>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-[9px] uppercase tracking-wider text-zinc-500">
        {label}
      </p>
      <p className="mt-0.5 text-sm font-bold text-white tabular-nums">
        {value}
      </p>
    </div>
  );
}

function CopyPixCode({ code }: { code: string }) {
  const [copied, setCopied] = useState(false);
  async function copy() {
    await navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }
  return (
    <div className="rounded-xl border border-white/[0.08] bg-black/30 p-3">
      <p className="text-[10px] uppercase tracking-wider text-zinc-500 mb-1">
        PIX copia e cola
      </p>
      <div className="flex items-center gap-2">
        <code className="flex-1 text-[11px] font-mono text-zinc-300 truncate">
          {code}
        </code>
        <button
          type="button"
          onClick={copy}
          className="inline-flex items-center gap-1 rounded-full bg-lime-400 px-3 py-1.5 text-xs font-bold text-black hover:bg-lime-300 shrink-0"
        >
          {copied ? (
            <Check className="size-3" />
          ) : (
            <Copy className="size-3" />
          )}
          {copied ? "Copiado" : "Copiar"}
        </button>
      </div>
    </div>
  );
}
