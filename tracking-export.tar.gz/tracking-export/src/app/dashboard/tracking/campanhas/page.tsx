import Link from "next/link";
import { Plug } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { requireUserId } from "@/lib/auth-helpers";
import { normUtm, resolveUtmToExternalId } from "@/lib/utm-match";
import { CampaignsClient } from "./client";

function periodToRange(period: string): { since: Date } {
  const now = new Date();
  const start = new Date(now);
  start.setHours(0, 0, 0, 0);
  switch (period) {
    case "today":
      return { since: start };
    case "yesterday": {
      const y = new Date(start);
      y.setDate(y.getDate() - 1);
      return { since: y };
    }
    case "7d":
      return { since: new Date(now.getTime() - 7 * 86400000) };
    case "month":
      return { since: new Date(now.getFullYear(), now.getMonth(), 1) };
    case "30d":
    default:
      return { since: new Date(now.getTime() - 30 * 86400000) };
  }
}

export default async function CampanhasPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const userId = await requireUserId();
  const sp = await searchParams;
  const period = sp.period ?? "today";
  const range = periodToRange(period);

  const adAccounts = await prisma.adAccount.findMany({
    where: {
      userId,
      platform: { in: ["meta", "tiktok"] }, // antes era só meta — tiktok também sincroniza campanhas via ad-sync.ts
      status: "active",
      enabled: true,
    },
    include: {
      campaigns: {
        orderBy: { name: "asc" },
        include: {
          adsets: {
            orderBy: { name: "asc" },
            include: { ads: { orderBy: { name: "asc" } } },
          },
        },
      },
    },
  });

  // Fetch transactions in period to merge with campaigns
  const transactions = await prisma.transaction.findMany({
    where: {
      userId,
      provider: { not: "test" },
      status: "PAID",
      paidAt: { gte: range.since },
      utmCampaign: { not: null },
    },
    select: {
      amountCents: true,
      utmCampaign: true,
      utmMedium: true,
      utmContent: true,
    },
  });

  // Sales por externalId de campanha/conjunto/anúncio.
  const salesByCampaignId = new Map<
    string,
    { count: number; amountCents: number }
  >();
  const salesByAdsetId = new Map<
    string,
    { count: number; amountCents: number }
  >();
  const salesByAdId = new Map<
    string,
    { count: number; amountCents: number }
  >();

  // Índices id + nome (pra casar UTM em qualquer formato: "nome|id", nome puro
  // do TikTok, ou só o id). Antes só casava "nome|id" → venda de TikTok (nome
  // puro) não aparecia em campanha nenhuma.
  const campExtIds = new Set<string>();
  const campByName = new Map<string, string>();
  const adsetExtIds = new Set<string>();
  const adsetByName = new Map<string, string>();
  const adExtIds = new Set<string>();
  const adByName = new Map<string, string>();
  for (const acc of adAccounts) {
    for (const c of acc.campaigns) {
      campExtIds.add(c.externalId);
      const ck = normUtm(c.name);
      if (ck && !campByName.has(ck)) campByName.set(ck, c.externalId);
      for (const s of c.adsets) {
        adsetExtIds.add(s.externalId);
        const sk = normUtm(s.name);
        if (sk && !adsetByName.has(sk)) adsetByName.set(sk, s.externalId);
        for (const a of s.ads) {
          adExtIds.add(a.externalId);
          const ak = normUtm(a.name);
          if (ak && !adByName.has(ak)) adByName.set(ak, a.externalId);
        }
      }
    }
  }

  function inc(
    map: Map<string, { count: number; amountCents: number }>,
    key: string,
    amount: number,
  ) {
    const cur = map.get(key) ?? { count: 0, amountCents: 0 };
    cur.count++;
    cur.amountCents += amount;
    map.set(key, cur);
  }

  for (const t of transactions) {
    const campId = resolveUtmToExternalId(t.utmCampaign, campExtIds, campByName);
    const adsetId = resolveUtmToExternalId(t.utmMedium, adsetExtIds, adsetByName);
    const adId = resolveUtmToExternalId(t.utmContent, adExtIds, adByName);
    if (campId) inc(salesByCampaignId, campId, t.amountCents);
    if (adsetId) inc(salesByAdsetId, adsetId, t.amountCents);
    if (adId) inc(salesByAdId, adId, t.amountCents);
  }

  const products = await prisma.product.findMany({
    where: { userId },
    select: { id: true, name: true },
    orderBy: { name: "asc" },
  });

  if (adAccounts.length === 0) {
    return (
      <div className="rounded-2xl border border-white/[0.08] bg-white/[0.02] p-12 text-center">
        <Plug className="mx-auto size-10 text-zinc-600" />
        <p className="mt-4 text-base font-semibold text-white">
          Conecte uma conta de anúncio
        </p>
        <p className="mt-2 text-sm text-zinc-400">
          Vá em <strong>Integrações</strong> e conecte Meta Ads ou TikTok Ads
          pra ver campanhas aqui.
        </p>
        <Link
          href="/dashboard/tracking"
          className="mt-4 inline-flex items-center gap-1.5 rounded-full bg-lime-400 px-4 py-2 text-xs font-semibold text-black hover:bg-lime-300"
        >
          Ir pra Integrações
        </Link>
      </div>
    );
  }

  const data = adAccounts.flatMap((acc) =>
    acc.campaigns.map((c) => {
      const sales = salesByCampaignId.get(c.externalId) ?? {
        count: 0,
        amountCents: 0,
      };
      return {
        adAccountId: acc.id,
        accountName: acc.accountName,
        currency: acc.currency ?? "BRL",
        campaign: {
          id: c.id,
          externalId: c.externalId,
          name: c.name,
          status: c.status,
          dailyBudgetCents: c.dailyBudgetCents,
          spendCentsDay: c.spendCentsDay,
          impressions: c.impressions,
          clicks: c.clicks,
          ctrPercent: c.ctrPercent,
          cpcCents: c.cpcCents,
          cpmCents: c.cpmCents,
          favorite: c.favorite,
          updatedAt: c.externalUpdatedAt?.toISOString() ?? null,
          salesCount: sales.count,
          salesCents: sales.amountCents,
          adsets: c.adsets.map((s) => {
            const sSales = salesByAdsetId.get(s.externalId) ?? {
              count: 0,
              amountCents: 0,
            };
            return {
              id: s.id,
              externalId: s.externalId,
              name: s.name,
              status: s.status,
              dailyBudgetCents: s.dailyBudgetCents,
              spendCentsDay: s.spendCentsDay,
              impressions: s.impressions,
              clicks: s.clicks,
              salesCount: sSales.count,
              salesCents: sSales.amountCents,
              ads: s.ads.map((a) => {
                const aSales = salesByAdId.get(a.externalId) ?? {
                  count: 0,
                  amountCents: 0,
                };
                return {
                  id: a.id,
                  externalId: a.externalId,
                  name: a.name,
                  status: a.status,
                  spendCentsDay: a.spendCentsDay,
                  impressions: a.impressions,
                  clicks: a.clicks,
                  salesCount: aSales.count,
                  salesCents: aSales.amountCents,
                };
              }),
            };
          }),
        },
      };
    }),
  );

  return (
    <CampaignsClient
      data={data}
      adAccounts={adAccounts.map((a) => ({
        id: a.id,
        accountId: a.accountId,
        accountName: a.accountName,
      }))}
      products={products}
      currentPeriod={period}
    />
  );
}
