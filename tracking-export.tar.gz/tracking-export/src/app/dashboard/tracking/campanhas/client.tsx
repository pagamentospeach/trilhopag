"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import {
  ChevronRight,
  ChevronDown,
  Play,
  Pause,
  RefreshCw,
  Loader2,
  Megaphone,
  Layers,
  Image as ImageIcon,
  Copy,
  DollarSign,
  Pencil,
  Download,
  Star,
  X,
} from "lucide-react";
import { formatBRL } from "@/lib/utils";
import {
  setAdObjectStatus,
  syncAllAccounts,
  duplicateCampaign,
  setCampaignBudget,
  setAdsetBudgetAction,
  renameCampaignAction,
  renameAdsetAction,
  renameAdAction,
  setAccountCurrencyAction,
  toggleCampaignFavorite,
} from "./actions";

type Ad = {
  id: string;
  externalId: string;
  name: string;
  status: string;
  spendCentsDay: number;
  impressions: number;
  clicks: number;
  salesCount: number;
  salesCents: number;
};
type Adset = {
  id: string;
  externalId: string;
  name: string;
  status: string;
  dailyBudgetCents: number | null;
  spendCentsDay: number;
  impressions: number;
  clicks: number;
  salesCount: number;
  salesCents: number;
  ads: Ad[];
};
type Campaign = {
  id: string;
  externalId: string;
  name: string;
  status: string;
  dailyBudgetCents: number | null;
  spendCentsDay: number;
  impressions: number;
  clicks: number;
  ctrPercent: number | null;
  cpcCents: number | null;
  cpmCents: number | null;
  favorite: boolean;
  updatedAt: string | null;
  salesCount: number;
  salesCents: number;
  adsets: Adset[];
};
type Row = {
  adAccountId: string;
  accountName: string;
  currency: string;
  campaign: Campaign;
};

/**
 * Formata um valor (em "cents") na moeda da CONTA de anúncio. Usado só pra
 * gasto/orçamento/CPC/CPM/CPA — métricas na moeda da plataforma. NÃO mexe no
 * formatBRL do resto do gateway (saldo/vendas continuam sempre em BRL).
 */
function formatMoney(cents: number, currency: string): string {
  try {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: currency || "BRL",
    }).format(cents / 100);
  } catch {
    return formatBRL(cents);
  }
}

export function CampaignsClient({
  data,
  adAccounts,
  products,
  currentPeriod,
}: {
  data: Row[];
  adAccounts: Array<{ id: string; accountId: string; accountName: string }>;
  products: Array<{ id: string; name: string }>;
  currentPeriod: string;
}) {
  const router = useRouter();
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [expandedSets, setExpandedSets] = useState<Set<string>>(new Set());
  const [filters, setFilters] = useState({
    nameFilter: "",
    statusFilter: "all" as "all" | "active" | "paused",
    accountId: "all",
    productId: "all",
  });
  const [isPending, startTransition] = useTransition();
  const [syncMsg, setSyncMsg] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const PAGE_SIZE = 20;

  function toggleCampaign(id: string) {
    setExpanded((s) => {
      const next = new Set(s);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }
  function toggleAdset(id: string) {
    setExpandedSets((s) => {
      const next = new Set(s);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function setPeriod(p: string) {
    const params = new URLSearchParams();
    params.set("period", p);
    router.push(`/dashboard/tracking/campanhas?${params.toString()}`);
  }

  function syncAll() {
    setSyncMsg(null);
    startTransition(async () => {
      const r = await syncAllAccounts();
      if (r.ok) {
        const total = r.results.reduce((s, x) => s + (x.campaigns || 0), 0);
        setSyncMsg(`${total} campanhas atualizadas`);
        router.refresh();
        setTimeout(() => setSyncMsg(null), 2500);
      } else {
        setSyncMsg("Erro ao sincronizar.");
      }
    });
  }

  const filtered = data.filter((row) => {
    if (
      filters.nameFilter &&
      !row.campaign.name.toLowerCase().includes(filters.nameFilter.toLowerCase())
    )
      return false;
    if (filters.statusFilter === "active" && row.campaign.status !== "ACTIVE")
      return false;
    if (filters.statusFilter === "paused" && row.campaign.status === "ACTIVE")
      return false;
    if (filters.accountId !== "all" && row.adAccountId !== filters.accountId)
      return false;
    return true;
  });

  /** 🧾 Exporta as campanhas filtradas pra CSV (pt-BR: ';' + vírgula decimal). */
  function exportCsv() {
    const dec = (cents: number | null | undefined) =>
      cents == null ? "" : (cents / 100).toFixed(2).replace(".", ",");
    const headers = [
      "Campanha",
      "Conta",
      "Moeda",
      "Status",
      "Orçamento",
      "Vendas",
      "Faturamento (R$)",
      "Gasto",
      "ROAS",
      "CPA",
      "CTR %",
      "CPC",
      "CPM",
      "Cliques",
      "Impressões",
    ];
    const rows = filtered.map((r) => {
      const c = r.campaign;
      const roas =
        c.spendCentsDay > 0
          ? (c.salesCents / c.spendCentsDay).toFixed(2).replace(".", ",")
          : "";
      const cpa =
        c.salesCount > 0 ? dec(Math.round(c.spendCentsDay / c.salesCount)) : "";
      return [
        c.name,
        r.accountName,
        r.currency,
        c.status,
        dec(c.dailyBudgetCents),
        String(c.salesCount),
        dec(c.salesCents),
        dec(c.spendCentsDay),
        roas,
        cpa,
        c.ctrPercent != null ? c.ctrPercent.toFixed(2).replace(".", ",") : "",
        dec(c.cpcCents),
        dec(c.cpmCents),
        String(c.clicks),
        String(c.impressions),
      ];
    });
    const esc = (v: string) =>
      /[";\r\n]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v;
    const csv = [headers, ...rows]
      .map((row) => row.map((cell) => esc(String(cell ?? ""))).join(";"))
      .join("\r\n");
    const blob = new Blob(["﻿" + csv], {
      type: "text/csv;charset=utf-8;",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `campanhas-${currentPeriod}-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const pageRows = filtered.slice(
    (currentPage - 1) * PAGE_SIZE,
    currentPage * PAGE_SIZE,
  );

  return (
    <div className="space-y-4">
      {/* Filtros */}
      <div className="rounded-xl border border-white/[0.08] bg-white/[0.02] p-4 grid grid-cols-2 gap-3 sm:grid-cols-5">
        <div>
          <label className="block text-[10px] text-zinc-500 mb-1">Nome</label>
          <input
            value={filters.nameFilter}
            onChange={(e) =>
              setFilters({ ...filters, nameFilter: e.target.value })
            }
            placeholder="Filtrar por nome"
            className="w-full rounded-lg border border-white/[0.08] bg-white/[0.02] px-3 py-2 text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-lime-400/40"
          />
        </div>
        <div>
          <label className="block text-[10px] text-zinc-500 mb-1">Status</label>
          <select
            value={filters.statusFilter}
            onChange={(e) =>
              setFilters({
                ...filters,
                statusFilter: e.target.value as "all" | "active" | "paused",
              })
            }
            className="w-full rounded-lg border border-white/[0.08] bg-white/[0.02] px-3 py-2 text-sm text-white focus:outline-none"
          >
            <option value="all">Qualquer</option>
            <option value="active">Ativas</option>
            <option value="paused">Pausadas</option>
          </select>
        </div>
        <div>
          <label className="block text-[10px] text-zinc-500 mb-1">Período</label>
          <select
            value={currentPeriod}
            onChange={(e) => setPeriod(e.target.value)}
            className="w-full rounded-lg border border-white/[0.08] bg-white/[0.02] px-3 py-2 text-sm text-white focus:outline-none"
          >
            <option value="today">Hoje</option>
            <option value="yesterday">Ontem</option>
            <option value="7d">7 dias</option>
            <option value="30d">30 dias</option>
            <option value="month">Este mês</option>
          </select>
        </div>
        <div>
          <label className="block text-[10px] text-zinc-500 mb-1">
            Conta de Anúncio
          </label>
          <select
            value={filters.accountId}
            onChange={(e) =>
              setFilters({ ...filters, accountId: e.target.value })
            }
            className="w-full rounded-lg border border-white/[0.08] bg-white/[0.02] px-3 py-2 text-sm text-white focus:outline-none"
          >
            <option value="all">Qualquer</option>
            {adAccounts.map((a) => (
              <option key={a.id} value={a.id}>
                {a.accountName}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-[10px] text-zinc-500 mb-1">Produto</label>
          <select
            value={filters.productId}
            onChange={(e) =>
              setFilters({ ...filters, productId: e.target.value })
            }
            className="w-full rounded-lg border border-white/[0.08] bg-white/[0.02] px-3 py-2 text-sm text-white focus:outline-none"
          >
            <option value="all">Qualquer</option>
            {products.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Sync button */}
      <div className="flex items-center justify-between">
        <p className="text-xs text-zinc-500">
          {filtered.length} campanha{filtered.length !== 1 ? "s" : ""}
          {syncMsg && (
            <span className="ml-2 text-lime-300">· {syncMsg}</span>
          )}
        </p>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={exportCsv}
            disabled={filtered.length === 0}
            title="Baixar CSV das campanhas filtradas"
            className="inline-flex items-center gap-1.5 rounded-full bg-white/[0.04] px-3 py-1.5 text-xs font-medium text-zinc-300 hover:bg-white/[0.08] transition disabled:opacity-50"
          >
            <Download className="size-3" />
            Exportar CSV
          </button>
          <button
            type="button"
            onClick={syncAll}
            disabled={isPending}
            className="inline-flex items-center gap-1.5 rounded-full bg-blue-500/15 px-3 py-1.5 text-xs font-medium text-blue-300 hover:bg-blue-500/25 transition disabled:opacity-50"
          >
            {isPending ? (
              <Loader2 className="size-3 animate-spin" />
            ) : (
              <RefreshCw className="size-3" />
            )}
            {isPending ? "Sincronizando..." : "Atualizar agora"}
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="rounded-2xl border border-white/[0.08] bg-white/[0.02] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="border-b border-white/[0.06] bg-black/30 text-[10px] uppercase tracking-wider text-zinc-500">
              <tr>
                <th className="px-3 py-3 text-left w-8"></th>
                <th className="px-3 py-3 text-left">Campanha</th>
                <th className="px-3 py-3 text-center">Status</th>
                <th className="px-3 py-3 text-right">Orçamento</th>
                <th className="px-3 py-3 text-right">Vendas</th>
                <th className="px-3 py-3 text-right">Faturamento</th>
                <th className="px-3 py-3 text-right">Gasto</th>
                <th className="px-3 py-3 text-right">ROAS</th>
                <th className="px-3 py-3 text-right">CPA</th>
                <th className="px-3 py-3 text-right">Lucro</th>
                <th className="px-3 py-3 text-right">Cliques</th>
                <th className="px-3 py-3 text-right">CTR</th>
                <th className="px-3 py-3 text-right">CPC</th>
                <th className="px-3 py-3 text-right">CPM</th>
                <th className="px-3 py-3 text-right">Impressões</th>
                <th className="px-3 py-3 text-center">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.04]">
              {filtered.length === 0 && (
                <tr>
                  <td
                    colSpan={16}
                    className="px-3 py-12 text-center text-sm text-zinc-500"
                  >
                    Nenhuma campanha encontrada. Clique em{" "}
                    <strong>Atualizar agora</strong> pra sincronizar com Meta.
                  </td>
                </tr>
              )}
              {pageRows.map((row) => (
                <CampaignRow
                  key={row.campaign.id}
                  row={row}
                  expanded={expanded.has(row.campaign.id)}
                  onToggle={() => toggleCampaign(row.campaign.id)}
                  expandedSets={expandedSets}
                  onToggleAdset={toggleAdset}
                  onStatusChange={() => router.refresh()}
                />
              ))}
            </tbody>
          </table>
        </div>
        {totalPages > 1 && (
          <div className="flex items-center justify-between border-t border-white/[0.06] bg-black/20 px-4 py-2.5 text-xs">
            <span className="text-zinc-500">
              Página {currentPage} de {totalPages} ·{" "}
              {filtered.length} resultados
            </span>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={currentPage <= 1}
                className="rounded-md border border-white/[0.08] bg-white/[0.02] px-2.5 py-1 text-zinc-300 hover:bg-white/[0.05] disabled:opacity-40 disabled:hover:bg-white/[0.02]"
              >
                Anterior
              </button>
              <button
                type="button"
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage >= totalPages}
                className="rounded-md border border-white/[0.08] bg-white/[0.02] px-2.5 py-1 text-zinc-300 hover:bg-white/[0.05] disabled:opacity-40 disabled:hover:bg-white/[0.02]"
              >
                Próxima
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function CampaignRow({
  row,
  expanded,
  onToggle,
  expandedSets,
  onToggleAdset,
  onStatusChange,
}: {
  row: Row;
  expanded: boolean;
  onToggle: () => void;
  expandedSets: Set<string>;
  onToggleAdset: (id: string) => void;
  onStatusChange: () => void;
}) {
  const c = row.campaign;
  const isActive = c.status === "ACTIVE";
  // Receita (vendas) é sempre BRL. Gasto está na moeda da conta. Quando a
  // conta NÃO é BRL, ROAS/lucro misturariam moedas → mostramos "—".
  const isBRL = (row.currency || "BRL") === "BRL";
  const roas =
    isBRL && c.spendCentsDay > 0
      ? (c.salesCents / c.spendCentsDay).toFixed(2)
      : "—";
  const cpa =
    c.salesCount > 0
      ? formatMoney(Math.round(c.spendCentsDay / c.salesCount), row.currency)
      : "—";
  const profit = c.salesCents - c.spendCentsDay;

  return (
    <>
      <tr className="hover:bg-white/[0.02]">
        <td className="px-3 py-3">
          {(c.adsets.length > 0 || c.salesCount > 0) && (
            <button type="button" onClick={onToggle} className="text-zinc-500 hover:text-white">
              {expanded ? (
                <ChevronDown className="size-3.5" />
              ) : (
                <ChevronRight className="size-3.5" />
              )}
            </button>
          )}
        </td>
        <td className="px-3 py-3 max-w-xs">
          <div className="flex items-center gap-2">
            <Megaphone className="size-3.5 shrink-0 text-zinc-500" />
            <div className="min-w-0">
              <div className="flex items-center gap-1">
                <FavoriteButton
                  adAccountId={row.adAccountId}
                  externalId={c.externalId}
                  favorite={c.favorite}
                  onDone={onStatusChange}
                />
                <p className="font-medium text-white truncate">{c.name}</p>
                <RenameButton
                  adAccountId={row.adAccountId}
                  externalId={c.externalId}
                  currentName={c.name}
                  kind="campaign"
                  onDone={onStatusChange}
                />
              </div>
              <p className="text-[10px] text-zinc-500 font-mono">
                {c.externalId} ·{" "}
                <CurrencyEditor
                  adAccountId={row.adAccountId}
                  currency={row.currency}
                  onDone={onStatusChange}
                />
              </p>
            </div>
          </div>
        </td>
        <td className="px-3 py-3 text-center">
          <StatusToggle
            adAccountId={row.adAccountId}
            kind="campaign"
            externalId={c.externalId}
            active={isActive}
            onChange={onStatusChange}
          />
        </td>
        <td className="px-3 py-3 text-right text-zinc-300 font-mono text-xs">
          {c.dailyBudgetCents
            ? formatMoney(c.dailyBudgetCents, row.currency)
            : "—"}
        </td>
        <td className="px-3 py-3 text-right text-zinc-200 tabular-nums">
          {c.salesCount}
        </td>
        <td className="px-3 py-3 text-right text-zinc-200 tabular-nums font-mono text-xs">
          {formatBRL(c.salesCents)}
        </td>
        <td className="px-3 py-3 text-right text-zinc-200 tabular-nums font-mono text-xs">
          {formatMoney(c.spendCentsDay, row.currency)}
        </td>
        <td
          className={`px-3 py-3 text-right tabular-nums font-mono text-xs ${
            roas !== "—" && Number(roas) >= 2
              ? "text-lime-300"
              : roas !== "—" && Number(roas) >= 1
                ? "text-yellow-300"
                : "text-zinc-300"
          }`}
        >
          {roas}
        </td>
        <td className="px-3 py-3 text-right text-zinc-200 tabular-nums font-mono text-xs">
          {cpa}
        </td>
        <td
          className={`px-3 py-3 text-right tabular-nums font-mono text-xs ${isBRL && profit > 0 ? "text-lime-300" : isBRL && profit < 0 ? "text-red-300" : "text-zinc-300"}`}
        >
          {isBRL ? formatBRL(profit) : "—"}
        </td>
        <td className="px-3 py-3 text-right text-zinc-400 tabular-nums text-xs">
          {c.clicks}
        </td>
        <td className="px-3 py-3 text-right text-zinc-400 tabular-nums text-xs">
          {c.ctrPercent ? `${c.ctrPercent.toFixed(2)}%` : "—"}
        </td>
        <td className="px-3 py-3 text-right text-zinc-400 tabular-nums font-mono text-xs">
          {c.cpcCents ? formatMoney(c.cpcCents, row.currency) : "—"}
        </td>
        <td className="px-3 py-3 text-right text-zinc-400 tabular-nums font-mono text-xs">
          {c.cpmCents ? formatMoney(c.cpmCents, row.currency) : "—"}
        </td>
        <td className="px-3 py-3 text-right text-zinc-400 tabular-nums text-xs">
          {c.impressions}
        </td>
        <td className="px-3 py-3 text-center">
          <CampaignActions
            adAccountId={row.adAccountId}
            campaignExternalId={c.externalId}
            campaignName={c.name}
            currentBudgetCents={c.dailyBudgetCents}
            onChange={onStatusChange}
          />
        </td>
      </tr>

      {expanded &&
        c.adsets.map((s) => (
          <AdsetRow
            key={s.id}
            adAccountId={row.adAccountId}
            currency={row.currency}
            adset={s}
            expanded={expandedSets.has(s.id)}
            onToggle={() => onToggleAdset(s.id)}
            onStatusChange={onStatusChange}
          />
        ))}
    </>
  );
}

function AdsetRow({
  adAccountId,
  currency,
  adset: s,
  expanded,
  onToggle,
  onStatusChange,
}: {
  adAccountId: string;
  currency: string;
  adset: Adset;
  expanded: boolean;
  onToggle: () => void;
  onStatusChange: () => void;
}) {
  const isActive = s.status === "ACTIVE";
  const isBRL = (currency || "BRL") === "BRL";
  const roas =
    isBRL && s.spendCentsDay > 0
      ? (s.salesCents / s.spendCentsDay).toFixed(2)
      : "—";
  const [showBudget, setShowBudget] = useState(false);

  return (
    <>
      <tr className="bg-white/[0.01] hover:bg-white/[0.03]">
        <td className="px-3 py-2 pl-8">
          {s.ads.length > 0 && (
            <button type="button" onClick={onToggle} className="text-zinc-500 hover:text-white">
              {expanded ? (
                <ChevronDown className="size-3" />
              ) : (
                <ChevronRight className="size-3" />
              )}
            </button>
          )}
        </td>
        <td className="px-3 py-2 max-w-xs pl-2">
          <div className="flex items-center gap-1.5">
            <Layers className="size-3 shrink-0 text-zinc-500" />
            <p className="text-xs text-zinc-300 truncate">{s.name}</p>
            <RenameButton
              adAccountId={adAccountId}
              externalId={s.externalId}
              currentName={s.name}
              kind="adset"
              onDone={onStatusChange}
            />
          </div>
        </td>
        <td className="px-3 py-2 text-center">
          <StatusToggle
            adAccountId={adAccountId}
            kind="adset"
            externalId={s.externalId}
            active={isActive}
            onChange={onStatusChange}
          />
        </td>
        <td className="px-3 py-2 text-right text-xs text-zinc-400 font-mono">
          <div className="inline-flex items-center gap-1">
            <span>
              {s.dailyBudgetCents
                ? formatMoney(s.dailyBudgetCents, currency)
                : "—"}
            </span>
            <button
              type="button"
              onClick={() => setShowBudget(true)}
              title="Ajustar orçamento do conjunto"
              className="rounded p-1 text-zinc-500 hover:bg-white/[0.06] hover:text-white transition"
            >
              <DollarSign className="size-3" />
            </button>
          </div>
          {showBudget && (
            <BudgetModal
              adAccountId={adAccountId}
              campaignExternalId={s.externalId}
              campaignName={s.name}
              currentBudgetCents={s.dailyBudgetCents}
              kind="adset"
              onClose={() => setShowBudget(false)}
              onSaved={() => {
                setShowBudget(false);
                onStatusChange();
              }}
            />
          )}
        </td>
        <td className="px-3 py-2 text-right text-xs text-zinc-400 tabular-nums">
          {s.salesCount}
        </td>
        <td className="px-3 py-2 text-right text-xs text-zinc-400 tabular-nums font-mono">
          {formatBRL(s.salesCents)}
        </td>
        <td className="px-3 py-2 text-right text-xs text-zinc-400 tabular-nums font-mono">
          {formatMoney(s.spendCentsDay, currency)}
        </td>
        <td className="px-3 py-2 text-right text-xs text-zinc-400 tabular-nums font-mono">
          {roas}
        </td>
        <td colSpan={8}></td>
      </tr>

      {expanded &&
        s.ads.map((a) => (
          <AdRow
            key={a.id}
            adAccountId={adAccountId}
            currency={currency}
            ad={a}
            onStatusChange={onStatusChange}
          />
        ))}
    </>
  );
}

function AdRow({
  adAccountId,
  currency,
  ad,
  onStatusChange,
}: {
  adAccountId: string;
  currency: string;
  ad: Ad;
  onStatusChange: () => void;
}) {
  const isActive = ad.status === "ACTIVE";
  const isBRL = (currency || "BRL") === "BRL";
  const roas =
    isBRL && ad.spendCentsDay > 0
      ? (ad.salesCents / ad.spendCentsDay).toFixed(2)
      : "—";

  return (
    <tr className="bg-white/[0.005] hover:bg-white/[0.02] text-[11px]">
      <td className="px-3 py-2 pl-16"></td>
      <td className="px-3 py-2 max-w-xs">
        <div className="flex items-center gap-1.5">
          <ImageIcon className="size-3 shrink-0 text-zinc-600" />
          <p className="text-xs text-zinc-400 truncate">{ad.name}</p>
          <RenameButton
            adAccountId={adAccountId}
            externalId={ad.externalId}
            currentName={ad.name}
            kind="ad"
            onDone={onStatusChange}
          />
        </div>
      </td>
      <td className="px-3 py-2 text-center">
        <StatusToggle
          adAccountId={adAccountId}
          kind="ad"
          externalId={ad.externalId}
          active={isActive}
          onChange={onStatusChange}
        />
      </td>
      <td className="px-3 py-2"></td>
      <td className="px-3 py-2 text-right text-zinc-400 tabular-nums">
        {ad.salesCount}
      </td>
      <td className="px-3 py-2 text-right text-zinc-400 tabular-nums font-mono">
        {formatBRL(ad.salesCents)}
      </td>
      <td className="px-3 py-2 text-right text-zinc-400 tabular-nums font-mono">
        {formatMoney(ad.spendCentsDay, currency)}
      </td>
      <td className="px-3 py-2 text-right text-zinc-400 tabular-nums font-mono">
        {roas}
      </td>
      <td colSpan={8}></td>
    </tr>
  );
}

function StatusToggle({
  adAccountId,
  kind,
  externalId,
  active,
  onChange,
}: {
  adAccountId: string;
  kind: "campaign" | "adset" | "ad";
  externalId: string;
  active: boolean;
  onChange: () => void;
}) {
  const [isPending, startTransition] = useTransition();
  function toggle() {
    startTransition(async () => {
      await setAdObjectStatus(adAccountId, kind, externalId, active ? "PAUSED" : "ACTIVE");
      onChange();
    });
  }
  return (
    <button
      type="button"
      onClick={toggle}
      disabled={isPending}
      className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-medium transition ${
        active
          ? "border-lime-400/30 bg-lime-400/15 text-lime-300 hover:bg-lime-400/25"
          : "border-zinc-600/30 bg-zinc-600/15 text-zinc-400 hover:bg-zinc-600/25"
      } disabled:opacity-50`}
    >
      {isPending ? (
        <Loader2 className="size-2.5 animate-spin" />
      ) : active ? (
        <Play className="size-2.5 fill-current" />
      ) : (
        <Pause className="size-2.5 fill-current" />
      )}
      {active ? "Ativa" : "Pausada"}
    </button>
  );
}

function CampaignActions({
  adAccountId,
  campaignExternalId,
  campaignName,
  currentBudgetCents,
  onChange,
}: {
  adAccountId: string;
  campaignExternalId: string;
  campaignName: string;
  currentBudgetCents: number | null;
  onChange: () => void;
}) {
  const [isDuplicating, startDup] = useTransition();
  const [showBudget, setShowBudget] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  function handleDuplicate() {
    if (!confirm(`Duplicar campanha "${campaignName}"? A cópia será criada PAUSADA.`))
      return;
    setMsg(null);
    startDup(async () => {
      const r = await duplicateCampaign(adAccountId, campaignExternalId);
      if (r.ok) {
        setMsg("Duplicada!");
        onChange();
        setTimeout(() => setMsg(null), 2000);
      } else {
        alert("Erro ao duplicar: " + r.error);
      }
    });
  }

  return (
    <div className="inline-flex items-center gap-1">
      <button
        type="button"
        onClick={() => setShowBudget(true)}
        title="Ajustar orçamento"
        className="rounded-md p-1.5 text-zinc-400 hover:bg-white/[0.06] hover:text-white transition"
      >
        <DollarSign className="size-3.5" />
      </button>
      <button
        type="button"
        onClick={handleDuplicate}
        disabled={isDuplicating}
        title="Duplicar campanha (cópia pausada)"
        className="rounded-md p-1.5 text-zinc-400 hover:bg-white/[0.06] hover:text-white transition disabled:opacity-50"
      >
        {isDuplicating ? (
          <Loader2 className="size-3.5 animate-spin" />
        ) : (
          <Copy className="size-3.5" />
        )}
      </button>
      {msg && <span className="text-[10px] text-lime-300">{msg}</span>}
      {showBudget && (
        <BudgetModal
          adAccountId={adAccountId}
          campaignExternalId={campaignExternalId}
          campaignName={campaignName}
          currentBudgetCents={currentBudgetCents}
          onClose={() => setShowBudget(false)}
          onSaved={() => {
            setShowBudget(false);
            onChange();
          }}
        />
      )}
    </div>
  );
}

/** 📌 Define a moeda da conta manualmente (aplica a todas as campanhas dela). */
function CurrencyEditor({
  adAccountId,
  currency,
  onDone,
}: {
  adAccountId: string;
  currency: string;
  onDone: () => void;
}) {
  const [isPending, startTransition] = useTransition();
  function edit() {
    const next = window.prompt(
      "Moeda da conta (ISO: BRL, USD, CLP…) — aplica a TODAS as campanhas desta conta:",
      currency,
    );
    if (next == null) return;
    const code = next.trim().toUpperCase();
    if (!code) return;
    // Taxa manual opcional (só pra moeda != BRL).
    let rate: number | null = null;
    if (code !== "BRL") {
      const r = window.prompt(
        `Taxa manual ${code}→BRL (deixe vazio = câmbio automático):`,
        "",
      );
      if (r != null && r.trim() !== "") {
        const n = Number(r.replace(",", "."));
        if (Number.isFinite(n) && n > 0) rate = n;
      }
    }
    startTransition(async () => {
      const r = await setAccountCurrencyAction(adAccountId, code, rate);
      if (r.ok) onDone();
      else alert(r.error || "Erro ao definir moeda.");
    });
  }
  return (
    <button
      type="button"
      onClick={edit}
      disabled={isPending}
      title="Definir moeda da conta"
      className="underline decoration-dotted underline-offset-2 hover:text-zinc-300 disabled:opacity-50"
    >
      {isPending ? "…" : currency}
    </button>
  );
}

function FavoriteButton({
  adAccountId,
  externalId,
  favorite,
  onDone,
}: {
  adAccountId: string;
  externalId: string;
  favorite: boolean;
  onDone: () => void;
}) {
  const [isPending, startTransition] = useTransition();
  function toggle() {
    startTransition(async () => {
      const r = await toggleCampaignFavorite(adAccountId, externalId, !favorite);
      if (r.ok) onDone();
      else alert(r.error || "Erro");
    });
  }
  return (
    <button
      type="button"
      onClick={toggle}
      disabled={isPending}
      title={favorite ? "Desfavoritar" : "Favoritar (mostra no dashboard)"}
      className="shrink-0 rounded p-0.5 transition disabled:opacity-50"
    >
      <Star
        className={`size-3.5 ${
          favorite
            ? "fill-amber-400 text-amber-400"
            : "text-zinc-600 hover:text-amber-300"
        }`}
      />
    </button>
  );
}

function RenameButton({
  adAccountId,
  externalId,
  currentName,
  kind,
  onDone,
}: {
  adAccountId: string;
  externalId: string;
  currentName: string;
  kind: "campaign" | "adset" | "ad";
  onDone: () => void;
}) {
  const [isPending, startTransition] = useTransition();
  const label =
    kind === "campaign" ? "campanha" : kind === "adset" ? "conjunto" : "anúncio";

  function rename() {
    const next = window.prompt(`Novo nome do ${label}:`, currentName);
    if (next == null) return;
    const clean = next.trim();
    if (!clean || clean === currentName) return;
    startTransition(async () => {
      const r =
        kind === "campaign"
          ? await renameCampaignAction(adAccountId, externalId, clean)
          : kind === "adset"
            ? await renameAdsetAction(adAccountId, externalId, clean)
            : await renameAdAction(adAccountId, externalId, clean);
      if (r.ok) onDone();
      else alert("Erro ao renomear: " + (r.error || ""));
    });
  }

  return (
    <button
      type="button"
      onClick={rename}
      disabled={isPending}
      title={`Editar nome do ${label}`}
      className="shrink-0 rounded p-0.5 text-zinc-500 hover:bg-white/[0.06] hover:text-white transition disabled:opacity-50"
    >
      {isPending ? (
        <Loader2 className="size-3 animate-spin" />
      ) : (
        <Pencil className="size-3" />
      )}
    </button>
  );
}

function BudgetModal({
  adAccountId,
  campaignExternalId,
  campaignName,
  currentBudgetCents,
  kind = "campaign",
  onClose,
  onSaved,
}: {
  adAccountId: string;
  campaignExternalId: string;
  campaignName: string;
  currentBudgetCents: number | null;
  kind?: "campaign" | "adset";
  onClose: () => void;
  onSaved: () => void;
}) {
  const [value, setValue] = useState(
    currentBudgetCents ? (currentBudgetCents / 100).toFixed(2) : "",
  );
  const [isPending, startTransition] = useTransition();
  const [err, setErr] = useState<string | null>(null);

  function save() {
    setErr(null);
    const cents = Math.round(Number(value.replace(",", ".")) * 100);
    if (!Number.isFinite(cents) || cents < 100) {
      setErr("Valor inválido (mínimo R$ 1,00)");
      return;
    }
    startTransition(async () => {
      const r =
        kind === "adset"
          ? await setAdsetBudgetAction(adAccountId, campaignExternalId, cents)
          : await setCampaignBudget(adAccountId, campaignExternalId, cents);
      if (r.ok) {
        onSaved();
      } else {
        setErr(r.error || "Erro ao salvar");
      }
    });
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm rounded-2xl border border-white/[0.08] bg-zinc-950 p-5 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between mb-3">
          <div>
            <h3 className="text-sm font-semibold text-white">
              Ajustar Orçamento Diário
            </h3>
            <p className="text-[11px] text-zinc-500 mt-0.5 truncate max-w-[260px]">
              {campaignName}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-md p-1 text-zinc-500 hover:bg-white/[0.06] hover:text-white"
          >
            <X className="size-4" />
          </button>
        </div>

        <label className="block text-[10px] text-zinc-500 mb-1">
          Valor (R$)
        </label>
        <input
          type="text"
          inputMode="decimal"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          placeholder="50,00"
          className="w-full rounded-lg border border-white/[0.08] bg-white/[0.02] px-3 py-2 text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-lime-400/40"
          autoFocus
        />
        {err && <p className="mt-2 text-xs text-red-300">{err}</p>}

        <div className="flex items-center justify-end gap-2 mt-4">
          <button
            type="button"
            onClick={onClose}
            className="rounded-full border border-white/[0.08] bg-white/[0.02] px-3 py-1.5 text-xs text-zinc-300 hover:bg-white/[0.05]"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={save}
            disabled={isPending}
            className="inline-flex items-center gap-1.5 rounded-full bg-lime-400 px-3 py-1.5 text-xs font-semibold text-black hover:bg-lime-300 transition disabled:opacity-50"
          >
            {isPending && <Loader2 className="size-3 animate-spin" />}
            Salvar
          </button>
        </div>
      </div>
    </div>
  );
}
