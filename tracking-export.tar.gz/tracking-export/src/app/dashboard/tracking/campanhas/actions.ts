"use server";

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/prisma";
import { requireUserId } from "@/lib/auth-helpers";
import {
  setObjectStatus,
  setObjectBudget,
  setAdsetBudget,
  setCampaignName,
  setAdsetName,
  setAdName,
  syncAdAccount,
} from "@/lib/ad-sync";
import { decryptString } from "@/lib/crypto";

export async function setAdObjectStatus(
  adAccountId: string,
  kind: "campaign" | "adset" | "ad",
  externalId: string,
  status: "ACTIVE" | "PAUSED",
) {
  const userId = await requireUserId();
  const acc = await prisma.adAccount.findFirst({
    where: { id: adAccountId, userId },
    select: { id: true },
  });
  if (!acc) return { ok: false as const, error: "Conta não encontrada." };
  const r = await setObjectStatus(adAccountId, kind, externalId, status);
  revalidatePath("/dashboard/tracking/campanhas");
  return r;
}

export async function syncAllAccounts() {
  const userId = await requireUserId();
  const accounts = await prisma.adAccount.findMany({
    where: {
      userId,
      platform: { in: ["meta", "tiktok"] },
      status: "active",
      enabled: true,
    },
    select: { id: true },
  });
  const results = await Promise.all(accounts.map((a) => syncAdAccount(a.id)));
  revalidatePath("/dashboard/tracking/campanhas");
  return { ok: true as const, results };
}

export async function setCampaignBudget(
  adAccountId: string,
  campaignExternalId: string,
  dailyBudgetCents: number,
) {
  const userId = await requireUserId();
  const acc = await prisma.adAccount.findFirst({
    where: { id: adAccountId, userId },
    select: { id: true },
  });
  if (!acc) return { ok: false as const, error: "Conta não encontrada." };
  const r = await setObjectBudget(adAccountId, campaignExternalId, dailyBudgetCents);
  revalidatePath("/dashboard/tracking/campanhas");
  return r;
}

export async function setAdsetBudgetAction(
  adAccountId: string,
  adsetExternalId: string,
  dailyBudgetCents: number,
) {
  const userId = await requireUserId();
  const acc = await prisma.adAccount.findFirst({
    where: { id: adAccountId, userId },
    select: { id: true },
  });
  if (!acc) return { ok: false as const, error: "Conta não encontrada." };
  const r = await setAdsetBudget(adAccountId, adsetExternalId, dailyBudgetCents);
  revalidatePath("/dashboard/tracking/campanhas");
  return r;
}

export async function renameCampaignAction(
  adAccountId: string,
  campaignExternalId: string,
  name: string,
) {
  const userId = await requireUserId();
  const acc = await prisma.adAccount.findFirst({
    where: { id: adAccountId, userId },
    select: { id: true },
  });
  if (!acc) return { ok: false as const, error: "Conta não encontrada." };
  const clean = (name || "").trim();
  if (clean.length < 1 || clean.length > 400) {
    return { ok: false as const, error: "Nome inválido." };
  }
  const r = await setCampaignName(adAccountId, campaignExternalId, clean);
  revalidatePath("/dashboard/tracking/campanhas");
  return r;
}

export async function renameAdsetAction(
  adAccountId: string,
  externalId: string,
  name: string,
) {
  const userId = await requireUserId();
  const acc = await prisma.adAccount.findFirst({
    where: { id: adAccountId, userId },
    select: { id: true },
  });
  if (!acc) return { ok: false as const, error: "Conta não encontrada." };
  const clean = (name || "").trim();
  if (clean.length < 1 || clean.length > 400)
    return { ok: false as const, error: "Nome inválido." };
  const r = await setAdsetName(adAccountId, externalId, clean);
  revalidatePath("/dashboard/tracking/campanhas");
  return r;
}

export async function renameAdAction(
  adAccountId: string,
  externalId: string,
  name: string,
) {
  const userId = await requireUserId();
  const acc = await prisma.adAccount.findFirst({
    where: { id: adAccountId, userId },
    select: { id: true },
  });
  if (!acc) return { ok: false as const, error: "Conta não encontrada." };
  const clean = (name || "").trim();
  if (clean.length < 1 || clean.length > 400)
    return { ok: false as const, error: "Nome inválido." };
  const r = await setAdName(adAccountId, externalId, clean);
  revalidatePath("/dashboard/tracking/campanhas");
  return r;
}

/** ⭐ Favorita/desfavorita uma campanha (aparece no topo do dashboard). */
export async function toggleCampaignFavorite(
  adAccountId: string,
  externalId: string,
  favorite: boolean,
) {
  const userId = await requireUserId();
  const acc = await prisma.adAccount.findFirst({
    where: { id: adAccountId, userId },
    select: { id: true },
  });
  if (!acc) return { ok: false as const, error: "Conta não encontrada." };
  await prisma.adCampaign.updateMany({
    where: { adAccountId: acc.id, externalId },
    data: { favorite },
  });
  revalidatePath("/dashboard/tracking/campanhas");
  revalidatePath("/dashboard");
  return { ok: true as const };
}

/**
 * 📌 Define manualmente a moeda da conta (fallback se a detecção falhar) +
 * uma taxa de câmbio manual opcional (fxRate). fxRate null = câmbio automático.
 */
export async function setAccountCurrencyAction(
  adAccountId: string,
  currency: string,
  fxRate?: number | null,
) {
  const userId = await requireUserId();
  const acc = await prisma.adAccount.findFirst({
    where: { id: adAccountId, userId },
    select: { id: true },
  });
  if (!acc) return { ok: false as const, error: "Conta não encontrada." };
  const code = (currency || "").trim().toUpperCase();
  if (!/^[A-Z]{3}$/.test(code))
    return { ok: false as const, error: "Código de moeda inválido (ex: BRL)." };
  const rate =
    fxRate != null && Number.isFinite(fxRate) && fxRate > 0 ? fxRate : null;
  await prisma.adAccount.update({
    where: { id: acc.id },
    data: { currency: code, fxRateOverride: rate },
  });
  revalidatePath("/dashboard/tracking/campanhas");
  return { ok: true as const };
}

export async function duplicateCampaign(
  adAccountId: string,
  campaignExternalId: string,
) {
  const userId = await requireUserId();
  const acc = await prisma.adAccount.findFirst({
    where: { id: adAccountId, userId },
  });
  if (!acc) return { ok: false as const, error: "Conta não encontrada." };

  try {
    const token = decryptString(acc.accessToken);
    const url = new URL(
      `https://graph.facebook.com/v19.0/${campaignExternalId}/copies`,
    );
    url.searchParams.set("access_token", token);
    const res = await fetch(url.toString(), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        deep_copy: true,
        status_option: "PAUSED",
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      return { ok: false as const, error: data.error?.message || "Falha." };
    }
    // Sincroniza pra trazer a nova campanha
    await syncAdAccount(acc.id);
    revalidatePath("/dashboard/tracking/campanhas");
    return { ok: true as const, copiedId: data.copied_campaign_id };
  } catch (e) {
    return {
      ok: false as const,
      error: e instanceof Error ? e.message : "unknown",
    };
  }
}
