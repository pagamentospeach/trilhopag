import { Stethoscope, AlertTriangle, CheckCircle2, Link2 } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { requireUserId } from "@/lib/auth-helpers";
import { formatBRL } from "@/lib/utils";
import { normUtm, resolveUtmToExternalId } from "@/lib/utm-match";

export const dynamic = "force-dynamic";

/**
 * Diagnóstico de UTM — mostra quantas vendas estão (ou não) sendo atribuídas a
 * uma campanha, com exemplos, pra o seller ver na hora se o tracking do anúncio
 * está configurado certo.
 */
export default async function DiagnosticoPage() {
  const userId = await requireUserId();
  const since = new Date();
  since.setUTCDate(since.getUTCDate() - 30);

  const [txs, campaigns] = await Promise.all([
    prisma.transaction.findMany({
      where: {
        userId,
        provider: { not: "test" },
        status: "PAID",
        paidAt: { gte: since },
      },
      select: {
        utmSource: true,
        utmMedium: true,
        utmCampaign: true,
        amountCents: true,
        paidAt: true,
      },
      orderBy: { paidAt: "desc" },
    }),
    prisma.adCampaign.findMany({
      where: { adAccount: { userId } },
      select: { externalId: true, name: true },
    }),
  ]);

  const campExtIds = new Set(campaigns.map((c) => c.externalId));
  const campByName = new Map<string, string>();
  for (const c of campaigns) {
    const k = normUtm(c.name);
    if (k && !campByName.has(k)) campByName.set(k, c.externalId);
  }

  const total = txs.length;
  let withCampaign = 0;
  let attributed = 0;
  const unmatched = new Map<string, { count: number; cents: number }>();
  const bySource = new Map<string, { count: number; attributed: number }>();
  const untrackedExamples: typeof txs = [];

  for (const t of txs) {
    const hasCamp = !!(t.utmCampaign || "").trim();
    if (hasCamp) withCampaign++;
    const ext = resolveUtmToExternalId(t.utmCampaign, campExtIds, campByName);
    if (ext) attributed++;

    const src = (t.utmSource || "").trim() || "(sem source)";
    const bs = bySource.get(src) ?? { count: 0, attributed: 0 };
    bs.count++;
    if (ext) bs.attributed++;
    bySource.set(src, bs);

    if (!ext) {
      if (hasCamp) {
        // capturou utm_campaign mas não casou com nenhuma campanha sincronizada
        const key = t.utmCampaign!.trim();
        const u = unmatched.get(key) ?? { count: 0, cents: 0 };
        u.count++;
        u.cents += t.amountCents;
        unmatched.set(key, u);
      } else if (untrackedExamples.length < 10) {
        untrackedExamples.push(t);
      }
    }
  }

  const withoutCampaign = total - withCampaign;
  const attributedPct = total > 0 ? Math.round((attributed / total) * 100) : 0;
  const topUnmatched = [...unmatched.entries()]
    .sort((a, b) => b[1].count - a[1].count)
    .slice(0, 8);
  const topSources = [...bySource.entries()]
    .sort((a, b) => b[1].count - a[1].count)
    .slice(0, 8);

  const healthColor =
    attributedPct >= 70
      ? "text-lime-400"
      : attributedPct >= 30
        ? "text-amber-400"
        : "text-red-400";

  return (
    <div className="max-w-5xl space-y-6">
      <header>
        <h1 className="flex items-center gap-2 text-2xl font-semibold text-white">
          <Stethoscope className="size-5 text-lime-400" />
          Diagnóstico de UTM
        </h1>
        <p className="mt-1 max-w-2xl text-sm text-zinc-400">
          Quantas vendas (últimos 30 dias) estão sendo atribuídas a uma campanha.
          Se a % está baixa, o tracking dos anúncios provavelmente não está
          mandando o utm_campaign.
        </p>
      </header>

      {total === 0 ? (
        <div className="rounded-2xl border border-white/[0.08] bg-white/[0.02] p-10 text-center text-sm text-zinc-500">
          Sem vendas pagas nos últimos 30 dias.
        </div>
      ) : (
        <>
          {/* Saúde geral */}
          <div className="rounded-2xl border border-white/[0.08] bg-white/[0.02] p-5">
            <p className="text-[11px] uppercase tracking-wider text-zinc-500">
              Vendas rastreadas (casadas com campanha)
            </p>
            <p className={`mt-1 text-4xl font-bold tabular-nums ${healthColor}`}>
              {attributedPct}%
            </p>
            <p className="mt-1 text-sm text-zinc-400">
              {attributed} de {total} vendas dos últimos 30 dias têm campanha
              identificada.
            </p>
          </div>

          {/* Cards */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Stat label="Vendas (30d)" value={String(total)} />
            <Stat label="Com utm_campaign" value={String(withCampaign)} tone="lime" />
            <Stat
              label="Sem utm_campaign"
              value={String(withoutCampaign)}
              tone={withoutCampaign > 0 ? "red" : undefined}
            />
            <Stat
              label="Casadas c/ campanha"
              value={String(attributed)}
              tone="lime"
            />
          </div>

          {/* Aviso */}
          {withoutCampaign > 0 && (
            <div className="rounded-xl border border-amber-500/30 bg-amber-500/[0.06] p-4">
              <p className="flex items-center gap-2 text-sm font-semibold text-amber-300">
                <AlertTriangle className="size-4" />
                {withoutCampaign} venda(s) chegaram SEM campanha (UTM faltando)
              </p>
              <p className="mt-1 text-[12px] text-amber-100/80">
                Esses anúncios não estão mandando o <code>utm_campaign</code> na
                URL de destino — então não dá pra saber de qual campanha vieram.
                Veja como corrigir abaixo. 👇
              </p>
            </div>
          )}

          {/* UTMs capturados mas que não casaram com campanha */}
          {topUnmatched.length > 0 && (
            <Section
              title="utm_campaign que NÃO casou com nenhuma campanha"
              hint="A venda trouxe um utm_campaign, mas ele não bate com o nome (nem o id) de nenhuma campanha sincronizada — campanha renomeada, não sincronizada, ou nome diferente."
            >
              <div className="divide-y divide-white/[0.05]">
                {topUnmatched.map(([val, info], i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between gap-3 px-1 py-2 text-xs"
                  >
                    <code className="truncate text-zinc-300" title={val}>
                      {val}
                    </code>
                    <span className="shrink-0 tabular-nums text-zinc-500">
                      {info.count}× · {formatBRL(info.cents)}
                    </span>
                  </div>
                ))}
              </div>
            </Section>
          )}

          {/* Exemplos de vendas sem campanha */}
          {untrackedExamples.length > 0 && (
            <Section
              title="Exemplos de vendas sem campanha"
              hint="Veja o utm_source dessas vendas — normalmente é um id gerado e o utm_campaign vem vazio (anúncio sem tracking)."
            >
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b border-white/[0.06] text-[10px] uppercase text-zinc-600">
                      <th className="px-2 py-1.5 text-left">Data</th>
                      <th className="px-2 py-1.5 text-right">Valor</th>
                      <th className="px-2 py-1.5 text-left">utm_source</th>
                      <th className="px-2 py-1.5 text-left">utm_medium</th>
                    </tr>
                  </thead>
                  <tbody>
                    {untrackedExamples.map((t, i) => (
                      <tr key={i} className="border-b border-white/[0.03]">
                        <td className="px-2 py-1.5 text-zinc-400">
                          {t.paidAt?.toLocaleDateString("pt-BR", {
                            day: "2-digit",
                            month: "2-digit",
                          })}
                        </td>
                        <td className="px-2 py-1.5 text-right tabular-nums text-zinc-300">
                          {formatBRL(t.amountCents)}
                        </td>
                        <td className="px-2 py-1.5">
                          <code className="text-zinc-400">
                            {t.utmSource || "—"}
                          </code>
                        </td>
                        <td className="px-2 py-1.5">
                          <code className="text-zinc-500">
                            {t.utmMedium || "—"}
                          </code>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Section>
          )}

          {/* Top sources */}
          {topSources.length > 0 && (
            <Section title="Por origem (utm_source)">
              <div className="divide-y divide-white/[0.05]">
                {topSources.map(([src, info], i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between gap-3 px-1 py-2 text-xs"
                  >
                    <code className="truncate text-zinc-300" title={src}>
                      {src}
                    </code>
                    <span className="shrink-0 tabular-nums text-zinc-500">
                      {info.count} venda(s) ·{" "}
                      <span
                        className={
                          info.attributed === info.count
                            ? "text-lime-400"
                            : info.attributed === 0
                              ? "text-red-400"
                              : "text-amber-400"
                        }
                      >
                        {info.attributed} casada(s)
                      </span>
                    </span>
                  </div>
                ))}
              </div>
            </Section>
          )}

          {/* Como corrigir */}
          <div className="rounded-2xl border border-lime-400/20 bg-lime-400/[0.04] p-5">
            <p className="flex items-center gap-2 text-sm font-semibold text-lime-300">
              <Link2 className="size-4" />
              Como rastrear 100% das vendas
            </p>
            <p className="mt-2 text-[13px] text-zinc-300">
              No anúncio, coloque os parâmetros UTM na <strong>URL de destino</strong>{" "}
              (ou em &quot;Parâmetros de URL&quot;). Os nomes precisam casar com o
              que sincronizamos — o essencial é o <code>utm_campaign</code>:
            </p>
            <pre className="mt-2 overflow-x-auto rounded-lg border border-white/[0.08] bg-black/40 p-3 text-[11px] text-lime-200">
{`# TikTok (use os macros do painel "Tracking URL")
utm_source=tiktok&utm_medium=__AID_NAME__&utm_campaign=__CAMPAIGN_NAME__&utm_content=__CID_NAME__

# Meta / UTMify (formato "nome|id" também funciona)
utm_source=facebook&utm_campaign={{campaign.name}}|{{campaign.id}}`}
            </pre>
            <p className="mt-2 flex items-center gap-1.5 text-[12px] text-zinc-400">
              <CheckCircle2 className="size-3.5 text-lime-400" />
              Já aceitamos os 2 formatos: nome puro (TikTok) e &quot;nome|id&quot;
              (Meta/UTMify).
            </p>
          </div>
        </>
      )}
    </div>
  );
}

function Stat({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone?: "lime" | "red";
}) {
  return (
    <div className="rounded-xl border border-white/[0.08] bg-white/[0.02] p-4">
      <p className="text-[10px] uppercase tracking-wider text-zinc-500">
        {label}
      </p>
      <p
        className={`mt-1 text-lg font-semibold tabular-nums ${
          tone === "lime"
            ? "text-lime-400"
            : tone === "red"
              ? "text-red-400"
              : "text-white"
        }`}
      >
        {value}
      </p>
    </div>
  );
}

function Section({
  title,
  hint,
  children,
}: {
  title: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-white/[0.08] bg-white/[0.02] p-4">
      <p className="text-[11px] uppercase tracking-wider text-zinc-500">
        {title}
      </p>
      {hint && <p className="mt-1 text-[11px] text-zinc-600">{hint}</p>}
      <div className="mt-2">{children}</div>
    </div>
  );
}
