import { TutorialClient } from "./client";

export default function TutorialPage() {
  return <TutorialClient />;
}
