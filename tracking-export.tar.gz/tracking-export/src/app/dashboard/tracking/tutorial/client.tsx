"use client";

import { useState } from "react";
import {
  Copy,
  Check,
  Code,
  AlertCircle,
  Sparkles,
  Globe,
  Plug,
} from "lucide-react";
import { MAIN_DOMAIN } from "@/lib/checkout-url";

const UTM_TEMPLATES = [
  {
    platform: "Meta (Facebook + Instagram)",
    color: "from-blue-500/20 to-cyan-500/20",
    description:
      "Cole isso no campo Parâmetro de URL do anúncio quando criar a campanha no Meta Ads.",
    code: "utm_source=FB&utm_campaign={{campaign.name}}|{{campaign.id}}&utm_medium={{adset.name}}|{{adset.id}}&utm_content={{ad.name}}|{{ad.id}}&utm_term={{placement}}",
  },
  {
    platform: "TikTok Ads",
    color: "from-pink-500/20 to-cyan-500/20",
    description: "Cole no campo URL Tracking quando criar o anúncio no TikTok.",
    code: "?utm_source=tiktok&utm_campaign=__CAMPAIGN_NAME__|__CAMPAIGN_ID__&utm_medium=__AID_NAME__|__AID__&utm_content=__CID_NAME__|__CID__&utm_term=__PLACEMENT__&utm_id=__CAMPAIGN_ID__",
  },
  {
    platform: "Kwai Ads",
    color: "from-orange-500/20 to-yellow-500/20",
    description: "Adicione no URL final do anúncio no Kwai for Business.",
    code: "?utm_source=kwai&utm_campaign=__CMPNID__&utm_medium=__ADSETID__&utm_content=__ADID__::__CALLBACK__::__KS_PIXELID__",
  },
  {
    platform: "Google Ads",
    color: "from-red-500/20 to-yellow-500/20",
    description: "Adicione em Modelo de rastreamento na conta do Google Ads.",
    code: "{lpurl}?utm_source=google&utm_campaign={campaignid}&utm_medium={adgroupid}&utm_content={creative}&utm_term={placement}::{keyword}&keyword={keyword}&device={device}&network={network}",
  },
];

// Usa MAIN_DOMAIN do helper centralizado pra que, se o dominio do gateway
// trocar de novo (ja trocou solutions → site → club), o tutorial atualiza
// sozinho. NAO hard-code o host aqui.
const SCRIPTS = [
  {
    name: "UTM Persist (essencial)",
    description:
      "Captura UTMs da URL e salva. Injeta automaticamente em todos os forms e links. Essencial pra que o gateway saiba de onde veio cada venda.",
    code: `<script
  src="${MAIN_DOMAIN}/scripts/utm-persist.js"
  async
  defer
></script>`,
  },
  {
    name: "Back Redirect (opcional)",
    description:
      "Intercepta o botão voltar do navegador e redireciona pra outra página (downsell). Substitua a URL pelo destino que você quer.",
    code: `<script
  src="${MAIN_DOMAIN}/scripts/back-redirect.js"
  data-bp-redirect="https://seudominio.com/oferta-especial"
  async
></script>`,
  },
  {
    name: "Pixel Helper (opcional)",
    description:
      "Carrega o pixel do Meta e do TikTok na sua landing page e dispara PageView. O checkout já dispara InitiateCheckout e Purchase automaticamente.",
    code: `<script
  src="${MAIN_DOMAIN}/scripts/pixel.js"
  data-fb-pixel="SEU_PIXEL_META_ID"
  data-tk-pixel="SEU_PIXEL_TIKTOK_ID"
  async
></script>`,
  },
];

export function TutorialClient() {
  return (
    <div className="space-y-6">
      {/* Como integrar a conta Meta */}
      <section className="rounded-2xl border border-blue-400/30 bg-gradient-to-br from-blue-500/[0.08] to-cyan-500/[0.04] p-5">
        <div className="flex items-start gap-3 mb-4">
          <Plug className="size-5 shrink-0 text-blue-300 mt-0.5" />
          <div>
            <h2 className="text-base font-semibold text-white">
              Como conectar sua conta Meta Ads
            </h2>
            <p className="mt-1 text-xs text-zinc-300">
              Passo a passo em menos de 1 minuto pra ver suas campanhas aparecerem aqui.
            </p>
          </div>
        </div>

        <div className="rounded-xl border border-yellow-400/30 bg-yellow-400/[0.06] p-3 mb-4 flex items-start gap-2 text-xs text-yellow-100">
          <Globe className="size-4 shrink-0 text-yellow-300 mt-0.5" />
          <div>
            <strong>IMPORTANTE — mesmo navegador.</strong> Abra o BravoPay no{" "}
            <em>mesmo navegador</em> onde sua conta do Facebook está logada
            (Chrome/Edge/etc). Se você está usando Safari mas o Facebook está
            no Chrome, copie a URL{" "}
            <code className="text-yellow-200">{MAIN_DOMAIN.replace(/^https?:\/\//, "")}</code> e cole
            no Chrome antes de conectar. Caso contrário, o OAuth vai falhar
            com{" "}
            <code className="text-yellow-200">invalid_state</code>.
          </div>
        </div>

        <ol className="text-xs text-zinc-200 space-y-2.5 list-decimal pl-5">
          <li>
            Verifique que o Facebook está logado no <strong>mesmo navegador</strong>{" "}
            que você está usando agora. Se não tiver, abra{" "}
            <code className="text-blue-300">facebook.com</code> em uma aba nova
            e faça login.
          </li>
          <li>
            Volte aqui no BravoPay e vá em{" "}
            <strong>Tracking → Integrações</strong>.
          </li>
          <li>
            Clique em <strong>Conectar conta Meta</strong>. Vai abrir uma
            janela do Facebook pedindo permissão pra ler suas contas de
            anúncio.
          </li>
          <li>
            <strong>Selecione TODAS as contas de anúncio</strong> que você
            quer trackear (você pode marcar várias de uma vez). Clique em{" "}
            <em>Continuar</em>.
          </li>
          <li>
            Você será redirecionado de volta pra integrações com suas contas
            já listadas. Pode ativar/desativar individualmente cada uma.
          </li>
          <li>
            Em <strong>Campanhas</strong>, clique em <em>Atualizar agora</em>{" "}
            pra puxar todas as campanhas, conjuntos e anúncios. (Roda
            automático a cada 30min depois.)
          </li>
          <li>
            Cole o template de UTM do Meta (abaixo) no campo{" "}
            <strong>Parâmetro de URL</strong> de cada campanha pra cruzar com
            as vendas.
          </li>
        </ol>
      </section>

      {/* Aviso importante */}
      <div className="rounded-2xl border border-lime-400/30 bg-lime-400/[0.05] p-5">
        <div className="flex items-start gap-3">
          <Sparkles className="size-5 shrink-0 text-lime-300" />
          <div>
            <p className="text-sm font-semibold text-white">
              Por que isso importa
            </p>
            <p className="mt-1 text-xs text-zinc-300 leading-relaxed">
              Os UTMs com o formato <code className="text-lime-300">nome|id</code>{" "}
              (ex: <code className="text-lime-300">Black Friday Q4|6231984720</code>) são a chave que liga uma venda
              à campanha que a originou. Sem isso, conseguimos ver de qual plataforma veio (FB/TikTok), mas não em qual campanha
              específica — então <strong>ROAS, CPA e Lucro por campanha</strong> ficam zerados.
            </p>
          </div>
        </div>
      </div>

      {/* UTM Templates */}
      <section className="space-y-3">
        <h2 className="text-base font-semibold text-white">
          UTMs por plataforma
        </h2>
        <p className="text-xs text-zinc-400">
          Cole o template correspondente no campo de parâmetros UTM da
          plataforma de ads. As variáveis (<code>{"{{campaign.name}}"}</code>,
          <code>__CAMPAIGN_NAME__</code>, etc) são substituídas automaticamente
          pela plataforma.
        </p>
        {UTM_TEMPLATES.map((t) => (
          <CodeCard
            key={t.platform}
            title={t.platform}
            description={t.description}
            code={t.code}
            color={t.color}
          />
        ))}
      </section>

      {/* Scripts */}
      <section className="space-y-3">
        <h2 className="text-base font-semibold text-white">
          Scripts pra colar na sua landing page
        </h2>
        <p className="text-xs text-zinc-400">
          Adicione no <code>&lt;head&gt;</code> ou antes do{" "}
          <code>&lt;/body&gt;</code> da sua página de venda. Hospedamos na
          nossa CDN — sem dependências externas.
        </p>
        {SCRIPTS.map((s) => (
          <CodeCard
            key={s.name}
            title={s.name}
            description={s.description}
            code={s.code}
            color="from-zinc-800/40 to-transparent"
          />
        ))}
      </section>

      {/* Guia rápido */}
      <section className="rounded-2xl border border-white/[0.06] bg-white/[0.02] p-5">
        <p className="text-sm font-semibold text-white mb-3">
          Guia rápido — primeira vez
        </p>
        <ol className="text-xs text-zinc-300 space-y-2 list-decimal pl-5">
          <li>
            Copie o template de UTM do Meta e cole no campo{" "}
            <strong>Parâmetro de URL</strong> da sua campanha nova.
          </li>
          <li>
            Adicione o script <strong>UTM Persist</strong> na sua landing page.
          </li>
          <li>
            Conecte sua conta Meta na aba <strong>Integrações</strong> aqui.
          </li>
          <li>
            Suas campanhas vão aparecer em <strong>Campanhas</strong> — e os
            cards de ROAS/CPA/Lucro vão começar a aparecer no <strong>Resumo</strong>.
          </li>
        </ol>
      </section>

      {/* Erro comum */}
      <div className="rounded-xl border border-yellow-400/20 bg-yellow-400/[0.04] p-4 text-xs text-yellow-100/80 flex items-start gap-2">
        <AlertCircle className="size-4 shrink-0 text-yellow-300 mt-0.5" />
        <div>
          <strong>Erro comum:</strong> não esqueça do <code>|id</code> no template
          de UTM. Sem ele, não conseguimos cruzar com a Meta API. Se sua
          campanha existente não tem ID no UTM, edite o anúncio no Meta e cole
          o template novo.
        </div>
      </div>
    </div>
  );
}

function CodeCard({
  title,
  description,
  code,
  color,
}: {
  title: string;
  description: string;
  code: string;
  color: string;
}) {
  const [copied, setCopied] = useState(false);
  function copy() {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }
  return (
    <div
      className={`rounded-xl border border-white/[0.06] bg-gradient-to-br ${color} overflow-hidden`}
    >
      <div className="flex items-center justify-between border-b border-white/[0.06] bg-black/30 px-4 py-2.5">
        <div className="flex items-center gap-2 min-w-0">
          <Code className="size-3.5 shrink-0 text-zinc-400" />
          <p className="text-sm font-semibold text-white truncate">{title}</p>
        </div>
        <button
          type="button"
          onClick={copy}
          className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-[11px] font-medium transition ${
            copied
              ? "bg-lime-400 text-black"
              : "bg-white/[0.06] text-zinc-200 hover:bg-white/[0.12]"
          }`}
        >
          {copied ? <Check className="size-3" /> : <Copy className="size-3" />}
          {copied ? "Copiado!" : "Copiar"}
        </button>
      </div>
      <p className="px-4 pt-3 text-[11px] text-zinc-400">{description}</p>
      <pre className="px-4 py-3 text-[11px] font-mono text-zinc-200 overflow-x-auto whitespace-pre-wrap break-all">
        {code}
      </pre>
    </div>
  );
}
