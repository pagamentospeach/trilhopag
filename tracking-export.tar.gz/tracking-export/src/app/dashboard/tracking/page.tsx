import { CheckCircle2, AlertTriangle, Clock3 } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { requireUserId } from "@/lib/auth-helpers";
import { decryptString } from "@/lib/crypto";
import { getMe } from "@/lib/providers/meta-ads";
import { IntegracoesClient } from "./integracoes-client";

export default async function TrackingIntegracoesPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const userId = await requireUserId();
  const sp = await searchParams;

  const accounts = await prisma.adAccount.findMany({
    where: { userId, platform: { in: ["meta", "tiktok"] } },
    orderBy: { accountName: "asc" },
  });

  type ProfileBucket = {
    externalUserId: string;
    profileName: string;
    expiresAt: string | null;
    adAccounts: Array<{
      id: string;
      accountId: string;
      accountName: string;
      status: string;
      enabled: boolean;
      lastSyncAt: string | null;
      syncError: string | null;
      pixels: Array<{ id: string; name: string }>;
    }>;
  };
  const metaByProfile = new Map<string, ProfileBucket>();
  const tiktokByProfile = new Map<string, ProfileBucket>();

  // Cache nome do perfil Meta (busca da API só pra perfis sem name salvo)
  const profileNameCache = new Map<string, string>();
  for (const a of accounts) {
    if (a.profileName && !profileNameCache.has(a.externalUserId)) {
      profileNameCache.set(a.externalUserId, a.profileName);
    }
  }
  const missing = new Set<string>();
  for (const a of accounts) {
    if (a.platform === "meta" && !profileNameCache.has(a.externalUserId)) {
      missing.add(a.externalUserId);
    }
  }
  await Promise.all(
    Array.from(missing).map(async (externalUserId) => {
      const acc = accounts.find(
        (a) => a.externalUserId === externalUserId && a.platform === "meta",
      );
      if (!acc) return;
      try {
        const token = decryptString(acc.accessToken);
        const me = await getMe(token);
        profileNameCache.set(externalUserId, me.name);
        await prisma.adAccount.updateMany({
          where: { userId, externalUserId, platform: "meta" },
          data: { profileName: me.name },
        });
      } catch {
        profileNameCache.set(externalUserId, `Perfil ${externalUserId.slice(0, 8)}`);
      }
    }),
  );

  for (const a of accounts) {
    const bucket =
      a.platform === "tiktok" ? tiktokByProfile : metaByProfile;
    const defaultName =
      a.platform === "tiktok"
        ? `Business Center ${a.externalUserId.slice(0, 8)}`
        : `Perfil ${a.externalUserId.slice(0, 8)}`;
    if (!bucket.has(a.externalUserId)) {
      const profileName =
        a.profileName ||
        profileNameCache.get(a.externalUserId) ||
        defaultName;
      bucket.set(a.externalUserId, {
        externalUserId: a.externalUserId,
        profileName,
        expiresAt: a.expiresAt?.toISOString() ?? null,
        adAccounts: [],
      });
    }
    bucket.get(a.externalUserId)!.adAccounts.push({
      id: a.id,
      accountId: a.accountId,
      accountName: a.accountName,
      status: a.status,
      enabled: a.enabled,
      lastSyncAt: a.lastSyncAt?.toISOString() ?? null,
      syncError: a.syncError,
      pixels: Array.isArray(a.pixels)
        ? (a.pixels as Array<{ id: string; name: string }>)
        : [],
    });
  }

  const metaProfiles = Array.from(metaByProfile.values());
  const tiktokProfiles = Array.from(tiktokByProfile.values());

  return (
    <div className="space-y-6">
      {/* AVISO TEMPORARIO — app Meta em analise. Remover quando aprovar. */}
      <div className="relative overflow-hidden rounded-2xl border border-amber-400/30 bg-gradient-to-br from-amber-400/[0.08] via-amber-400/[0.04] to-transparent p-4">
        <div className="pointer-events-none absolute -top-12 -right-12 size-40 rounded-full bg-amber-400/15 blur-3xl" />
        <div className="relative flex items-start gap-3">
          <span className="inline-flex size-10 shrink-0 items-center justify-center rounded-xl bg-amber-400/15 text-amber-300">
            <Clock3 className="size-5" />
          </span>
          <div className="flex-1 space-y-1.5">
            <p className="text-sm font-semibold text-amber-100">
              Integração Meta em análise pelo Facebook
            </p>
            <p className="text-xs text-amber-100/70 leading-relaxed">
              Nosso aplicativo de integração com o Meta Ads está passando pela
              verificação oficial do Facebook (etapa obrigatória pra apps que
              gerenciam contas de anúncio). Algumas conexões podem ficar
              temporariamente indisponíveis nas próximas 24-72h.
              <br className="hidden sm:inline" />
              <strong className="text-amber-200">Não se preocupe</strong> — quem
              já está conectado <strong>continua sincronizando normalmente</strong>{" "}
              (insights, gasto, ROAS, etc). Novas conexões voltam a funcionar
              100% assim que o Facebook aprovar.
            </p>
            <p className="text-[11px] text-amber-200/60 pt-1">
              Status: Verificação da empresa em análise · Tempo estimado: 2-5
              dias úteis
            </p>
          </div>
        </div>
      </div>

      {sp.connected && (
        <div className="flex items-center gap-2 rounded-xl border border-lime-400/30 bg-lime-400/[0.05] px-4 py-3 text-sm text-lime-200">
          <CheckCircle2 className="size-4" />
          {sp.connected === "tiktok" ? "TikTok Business" : "Meta"} conectado com sucesso.{" "}
          {sp.count} {sp.connected === "tiktok" ? "advertiser(s)" : "ad account(s)"} sincronizada(s).
        </div>
      )}
      {sp.error && (
        <div className="flex items-center gap-2 rounded-xl border border-red-500/30 bg-red-500/[0.05] px-4 py-3 text-sm text-red-300">
          <AlertTriangle className="size-4" />
          Erro ao conectar: <code className="text-xs">{sp.error}</code>
        </div>
      )}

      <IntegracoesClient
        metaProfiles={metaProfiles}
        tiktokProfiles={tiktokProfiles}
      />

    </div>
  );
}
