"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import {
  Plus,
  Bot,
  Play,
  Pause,
  Trash2,
  Zap,
  Loader2,
  X,
  Clock,
  CheckCircle2,
  Power,
  Target,
  Rocket,
  AlertTriangle,
  Settings2,
  FlaskConical,
  Calculator,
} from "lucide-react";
import {
  createRule,
  toggleRule,
  deleteRule,
  runRuleNow,
  simulateRuleNow,
  killSwitchAccount,
  setGlobalTargetRoas,
  saveAdAutomationSettings,
} from "./actions";

type AdSettings = {
  adAlertsEnabled: boolean;
  adBurnAlertCents: number;
  autoScaleEnabled: boolean;
  autoScaleMinRoas: number;
  autoScaleStepPct: number;
  autoScaleMaxBudgetCents: number;
};

type Rule = {
  id: string;
  name: string;
  platform: string;
  scope: Record<string, unknown>;
  conditions: Array<Record<string, unknown>>;
  action: Record<string, unknown>;
  frequency: string;
  window: string;
  active: boolean;
  lastRunAt: string | null;
  lastExecution: {
    ranAt: string;
    matchedCount: number;
    actionTaken: string;
  } | null;
  executions: Array<{
    ranAt: string;
    matchedCount: number;
    actionTaken: string;
  }>;
};

/** Templates de regra prontos (1 clique). */
const RULE_TEMPLATES: Array<{
  key: string;
  label: string;
  desc: string;
  payload: {
    name: string;
    scope: { applyTo: "campaigns" | "adsets" | "ads"; filter: "active" | "all" };
    conditions: Array<{ metric: string; op: string; value: number }>;
    action: { type: string; value?: number };
    frequency: string;
    window: string;
  };
}> = [
  {
    key: "pause_low_roas",
    label: "Pausar ROAS < 1",
    desc: "Pausa campanha ativa que estiver com ROAS abaixo de 1 no dia.",
    payload: {
      name: "Pausar ROAS < 1",
      scope: { applyTo: "campaigns", filter: "active" },
      conditions: [{ metric: "roas", op: "lt", value: 1 }],
      action: { type: "pause" },
      frequency: "1h",
      window: "1d",
    },
  },
  {
    key: "pause_burning",
    label: "Pausar queimando (R$50, 0 venda)",
    desc: "Pausa campanha que gastou +R$50 no dia sem nenhuma venda.",
    payload: {
      name: "Pausar queimando (R$50 sem venda)",
      scope: { applyTo: "campaigns", filter: "active" },
      conditions: [
        { metric: "spend", op: "gt", value: 50 },
        { metric: "sales", op: "lt", value: 1 },
      ],
      action: { type: "pause" },
      frequency: "1h",
      window: "1d",
    },
  },
  {
    key: "scale_winner",
    label: "Escalar ROAS > 2 (+20%)",
    desc: "Sobe o orçamento em 20% de quem está com ROAS acima de 2.",
    payload: {
      name: "Escalar vencedora (ROAS > 2)",
      scope: { applyTo: "campaigns", filter: "active" },
      conditions: [{ metric: "roas", op: "gt", value: 2 }],
      action: { type: "budget_increase", value: 20 },
      frequency: "6h",
      window: "1d",
    },
  },
  {
    key: "pause_high_cpa",
    label: "Pausar CPA alto (> R$50)",
    desc: "Pausa campanha cujo custo por venda passar de R$50.",
    payload: {
      name: "Pausar CPA > R$50",
      scope: { applyTo: "campaigns", filter: "active" },
      conditions: [{ metric: "cpa", op: "gt", value: 50 }],
      action: { type: "pause" },
      frequency: "1h",
      window: "1d",
    },
  },
  {
    key: "dayparting_pause_night",
    label: "Dayparting: pausar 0h-6h",
    desc: "Pausa campanhas ativas da meia-noite às 6h (horário de Brasília).",
    payload: {
      name: "Dayparting — pausar 0h às 6h",
      scope: { applyTo: "campaigns", filter: "active" },
      conditions: [
        { metric: "hour", op: "gte", value: 0 },
        { metric: "hour", op: "lt", value: 6 },
      ],
      action: { type: "pause" },
      frequency: "15m",
      window: "1d",
    },
  },
  {
    key: "dayparting_resume_morning",
    label: "Dayparting: reativar às 6h",
    desc: "Reativa campanhas das 6h em diante. ⚠️ liga TODAS (use junto com a de pausar à noite).",
    payload: {
      name: "Dayparting — reativar das 6h",
      scope: { applyTo: "campaigns", filter: "all" },
      conditions: [{ metric: "hour", op: "gte", value: 6 }],
      action: { type: "activate" },
      frequency: "15m",
      window: "1d",
    },
  },
];

const METRIC_LABEL: Record<string, string> = {
  spend: "Gasto",
  cpa: "CPA",
  roas: "ROAS",
  roi: "ROI",
  profit: "Lucro",
  margin: "Margem",
  cpc: "CPC",
  ctr: "CTR",
  impressions: "Impressões",
  sales: "Vendas",
  hour: "Hora do dia (0-23, Brasília)",
};

const OP_LABEL: Record<string, string> = {
  gt: "maior que",
  lt: "menor que",
  gte: "≥",
  lte: "≤",
  eq: "=",
};

const ACTION_LABEL: Record<string, string> = {
  pause: "Pausar",
  activate: "Ativar",
  budget_increase: "Aumentar orçamento",
  budget_decrease: "Diminuir orçamento",
  notify: "Notificar",
};

export function RulesClient({
  rules,
  adAccounts,
  products,
  killAccounts,
  globalTarget,
  settings,
  avgTicketReais,
  feePercent,
}: {
  rules: Rule[];
  adAccounts: Array<{ id: string; accountName: string; platform: string }>;
  products: Array<{ id: string; name: string }>;
  killAccounts: Array<{ id: string; accountName: string; platform: string }>;
  globalTarget: number;
  settings: AdSettings;
  avgTicketReais: number;
  feePercent: number;
}) {
  const router = useRouter();
  const [showForm, setShowForm] = useState(false);

  return (
    <div className="space-y-4">
      {/* REGRAS primeiro: header + criar + lista */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <p className="text-xs text-zinc-400">
          {rules.length} regra{rules.length !== 1 ? "s" : ""} ·{" "}
          {rules.filter((r) => r.active).length} ativa
          {rules.filter((r) => r.active).length !== 1 ? "s" : ""} · regras
          rodam automaticamente conforme a frequência
        </p>
        <button
          type="button"
          onClick={() => setShowForm(true)}
          className="inline-flex items-center gap-1.5 rounded-full bg-lime-400 px-4 py-2 text-xs font-semibold text-black hover:bg-lime-300 transition"
        >
          <Plus className="size-3.5" /> Nova regra
        </button>
      </div>

      {rules.length === 0 && !showForm && (
        <div className="rounded-2xl border border-white/[0.08] bg-white/[0.02] p-12 text-center">
          <Bot className="mx-auto size-10 text-zinc-600" />
          <p className="mt-4 text-base font-semibold text-white">
            Nenhuma regra criada ainda
          </p>
          <p className="mt-2 text-sm text-zinc-400">
            Automatize ações como pausar campanhas com ROAS baixo, ativar com
            CPA bom ou ajustar orçamento de quem tá performando. Veja os
            templates prontos logo abaixo.
          </p>
          <button
            type="button"
            onClick={() => setShowForm(true)}
            className="mt-4 inline-flex items-center gap-1.5 rounded-full bg-lime-400 px-4 py-2 text-xs font-semibold text-black hover:bg-lime-300"
          >
            <Plus className="size-3.5" /> Criar primeira regra
          </button>
        </div>
      )}

      {rules.map((r) => (
        <RuleCard key={r.id} rule={r} onChange={() => router.refresh()} />
      ))}

      {/* FERRAMENTAS abaixo das regras — todas recolhidas por padrão */}
      <div className="space-y-3 pt-2">
        <AutomationPanel
          globalTarget={globalTarget}
          settings={settings}
          onSaved={() => router.refresh()}
        />
        {killAccounts.length > 0 && <KillSwitchPanel accounts={killAccounts} />}
        <CollapsibleShell
          title="Templates prontos — 1 clique"
          icon={<Zap className="size-4 text-yellow-300" />}
        >
          <RuleTemplates onCreated={() => router.refresh()} />
        </CollapsibleShell>
        <CollapsibleShell
          title="Calculadora de break-even"
          icon={<Calculator className="size-4 text-lime-400" />}
        >
          <BreakEvenCalc
            onSavedTarget={() => router.refresh()}
            avgTicketReais={avgTicketReais}
            feePercent={feePercent}
          />
        </CollapsibleShell>
      </div>

      {showForm && (
        <RuleFormModal
          onClose={() => setShowForm(false)}
          adAccounts={adAccounts}
          products={products}
          onSaved={() => {
            setShowForm(false);
            router.refresh();
          }}
        />
      )}
    </div>
  );
}

/** Casca recolhível padrão (header + toggle). Recolhida por padrão. */
function CollapsibleShell({
  title,
  icon,
  children,
}: {
  title: string;
  icon?: React.ReactNode;
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded-xl border border-white/[0.08] bg-white/[0.02]">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center justify-between px-4 py-3 text-left"
      >
        <span className="flex items-center gap-2 text-sm font-semibold text-white">
          {icon}
          {title}
        </span>
        <span className="text-xs text-zinc-500">{open ? "fechar" : "abrir"}</span>
      </button>
      {open && (
        <div className="border-t border-white/[0.06] p-4">{children}</div>
      )}
    </div>
  );
}

function KillSwitchPanel({
  accounts,
}: {
  accounts: Array<{ id: string; accountName: string; platform: string }>;
}) {
  return (
    <CollapsibleShell
      title="Kill switch — pausar tudo de uma conta"
      icon={<Power className="size-4 text-red-400" />}
    >
      <p className="text-[11px] text-zinc-500">
        Botão de pânico: pausa TODAS as campanhas da conta na hora (reversível —
        você reativa no painel da plataforma).
      </p>
      <div className="mt-3 flex flex-wrap gap-2">
        {accounts.map((a) => (
          <KillButton key={a.id} account={a} />
        ))}
      </div>
    </CollapsibleShell>
  );
}

/** 🧮 Calculadora de break-even — ROAS mínimo pra empatar. */
function BreakEvenCalc({
  onSavedTarget,
  avgTicketReais,
  feePercent,
}: {
  onSavedTarget: () => void;
  avgTicketReais: number;
  feePercent: number;
}) {
  // Pré-preenche com dados reais do seller (ticket médio + taxa do plano).
  const [ticket, setTicket] = useState(
    avgTicketReais > 0 ? avgTicketReais.toFixed(2) : "",
  );
  const [feePct, setFeePct] = useState(
    feePercent > 0 ? String(feePercent) : "",
  );
  const [cost, setCost] = useState("");
  const [isPending, startTransition] = useTransition();
  const [msg, setMsg] = useState<string | null>(null);

  const t = Number(ticket.replace(",", ".")) || 0;
  const f = Number(feePct.replace(",", ".")) || 0;
  const c = Number(cost.replace(",", ".")) || 0;
  const net = t - (t * f) / 100 - c; // líquido por venda (após taxa + custo)
  const beRoas = t > 0 && net > 0 ? t / net : null;

  function useAsTarget() {
    if (beRoas == null) return;
    const rounded = Math.round(beRoas * 100) / 100;
    startTransition(async () => {
      const r = await setGlobalTargetRoas(rounded);
      setMsg(r.ok ? `Meta global = ${rounded}x` : "Erro ao salvar.");
      onSavedTarget();
    });
  }

  const inputCls =
    "w-full rounded-md border border-white/[0.08] bg-white/[0.03] px-2 py-1.5 text-sm text-white outline-none focus:border-lime-400/50";

  return (
    <div>
      <p className="text-[11px] text-zinc-500">
        ROAS mínimo pra empatar — cobre o anúncio + a taxa do gateway + o custo
        do produto.
      </p>
      {avgTicketReais > 0 && (
        <p className="mt-1 text-[10px] text-zinc-600">
          Pré-preenchido com seu ticket médio real (30d) e a taxa do seu plano.
        </p>
      )}
      <div className="mt-3 grid grid-cols-3 gap-2">
        <label className="text-[11px] text-zinc-500">
          Ticket (R$)
          <input
            type="text"
            inputMode="decimal"
            value={ticket}
            onChange={(e) => setTicket(e.target.value)}
            placeholder="97"
            className={inputCls}
          />
        </label>
        <label className="text-[11px] text-zinc-500">
          Taxa gateway (%)
          <input
            type="text"
            inputMode="decimal"
            value={feePct}
            onChange={(e) => setFeePct(e.target.value)}
            placeholder="6.99"
            className={inputCls}
          />
        </label>
        <label className="text-[11px] text-zinc-500">
          Custo produto (R$)
          <input
            type="text"
            inputMode="decimal"
            value={cost}
            onChange={(e) => setCost(e.target.value)}
            placeholder="0"
            className={inputCls}
          />
        </label>
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-3">
        <span className="text-sm text-white">
          Break-even:{" "}
          <strong className="text-lime-300">
            {beRoas != null ? `${beRoas.toFixed(2)}x` : "—"}
          </strong>
        </span>
        <button
          type="button"
          onClick={useAsTarget}
          disabled={beRoas == null || isPending}
          className="rounded-md bg-lime-400 px-3 py-1.5 text-xs font-semibold text-black hover:bg-lime-300 transition disabled:opacity-50"
        >
          Usar como meta de ROAS
        </button>
        {msg && <span className="text-xs text-lime-300">{msg}</span>}
        {t > 0 && net <= 0 && (
          <span className="text-xs text-red-300">
            Sem margem: taxa + custo já consomem o ticket.
          </span>
        )}
      </div>
    </div>
  );
}

function RuleTemplates({ onCreated }: { onCreated: () => void }) {
  const [pendingKey, setPendingKey] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  function applyTemplate(t: (typeof RULE_TEMPLATES)[number]) {
    setPendingKey(t.key);
    startTransition(async () => {
      const r = await createRule({
        name: t.payload.name,
        platform: "meta",
        scope: t.payload.scope,
        conditions: t.payload.conditions,
        action: t.payload.action,
        frequency: t.payload.frequency,
        window: t.payload.window,
      });
      setPendingKey(null);
      if (r.ok) onCreated();
      else alert(r.error || "Erro ao criar regra.");
    });
  }

  return (
    <div>
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
        {RULE_TEMPLATES.map((t) => (
          <button
            key={t.key}
            type="button"
            onClick={() => applyTemplate(t)}
            disabled={isPending}
            className="flex items-start gap-2 rounded-lg border border-white/[0.06] bg-white/[0.02] p-3 text-left transition hover:border-lime-400/30 hover:bg-white/[0.04] disabled:opacity-50"
          >
            <span className="mt-0.5">
              {pendingKey === t.key ? (
                <Loader2 className="size-4 animate-spin text-lime-300" />
              ) : (
                <Plus className="size-4 text-lime-300" />
              )}
            </span>
            <span>
              <span className="block text-sm font-medium text-white">
                {t.label}
              </span>
              <span className="block text-[11px] text-zinc-500">{t.desc}</span>
            </span>
          </button>
        ))}
      </div>
      <p className="mt-2 text-[10px] text-zinc-600">
        Cria a regra na hora (ativa) — você edita ou exclui depois na lista
        abaixo. As ações de pausar/escalar rodam nas contas Meta.
      </p>
    </div>
  );
}

function RuleHistory({
  executions,
}: {
  executions: Array<{ ranAt: string; matchedCount: number; actionTaken: string }>;
}) {
  const [open, setOpen] = useState(false);
  return (
    <div className="mt-2">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="inline-flex items-center gap-1 text-[10px] text-zinc-500 hover:text-zinc-300"
      >
        <Clock className="size-3" />
        {open ? "Ocultar histórico" : `Histórico (${executions.length})`}
      </button>
      {open && (
        <ul className="mt-2 space-y-1 border-l border-white/[0.06] pl-3">
          {executions.map((e, i) => (
            <li key={i} className="text-[10px] text-zinc-400">
              <span className="text-zinc-300">
                {new Date(e.ranAt).toLocaleString("pt-BR", {
                  day: "2-digit",
                  month: "2-digit",
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </span>{" "}
              · {e.matchedCount} afetado(s) · {e.actionTaken}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function RuleCard({ rule, onChange }: { rule: Rule; onChange: () => void }) {
  const [isPending, startTransition] = useTransition();
  const scope = rule.scope as { applyTo?: string; filter?: string; nameFilter?: string };
  const action = rule.action as { type: string; value?: number };

  function onToggle() {
    startTransition(async () => {
      await toggleRule(rule.id, !rule.active);
      onChange();
    });
  }
  function onDelete() {
    if (!confirm(`Excluir regra "${rule.name}"?`)) return;
    startTransition(async () => {
      await deleteRule(rule.id);
      onChange();
    });
  }
  function onRunNow() {
    startTransition(async () => {
      const r = await runRuleNow(rule.id);
      onChange();
      if (r.ok) alert(`Executada: ${r.matchedCount} objetos afetados (ação: ${r.actionTaken})`);
    });
  }
  function onSimulate() {
    startTransition(async () => {
      const r = await simulateRuleNow(rule.id);
      if (r.ok)
        alert(
          `Simulação: ${r.matchedCount} objeto(s) bateriam essa regra agora (nada foi alterado).`,
        );
      else alert(r.error || "Erro na simulação.");
    });
  }

  return (
    <div
      className={`rounded-2xl border bg-white/[0.02] p-5 ${
        rule.active ? "border-lime-400/20" : "border-white/[0.06]"
      }`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <span
              className={`size-2 rounded-full ${rule.active ? "bg-lime-400" : "bg-zinc-600"}`}
            />
            <h3 className="text-base font-semibold text-white">{rule.name}</h3>
            <span className="rounded-full bg-white/[0.06] px-2 py-0.5 text-[10px] text-zinc-400 uppercase">
              {rule.platform}
            </span>
          </div>
          <p className="mt-1 text-xs text-zinc-400">
            Aplica em <strong>{scope.applyTo ?? "campanhas"}</strong>
            {scope.filter ? ` ${scope.filter === "active" ? "ativas" : "(todas)"}` : ""}
            {scope.nameFilter ? ` cujo nome contém "${scope.nameFilter}"` : ""}
          </p>

          {/* Condições */}
          <div className="mt-3 space-y-1">
            <p className="text-[10px] uppercase tracking-wider text-zinc-500">SE</p>
            {(rule.conditions as Array<{ metric: string; op: string; value: number }>).map((c, i) => (
              <p key={i} className="text-xs text-zinc-200">
                <strong>{METRIC_LABEL[c.metric] ?? c.metric}</strong>{" "}
                {OP_LABEL[c.op] ?? c.op}{" "}
                <strong className="text-lime-300">{c.value}</strong>{" "}
                <span className="text-zinc-500">
                  (na janela de {rule.window})
                </span>
              </p>
            ))}
          </div>

          {/* Ação */}
          <div className="mt-3">
            <p className="text-[10px] uppercase tracking-wider text-zinc-500">ENTÃO</p>
            <p className="text-xs text-zinc-200 mt-0.5">
              <Zap className="inline size-3 text-yellow-300 mr-1" />
              <strong>{ACTION_LABEL[action.type] ?? action.type}</strong>
              {action.value ? ` em ${action.value}%` : ""}
            </p>
          </div>

          <div className="mt-3 flex items-center gap-3 text-[10px] text-zinc-500">
            <span className="inline-flex items-center gap-1">
              <Clock className="size-3" /> Roda a cada {rule.frequency}
            </span>
            {rule.lastExecution && (
              <span className="inline-flex items-center gap-1">
                <CheckCircle2 className="size-3 text-lime-400" />
                Última: {rule.lastExecution.matchedCount} afetados (
                {rule.lastExecution.actionTaken}) ·{" "}
                {new Date(rule.lastExecution.ranAt).toLocaleString("pt-BR", {
                  day: "2-digit",
                  month: "2-digit",
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </span>
            )}
          </div>
          {rule.executions.length > 0 && (
            <RuleHistory executions={rule.executions} />
          )}
        </div>

        <div className="flex flex-col gap-2 shrink-0">
          <button
            type="button"
            onClick={onToggle}
            disabled={isPending}
            className={`inline-flex items-center gap-1 rounded-full border px-3 py-1 text-[11px] font-medium ${
              rule.active
                ? "border-lime-400/30 bg-lime-400/15 text-lime-300 hover:bg-lime-400/25"
                : "border-zinc-600/30 bg-zinc-600/15 text-zinc-400 hover:bg-zinc-600/25"
            }`}
          >
            {rule.active ? <Play className="size-3" /> : <Pause className="size-3" />}
            {rule.active ? "Ativa" : "Pausada"}
          </button>
          <button
            type="button"
            onClick={onRunNow}
            disabled={isPending}
            className="inline-flex items-center justify-center gap-1 rounded-full border border-white/[0.08] bg-white/[0.02] px-3 py-1 text-[11px] text-zinc-300 hover:bg-white/[0.05]"
          >
            {isPending ? <Loader2 className="size-3 animate-spin" /> : <Zap className="size-3" />}
            Rodar agora
          </button>
          <button
            type="button"
            onClick={onSimulate}
            disabled={isPending}
            className="inline-flex items-center justify-center gap-1 rounded-full border border-white/[0.08] bg-white/[0.02] px-3 py-1 text-[11px] text-zinc-300 hover:bg-white/[0.05]"
            title="Simular sem aplicar (dry-run)"
          >
            <FlaskConical className="size-3" />
            Simular
          </button>
          <button
            type="button"
            onClick={onDelete}
            disabled={isPending}
            className="inline-flex items-center justify-center rounded-full border border-white/[0.08] bg-white/[0.02] p-1.5 text-zinc-400 hover:border-red-400/40 hover:bg-red-400/10 hover:text-red-300"
            title="Excluir"
          >
            <Trash2 className="size-3" />
          </button>
        </div>
      </div>
    </div>
  );
}

function RuleFormModal({
  onClose,
  onSaved,
  adAccounts,
  products,
}: {
  onClose: () => void;
  onSaved: () => void;
  adAccounts: Array<{ id: string; accountName: string; platform: string }>;
  products: Array<{ id: string; name: string }>;
}) {
  const [name, setName] = useState("");
  const [applyTo, setApplyTo] = useState<"campaigns" | "adsets" | "ads">("campaigns");
  const [filter, setFilter] = useState<"active" | "all">("active");
  const [nameFilter, setNameFilter] = useState("");
  const [productId, setProductId] = useState("");
  const [conditions, setConditions] = useState<
    Array<{ metric: string; op: string; value: number }>
  >([{ metric: "roas", op: "lt", value: 1.5 }]);
  const [actionType, setActionType] = useState<string>("pause");
  const [actionValue, setActionValue] = useState<number>(10);
  const [frequency, setFrequency] = useState("1h");
  const [windowVal, setWindowVal] = useState("1d");
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  function addCondition() {
    setConditions([...conditions, { metric: "spend", op: "gt", value: 50 }]);
  }
  function removeCondition(i: number) {
    setConditions(conditions.filter((_, k) => k !== i));
  }
  function updateCondition(i: number, patch: Partial<typeof conditions[0]>) {
    setConditions(
      conditions.map((c, k) => (k === i ? { ...c, ...patch } : c)),
    );
  }

  function save() {
    setError(null);
    startTransition(async () => {
      const r = await createRule({
        name,
        platform: "meta",
        scope: {
          applyTo,
          filter,
          nameFilter: nameFilter || undefined,
          productId: productId || undefined,
        },
        conditions: conditions.map((c) => ({
          metric: c.metric,
          op: c.op,
          value: Number(c.value),
        })),
        action:
          actionType === "budget_increase" || actionType === "budget_decrease"
            ? { type: actionType, value: actionValue }
            : { type: actionType },
        frequency,
        window: windowVal,
      });
      if (r.ok) onSaved();
      else setError(r.error || "Erro ao criar.");
    });
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center bg-black/80 p-4 overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="my-6 w-full max-w-xl rounded-2xl border border-white/[0.08] bg-zinc-950"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-white/[0.06] px-5 py-4">
          <h3 className="text-base font-semibold text-white">
            Criar regra personalizada
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="text-zinc-500 hover:text-white"
          >
            <X className="size-4" />
          </button>
        </div>
        <div className="px-5 py-5 space-y-5 max-h-[70vh] overflow-y-auto">
          <div>
            <label className="text-xs text-zinc-400 block mb-1">Nome da regra</label>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex: Pausa ROAS abaixo de 1.5"
              className="w-full rounded-lg border border-white/[0.08] bg-white/[0.02] px-3 py-2 text-sm text-white"
            />
          </div>

          <div>
            <label className="text-xs text-zinc-400 block mb-1">Aplicar regra a</label>
            <select
              value={applyTo}
              onChange={(e) =>
                setApplyTo(e.target.value as "campaigns" | "adsets" | "ads")
              }
              className="w-full rounded-lg border border-white/[0.08] bg-white/[0.02] px-3 py-2 text-sm text-white"
            >
              <option value="campaigns">Campanhas</option>
              <option value="adsets">Conjuntos (adsets)</option>
              <option value="ads">Anúncios (ads)</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-zinc-400 block mb-1">Status</label>
              <select
                value={filter}
                onChange={(e) => setFilter(e.target.value as "active" | "all")}
                className="w-full rounded-lg border border-white/[0.08] bg-white/[0.02] px-3 py-2 text-sm text-white"
              >
                <option value="active">Apenas ativas</option>
                <option value="all">Todas</option>
              </select>
            </div>
            <div>
              <label className="text-xs text-zinc-400 block mb-1">Produto</label>
              <select
                value={productId}
                onChange={(e) => setProductId(e.target.value)}
                className="w-full rounded-lg border border-white/[0.08] bg-white/[0.02] px-3 py-2 text-sm text-white"
              >
                <option value="">Qualquer</option>
                {products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="text-xs text-zinc-400 block mb-1">
              Filtrar por nome (opcional)
            </label>
            <input
              value={nameFilter}
              onChange={(e) => setNameFilter(e.target.value)}
              placeholder='Ex: "Black"'
              className="w-full rounded-lg border border-white/[0.08] bg-white/[0.02] px-3 py-2 text-sm text-white"
            />
          </div>

          {/* Condições */}
          <div>
            <label className="text-xs text-zinc-400 block mb-2">Condições</label>
            <div className="space-y-2">
              {conditions.map((c, i) => (
                <div key={i} className="flex items-center gap-2">
                  <select
                    value={c.metric}
                    onChange={(e) => updateCondition(i, { metric: e.target.value })}
                    className="rounded-lg border border-white/[0.08] bg-white/[0.02] px-2 py-2 text-xs text-white flex-1"
                  >
                    {Object.entries(METRIC_LABEL).map(([k, v]) => (
                      <option key={k} value={k}>{v}</option>
                    ))}
                  </select>
                  <select
                    value={c.op}
                    onChange={(e) => updateCondition(i, { op: e.target.value })}
                    className="rounded-lg border border-white/[0.08] bg-white/[0.02] px-2 py-2 text-xs text-white"
                  >
                    {Object.entries(OP_LABEL).map(([k, v]) => (
                      <option key={k} value={k}>{v}</option>
                    ))}
                  </select>
                  <input
                    type="number"
                    step="0.01"
                    value={c.value}
                    onChange={(e) =>
                      updateCondition(i, { value: Number(e.target.value) })
                    }
                    className="w-24 rounded-lg border border-white/[0.08] bg-white/[0.02] px-2 py-2 text-xs text-white text-right"
                  />
                  <button
                    type="button"
                    onClick={() => removeCondition(i)}
                    className="text-zinc-500 hover:text-red-300"
                  >
                    <X className="size-3.5" />
                  </button>
                </div>
              ))}
            </div>
            <button
              type="button"
              onClick={addCondition}
              className="mt-2 inline-flex items-center gap-1 text-[11px] text-lime-300 hover:underline"
            >
              <Plus className="size-3" /> Adicionar condição (AND)
            </button>
          </div>

          {/* Ação */}
          <div>
            <label className="text-xs text-zinc-400 block mb-1">Ação</label>
            <div className="flex items-center gap-2">
              <select
                value={actionType}
                onChange={(e) => setActionType(e.target.value)}
                className="flex-1 rounded-lg border border-white/[0.08] bg-white/[0.02] px-3 py-2 text-sm text-white"
              >
                <option value="pause">Pausar</option>
                <option value="activate">Ativar</option>
                <option value="budget_increase">Aumentar orçamento (%)</option>
                <option value="budget_decrease">Diminuir orçamento (%)</option>
                <option value="notify">Apenas notificar</option>
              </select>
              {(actionType === "budget_increase" ||
                actionType === "budget_decrease") && (
                <input
                  type="number"
                  value={actionValue}
                  onChange={(e) => setActionValue(Number(e.target.value))}
                  className="w-20 rounded-lg border border-white/[0.08] bg-white/[0.02] px-3 py-2 text-sm text-white"
                />
              )}
            </div>
          </div>

          {/* Frequência + Janela */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-zinc-400 block mb-1">Frequência</label>
              <select
                value={frequency}
                onChange={(e) => setFrequency(e.target.value)}
                className="w-full rounded-lg border border-white/[0.08] bg-white/[0.02] px-3 py-2 text-sm text-white"
              >
                <option value="15m">A cada 15 minutos</option>
                <option value="1h">A cada 1 hora</option>
                <option value="6h">A cada 6 horas</option>
                <option value="24h">A cada 24 horas</option>
              </select>
            </div>
            <div>
              <label className="text-xs text-zinc-400 block mb-1">
                Janela de avaliação
              </label>
              <select
                value={windowVal}
                onChange={(e) => setWindowVal(e.target.value)}
                className="w-full rounded-lg border border-white/[0.08] bg-white/[0.02] px-3 py-2 text-sm text-white"
              >
                <option value="30m">Últimos 30 min</option>
                <option value="1h">Última 1 hora</option>
                <option value="1d">Últimas 24h</option>
                <option value="7d">Últimos 7 dias</option>
              </select>
            </div>
          </div>

          {error && (
            <p className="text-xs text-red-300">{error}</p>
          )}
        </div>

        <div className="flex items-center justify-end gap-2 border-t border-white/[0.06] px-5 py-4">
          <button
            type="button"
            onClick={onClose}
            className="rounded-full border border-white/10 px-4 py-2 text-xs text-zinc-300 hover:bg-white/[0.04]"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={save}
            disabled={isPending || !name || conditions.length === 0}
            className="inline-flex items-center gap-1.5 rounded-full bg-lime-400 px-4 py-2 text-xs font-semibold text-black hover:bg-lime-300 disabled:opacity-50"
          >
            {isPending ? <Loader2 className="size-3 animate-spin" /> : null}
            Salvar regra
          </button>
        </div>
      </div>
    </div>
  );
}

function KillButton({
  account,
}: {
  account: { id: string; accountName: string; platform: string };
}) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [msg, setMsg] = useState<string | null>(null);

  function kill() {
    if (
      !confirm(
        `Pausar TODAS as campanhas de "${account.accountName}"? (reversível na plataforma)`,
      )
    )
      return;
    setMsg(null);
    startTransition(async () => {
      const r = await killSwitchAccount(account.id);
      if (r.ok) {
        setMsg(`${r.paused} pausada(s)`);
        router.refresh();
      } else {
        setMsg(r.error);
      }
    });
  }

  return (
    <button
      type="button"
      onClick={kill}
      disabled={isPending}
      className="inline-flex items-center gap-1.5 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-1.5 text-xs font-medium text-red-300 hover:bg-red-500/20 transition disabled:opacity-50"
      title={`Pausar tudo em ${account.accountName}`}
    >
      {isPending ? (
        <Loader2 className="size-3.5 animate-spin" />
      ) : (
        <Power className="size-3.5" />
      )}
      {account.accountName}
      {msg && <span className="text-lime-300">· {msg}</span>}
    </button>
  );
}

/** 🎯 Meta de ROAS global + 🔁 auto-scale + 💸 alerta de queima. */
function AutomationPanel({
  globalTarget,
  settings,
  onSaved,
}: {
  globalTarget: number;
  settings: AdSettings;
  onSaved: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [isPending, startTransition] = useTransition();
  const [msg, setMsg] = useState<string | null>(null);

  const [target, setTarget] = useState(
    globalTarget > 0 ? String(globalTarget) : "",
  );
  const [alertsEnabled, setAlertsEnabled] = useState(settings.adAlertsEnabled);
  const [burnReais, setBurnReais] = useState(
    String((settings.adBurnAlertCents / 100).toFixed(0)),
  );
  const [scaleEnabled, setScaleEnabled] = useState(settings.autoScaleEnabled);
  const [minRoas, setMinRoas] = useState(String(settings.autoScaleMinRoas));
  const [stepPct, setStepPct] = useState(String(settings.autoScaleStepPct));
  const [maxReais, setMaxReais] = useState(
    settings.autoScaleMaxBudgetCents > 0
      ? String((settings.autoScaleMaxBudgetCents / 100).toFixed(0))
      : "",
  );

  function saveTarget() {
    const v = Number(target.trim().replace(",", "."));
    startTransition(async () => {
      await setGlobalTargetRoas(Number.isFinite(v) ? v : 0);
      setMsg("Meta global salva");
      onSaved();
    });
  }

  function saveAutomation() {
    startTransition(async () => {
      const r = await saveAdAutomationSettings({
        adAlertsEnabled: alertsEnabled,
        adBurnAlertReais: Number(burnReais.replace(",", ".")) || 0,
        autoScaleEnabled: scaleEnabled,
        autoScaleMinRoas: Number(minRoas.replace(",", ".")) || 0,
        autoScaleStepPct: Number(stepPct) || 20,
        autoScaleMaxBudgetReais: Number(maxReais.replace(",", ".")) || 0,
      });
      setMsg(r.ok ? "Automação salva" : (r as { error: string }).error);
      onSaved();
    });
  }

  return (
    <div className="rounded-xl border border-white/[0.08] bg-white/[0.02]">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center justify-between px-4 py-3 text-left"
      >
        <span className="flex items-center gap-2 text-sm font-semibold text-white">
          <Settings2 className="size-4 text-lime-400" />
          Metas & automação
        </span>
        <span className="text-xs text-zinc-500">
          {open ? "fechar" : "abrir"}
        </span>
      </button>

      {open && (
        <div className="space-y-5 border-t border-white/[0.06] p-4">
          {/* Meta global */}
          <div>
            <p className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-zinc-400">
              <Target className="size-3.5 text-lime-400" />
              Meta de ROAS global
            </p>
            <p className="mt-1 text-[11px] text-zinc-500">
              ROAS-alvo de referência das suas campanhas. Use como base pras
              regras e pra decidir o que escalar/pausar.
            </p>
            <div className="mt-2 flex items-center gap-2">
              <input
                type="text"
                inputMode="decimal"
                value={target}
                onChange={(e) => setTarget(e.target.value)}
                placeholder="ex: 1.5"
                className="w-24 rounded-md border border-white/[0.08] bg-white/[0.03] px-3 py-1.5 text-sm text-white outline-none focus:border-lime-400/50"
              />
              <span className="text-sm text-zinc-500">x</span>
              <button
                type="button"
                onClick={saveTarget}
                disabled={isPending}
                className="rounded-md bg-lime-400 px-3 py-1.5 text-xs font-semibold text-black hover:bg-lime-300 transition disabled:opacity-50"
              >
                Salvar meta
              </button>
            </div>
          </div>

          <div className="h-px bg-white/[0.06]" />

          {/* Alerta de queima */}
          <div>
            <label className="flex items-center gap-2 text-sm text-zinc-200">
              <input
                type="checkbox"
                checked={alertsEnabled}
                onChange={(e) => setAlertsEnabled(e.target.checked)}
                className="size-4 accent-lime-400"
              />
              <AlertTriangle className="size-3.5 text-amber-400" />
              Alerta de queima (push quando gastar sem vender)
            </label>
            <div className="mt-2 flex flex-wrap items-center gap-2 pl-6 text-[11px] text-zinc-500">
              Avisar quando a campanha gastar mais de
              <span className="text-zinc-400">R$</span>
              <input
                type="text"
                inputMode="decimal"
                value={burnReais}
                onChange={(e) => setBurnReais(e.target.value)}
                className="w-16 rounded-md border border-white/[0.08] bg-white/[0.03] px-2 py-1 text-center text-xs text-white outline-none focus:border-amber-400/50"
              />
              no dia sem nenhuma venda.
            </div>
          </div>

          <div className="h-px bg-white/[0.06]" />

          {/* Escalar vencedora */}
          <div>
            <label className="flex items-center gap-2 text-sm text-zinc-200">
              <input
                type="checkbox"
                checked={scaleEnabled}
                onChange={(e) => setScaleEnabled(e.target.checked)}
                className="size-4 accent-lime-400"
              />
              <Rocket className="size-3.5 text-lime-400" />
              Escalar vencedora automaticamente
            </label>
            <div className="mt-2 grid grid-cols-1 gap-2 pl-6 text-[11px] text-zinc-500 sm:grid-cols-3">
              <label className="flex items-center gap-1.5">
                ROAS ≥
                <input
                  type="text"
                  inputMode="decimal"
                  value={minRoas}
                  onChange={(e) => setMinRoas(e.target.value)}
                  className="w-14 rounded-md border border-white/[0.08] bg-white/[0.03] px-2 py-1 text-center text-xs text-white outline-none focus:border-lime-400/50"
                />
                x
              </label>
              <label className="flex items-center gap-1.5">
                sobe budget
                <input
                  type="text"
                  inputMode="numeric"
                  value={stepPct}
                  onChange={(e) => setStepPct(e.target.value)}
                  className="w-14 rounded-md border border-white/[0.08] bg-white/[0.03] px-2 py-1 text-center text-xs text-white outline-none focus:border-lime-400/50"
                />
                %
              </label>
              <label className="flex items-center gap-1.5">
                teto R$
                <input
                  type="text"
                  inputMode="decimal"
                  value={maxReais}
                  onChange={(e) => setMaxReais(e.target.value)}
                  placeholder="∞"
                  className="w-16 rounded-md border border-white/[0.08] bg-white/[0.03] px-2 py-1 text-center text-xs text-white outline-none focus:border-lime-400/50"
                />
              </label>
            </div>
            <p className="mt-1.5 pl-6 text-[10px] text-zinc-600">
              Roda a cada 30min. Sobe no máximo 1x por dia por campanha. Só age
              em campanhas ativas com budget diário definido.
            </p>
          </div>

          <div className="flex items-center gap-3 pt-1">
            <button
              type="button"
              onClick={saveAutomation}
              disabled={isPending}
              className="inline-flex items-center gap-2 rounded-md bg-lime-400 px-4 py-2 text-sm font-semibold text-black hover:bg-lime-300 transition disabled:opacity-50"
            >
              {isPending && <Loader2 className="size-4 animate-spin" />}
              Salvar automação
            </button>
            {msg && <span className="text-xs text-lime-300">{msg}</span>}
          </div>
        </div>
      )}
    </div>
  );
}
