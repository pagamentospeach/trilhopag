"use server";

import { z } from "zod";
import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/prisma";
import { requireUserId, requireSessionUserId } from "@/lib/auth-helpers";
import { runRule } from "@/lib/rule-engine";
import { setObjectStatus } from "@/lib/ad-sync";
import { assertSafeOrigin } from "@/lib/security/origin";

const ConditionSchema = z.object({
  metric: z.enum([
    "spend",
    "cpa",
    "roas",
    "roi",
    "profit",
    "margin",
    "cpc",
    "ctr",
    "impressions",
    "sales",
    "hour",
  ]),
  op: z.enum(["gt", "lt", "gte", "lte", "eq"]),
  value: z.number(),
});

const ActionSchema = z.object({
  type: z.enum(["pause", "activate", "budget_increase", "budget_decrease", "notify"]),
  value: z.number().optional(),
});

const ScopeSchema = z.object({
  productId: z.string().optional(),
  accountIds: z.array(z.string()).optional(),
  applyTo: z.enum(["campaigns", "adsets", "ads"]).default("campaigns"),
  filter: z.enum(["active", "all"]).default("active"),
  nameFilter: z.string().optional(),
});

const RuleInput = z.object({
  name: z.string().min(1).max(120),
  platform: z.string().default("meta"),
  scope: ScopeSchema,
  conditions: z.array(ConditionSchema).min(1),
  action: ActionSchema,
  frequency: z.enum(["15m", "1h", "6h", "24h"]).default("1h"),
  window: z.enum(["30m", "1h", "1d", "7d"]).default("1d"),
});

export async function createRule(payload: unknown) {
  const userId = await requireUserId();
  const parsed = RuleInput.safeParse(payload);
  if (!parsed.success) {
    return {
      ok: false as const,
      error: "Dados inválidos: " + JSON.stringify(parsed.error.flatten()),
    };
  }
  await prisma.adRule.create({
    data: {
      userId,
      name: parsed.data.name,
      platform: parsed.data.platform,
      scope: parsed.data.scope as never,
      conditions: parsed.data.conditions as never,
      action: parsed.data.action as never,
      frequency: parsed.data.frequency,
      window: parsed.data.window,
      active: true,
    },
  });
  revalidatePath("/dashboard/tracking/regras");
  return { ok: true as const };
}

export async function updateRule(ruleId: string, payload: unknown) {
  const userId = await requireUserId();
  const owned = await prisma.adRule.findFirst({
    where: { id: ruleId, userId },
    select: { id: true },
  });
  if (!owned) return { ok: false as const, error: "Regra não encontrada." };
  const parsed = RuleInput.safeParse(payload);
  if (!parsed.success) return { ok: false as const, error: "Dados inválidos." };
  await prisma.adRule.update({
    where: { id: ruleId },
    data: {
      name: parsed.data.name,
      scope: parsed.data.scope as never,
      conditions: parsed.data.conditions as never,
      action: parsed.data.action as never,
      frequency: parsed.data.frequency,
      window: parsed.data.window,
    },
  });
  revalidatePath("/dashboard/tracking/regras");
  return { ok: true as const };
}

export async function toggleRule(ruleId: string, active: boolean) {
  const userId = await requireUserId();
  const r = await prisma.adRule.findFirst({
    where: { id: ruleId, userId },
    select: { id: true },
  });
  if (!r) return { ok: false as const, error: "Não encontrada." };
  await prisma.adRule.update({ where: { id: ruleId }, data: { active } });
  revalidatePath("/dashboard/tracking/regras");
  return { ok: true as const };
}

export async function deleteRule(ruleId: string) {
  const userId = await requireUserId();
  const r = await prisma.adRule.findFirst({
    where: { id: ruleId, userId },
    select: { id: true },
  });
  if (!r) return { ok: false as const, error: "Não encontrada." };
  await prisma.adRule.delete({ where: { id: ruleId } });
  revalidatePath("/dashboard/tracking/regras");
  return { ok: true as const };
}

export async function runRuleNow(ruleId: string) {
  const userId = await requireUserId();
  const r = await prisma.adRule.findFirst({
    where: { id: ruleId, userId },
    select: { id: true },
  });
  if (!r) return { ok: false as const, error: "Não encontrada." };
  const result = await runRule(ruleId);
  revalidatePath("/dashboard/tracking/regras");
  return {
    ok: true as const,
    matchedCount: result.matchedCount,
    actionTaken: result.actionTaken,
  };
}

/** 🧪 Simula a regra (dry-run): conta quem bateria, sem aplicar nada. */
export async function simulateRuleNow(ruleId: string) {
  const userId = await requireUserId();
  const r = await prisma.adRule.findFirst({
    where: { id: ruleId, userId },
    select: { id: true },
  });
  if (!r) return { ok: false as const, error: "Não encontrada." };
  const result = await runRule(ruleId, true);
  return { ok: true as const, matchedCount: result.matchedCount };
}

/**
 * KILL SWITCH — pausa TODAS as campanhas (ativas) de uma conta de uma vez.
 * Botão de pânico do media buyer. Reversível na plataforma.
 */
export async function killSwitchAccount(
  adAccountDbId: string,
): Promise<{ ok: true; paused: number } | { ok: false; error: string }> {
  try {
    await assertSafeOrigin();
  } catch {
    return { ok: false, error: "Origem inválida" };
  }
  const userId = await requireSessionUserId();

  const acc = await prisma.adAccount.findFirst({
    where: { id: adAccountDbId, userId },
    select: { id: true },
  });
  if (!acc) return { ok: false, error: "Conta não encontrada" };

  const campaigns = await prisma.adCampaign.findMany({
    where: {
      adAccountId: acc.id,
      status: { notIn: ["PAUSED", "DISABLE", "CAMPAIGN_STATUS_DISABLE"] },
    },
    select: { externalId: true },
  });

  let paused = 0;
  for (const c of campaigns) {
    const r = await setObjectStatus(acc.id, "campaign", c.externalId, "PAUSED");
    if (r.ok) paused++;
  }

  revalidatePath("/dashboard/tracking/regras");
  revalidatePath("/dashboard/tracking/campanhas");
  return { ok: true, paused };
}

/**
 * 🎯 META DE ROAS GLOBAL — referência do seller (0 = sem meta). Usada pelas
 * regras/alertas como ROAS-alvo das campanhas.
 */
export async function setGlobalTargetRoas(
  value: number,
): Promise<{ ok: true } | { ok: false; error: string }> {
  try {
    await assertSafeOrigin();
  } catch {
    return { ok: false, error: "Origem inválida" };
  }
  const userId = await requireSessionUserId();
  const v = Number.isFinite(value) && value > 0 ? Math.min(value, 100) : 0;
  await prisma.userSettings.upsert({
    where: { userId },
    create: { userId, adTargetRoas: v },
    update: { adTargetRoas: v },
  });
  revalidatePath("/dashboard/tracking/regras");
  return { ok: true };
}

/** ⚙️ Configurações de alerta de queima + auto-scale (escalar vencedora). */
export async function saveAdAutomationSettings(input: {
  adAlertsEnabled: boolean;
  adBurnAlertReais: number;
  autoScaleEnabled: boolean;
  autoScaleMinRoas: number;
  autoScaleStepPct: number;
  autoScaleMaxBudgetReais: number;
}): Promise<{ ok: true } | { ok: false; error: string }> {
  try {
    await assertSafeOrigin();
  } catch {
    return { ok: false, error: "Origem inválida" };
  }
  const userId = await requireSessionUserId();

  const burnCents = Math.max(
    0,
    Math.round((Number(input.adBurnAlertReais) || 0) * 100),
  );
  const minRoas = Math.max(0, Math.min(Number(input.autoScaleMinRoas) || 0, 100));
  const stepPct = Math.max(
    1,
    Math.min(Math.round(Number(input.autoScaleStepPct) || 20), 500),
  );
  const maxBudgetCents = Math.max(
    0,
    Math.round((Number(input.autoScaleMaxBudgetReais) || 0) * 100),
  );

  const data = {
    adAlertsEnabled: !!input.adAlertsEnabled,
    adBurnAlertCents: burnCents,
    autoScaleEnabled: !!input.autoScaleEnabled,
    autoScaleMinRoas: minRoas,
    autoScaleStepPct: stepPct,
    autoScaleMaxBudgetCents: maxBudgetCents,
  };
  await prisma.userSettings.upsert({
    where: { userId },
    create: { userId, ...data },
    update: data,
  });
  revalidatePath("/dashboard/tracking/regras");
  return { ok: true };
}
