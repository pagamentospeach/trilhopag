import { prisma } from "@/lib/prisma";
import { requireUserId } from "@/lib/auth-helpers";
import { RulesClient } from "./client";

export default async function RegrasPage() {
  const userId = await requireUserId();
  const since30 = new Date(new Date().getTime() - 30 * 86400000);
  const [rules, adAccounts, products, killAccounts, settings, ticketAgg, user] =
    await Promise.all([
      prisma.adRule.findMany({
        where: { userId },
        orderBy: { createdAt: "desc" },
        include: {
          executions: {
            orderBy: { ranAt: "desc" },
            take: 8,
          },
        },
      }),
      prisma.adAccount.findMany({
        where: { userId, status: "active" },
        select: { id: true, accountName: true, platform: true },
      }),
      prisma.product.findMany({
        where: { userId },
        select: { id: true, name: true },
        orderBy: { name: "asc" },
      }),
      // Contas pro kill switch — só Meta/TikTok habilitadas.
      prisma.adAccount.findMany({
        where: { userId, platform: { in: ["meta", "tiktok"] }, enabled: true },
        select: { id: true, accountName: true, platform: true },
        orderBy: { accountName: "asc" },
      }),
      prisma.userSettings.findUnique({
        where: { userId },
        select: {
          adTargetRoas: true,
          adAlertsEnabled: true,
          adBurnAlertCents: true,
          autoScaleEnabled: true,
          autoScaleMinRoas: true,
          autoScaleStepPct: true,
          autoScaleMaxBudgetCents: true,
        },
      }),
      // Ticket médio real (30d) pra pré-preencher o break-even.
      prisma.transaction.aggregate({
        where: { userId, status: "PAID", paidAt: { gte: since30 } },
        _avg: { amountCents: true },
      }),
      prisma.user.findUnique({
        where: { id: userId },
        select: { feePercent: true },
      }),
    ]);

  const avgTicketReais = Math.round((ticketAgg._avg.amountCents ?? 0)) / 100;
  const feePercent = user?.feePercent ?? 0;

  return (
    <RulesClient
      rules={rules.map((r) => ({
        id: r.id,
        name: r.name,
        platform: r.platform,
        scope: r.scope as unknown as Record<string, unknown>,
        conditions: r.conditions as unknown as Array<Record<string, unknown>>,
        action: r.action as unknown as Record<string, unknown>,
        frequency: r.frequency,
        window: r.window,
        active: r.active,
        lastRunAt: r.lastRunAt?.toISOString() ?? null,
        lastExecution: r.executions[0]
          ? {
              ranAt: r.executions[0].ranAt.toISOString(),
              matchedCount: r.executions[0].matchedCount,
              actionTaken: r.executions[0].actionTaken,
            }
          : null,
        executions: r.executions.map((e) => ({
          ranAt: e.ranAt.toISOString(),
          matchedCount: e.matchedCount,
          actionTaken: e.actionTaken,
        })),
      }))}
      adAccounts={adAccounts}
      products={products}
      killAccounts={killAccounts}
      globalTarget={settings?.adTargetRoas ?? 0}
      settings={{
        adAlertsEnabled: settings?.adAlertsEnabled ?? true,
        adBurnAlertCents: settings?.adBurnAlertCents ?? 5000,
        autoScaleEnabled: settings?.autoScaleEnabled ?? false,
        autoScaleMinRoas: settings?.autoScaleMinRoas ?? 2,
        autoScaleStepPct: settings?.autoScaleStepPct ?? 20,
        autoScaleMaxBudgetCents: settings?.autoScaleMaxBudgetCents ?? 0,
      }}
      avgTicketReais={avgTicketReais}
      feePercent={feePercent}
    />
  );
}
