"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Plug, Megaphone, Bot, GraduationCap, Rocket, ShieldAlert, Stethoscope } from "lucide-react";
import { cn } from "@/lib/utils";

type TabDef = {
  key: string;
  label: string;
  href: string;
  Icon: typeof Plug;
  exact?: boolean;
  soon?: boolean;
};

const TABS: TabDef[] = [
  { key: "integracoes", label: "Integrações", href: "/dashboard/tracking", Icon: Plug, exact: true },
  { key: "campanhas", label: "Campanhas", href: "/dashboard/tracking/campanhas", Icon: Megaphone },
  {
    key: "massa",
    label: "Subir Campanhas em Massa",
    href: "/dashboard/tracking/massa",
    Icon: Rocket,
  },
  {
    key: "apelacao",
    label: "Apelação em Massa",
    href: "/dashboard/tracking/apelacao",
    Icon: ShieldAlert,
  },
  { key: "regras", label: "Regras", href: "/dashboard/tracking/regras", Icon: Bot },
  { key: "diagnostico", label: "Diagnóstico", href: "/dashboard/tracking/diagnostico", Icon: Stethoscope },
  { key: "tutorial", label: "Tutorial", href: "/dashboard/tracking/tutorial", Icon: GraduationCap },
];

export function TrackingTabsNav({
  rejectedCount = 0,
}: {
  rejectedCount?: number;
}) {
  const pathname = usePathname();
  return (
    <div className="overflow-x-auto">
      <div className="flex min-w-max gap-1 border-b border-white/[0.06]">
        {TABS.map((t) => {
          const active = t.exact
            ? pathname === t.href
            : pathname === t.href || pathname.startsWith(t.href + "/");
          const Icon = t.Icon;
          const showRejectedBadge = t.key === "apelacao" && rejectedCount > 0;
          return (
            <Link
              key={t.key}
              href={t.href}
              className={cn(
                "inline-flex items-center gap-2 whitespace-nowrap border-b-2 px-4 py-3 text-sm font-medium transition",
                active
                  ? "border-lime-400 text-lime-300"
                  : "border-transparent text-zinc-400 hover:text-white",
              )}
            >
              <Icon className="size-4" />
              {t.label}
              {showRejectedBadge && (
                <span className="ml-1 rounded-full bg-amber-400 px-1.5 py-0.5 text-[9px] font-bold text-black">
                  {rejectedCount > 99 ? "99+" : rejectedCount}
                </span>
              )}
              {t.soon && (
                <span className="ml-1 rounded-full bg-yellow-400/15 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-yellow-200">
                  em breve
                </span>
              )}
            </Link>
          );
        })}
      </div>
    </div>
  );
}
