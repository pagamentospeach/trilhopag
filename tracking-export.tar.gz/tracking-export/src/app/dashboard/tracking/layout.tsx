import Link from "next/link";
import { TrendingUp } from "lucide-react";
import { getTranslations } from "next-intl/server";
import { prisma } from "@/lib/prisma";
import { requireUserId } from "@/lib/auth-helpers";
import { TrackingTabsNav } from "./tabs-nav";

export default async function TrackingLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const t = await getTranslations("tracking");
  const userId = await requireUserId();

  // Contador de anúncios reprovados → badge na aba "Apelação em Massa".
  const rejectedCount = await prisma.ad
    .count({
      where: {
        OR: [
          { secondaryStatus: { contains: "DISAPPROVE", mode: "insensitive" } },
          { secondaryStatus: { contains: "REJECT", mode: "insensitive" } },
          { secondaryStatus: { contains: "DENIED", mode: "insensitive" } },
        ],
        adset: { campaign: { adAccount: { userId } } },
      },
    })
    .catch(() => 0);
  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <header className="space-y-3">
        <div className="flex items-center gap-3">
          <span className="inline-flex size-10 items-center justify-center rounded-xl bg-lime-400/10 text-lime-400">
            <TrendingUp className="size-5" />
          </span>
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-lime-400">
              Tracking
            </p>
            <h1 className="text-2xl font-semibold tracking-tight text-white">
              {t("titulo")}
            </h1>
          </div>
        </div>
        <p className="text-sm text-zinc-400 max-w-2xl">
          {t("descricao")} <Link href="/dashboard" className="text-lime-300 hover:underline">→</Link>
        </p>
      </header>

      <TrackingTabsNav rejectedCount={rejectedCount} />

      <div className="mt-5">{children}</div>
    </div>
  );
}
