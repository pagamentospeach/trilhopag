"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import {
  Plug,
  Plus,
  RefreshCw,
  Copy,
  Check,
  Trash2,
  ExternalLink,
  Loader2,
  AlertTriangle,
  ChevronDown,
  ChevronRight,
  MoreVertical,
  Info,
} from "lucide-react";

type AdAccountLite = {
  id: string;
  accountId: string;
  accountName: string;
  status: string;
  enabled: boolean;
  lastSyncAt: string | null;
  syncError: string | null;
  pixels: Array<{ id: string; name: string }>;
};

type AdProfile = {
  externalUserId: string;
  profileName: string;
  expiresAt: string | null;
  adAccounts: AdAccountLite[];
};

type Platform = "meta" | "tiktok";

export function IntegracoesClient({
  metaProfiles,
  tiktokProfiles,
}: {
  metaProfiles: AdProfile[];
  tiktokProfiles: AdProfile[];
}) {
  const [showConnectModal, setShowConnectModal] = useState(false);
  const [showTiktokModal, setShowTiktokModal] = useState(false);

  return (
    <div className="space-y-3">
      {/* Card Meta */}
      <div className="rounded-2xl border border-white/[0.08] bg-white/[0.02] overflow-hidden">
        <div className="flex items-center justify-between border-b border-white/[0.06] px-5 py-4">
          <div className="flex items-center gap-3">
            <span className="inline-flex size-10 items-center justify-center rounded-xl bg-blue-500/20 text-blue-400">
              <svg viewBox="0 0 24 24" className="size-5 fill-current">
                <path d="M9.101 23.691v-7.98H6.627v-3.667h2.474v-1.58c0-4.085 1.848-5.978 5.858-5.978.401 0 .955.042 1.468.103a8.68 8.68 0 0 1 1.141.195v3.325a8.623 8.623 0 0 0-.653-.036 26.805 26.805 0 0 0-.733-.009c-.707 0-1.259.096-1.675.309a1.686 1.686 0 0 0-.679.622c-.258.42-.374.995-.374 1.752v1.297h3.919l-.386 2.103-.287 1.564h-3.246v8.245C19.396 23.238 24 18.179 24 12.044c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.628 3.874 10.35 9.101 11.647Z" />
              </svg>
            </span>
            <div>
              <p className="text-base font-semibold text-white">Meta Ads</p>
              <p className="text-xs text-zinc-400">
                Facebook + Instagram Ads — conecte um perfil e selecione as contas
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setShowConnectModal(true)}
            className="inline-flex items-center gap-1.5 rounded-full bg-blue-500 px-3 py-1.5 text-xs font-semibold text-white hover:bg-blue-400 transition"
          >
            <Plus className="size-3" /> Adicionar perfil
          </button>
        </div>

        {metaProfiles.length === 0 ? (
          <div className="px-5 py-10 text-center">
            <Plug className="mx-auto size-8 text-zinc-600" />
            <p className="mt-3 text-sm text-zinc-400">
              Nenhum perfil Meta conectado ainda.
            </p>
            <p className="text-xs text-zinc-500">
              Clique em <strong>Adicionar perfil</strong> pra começar.
            </p>
            <Info className="mx-auto mt-4 size-3 text-yellow-300" />
            <p className="text-[11px] text-yellow-300 max-w-md mx-auto">
              💡 Importante: abra o BravoPay no mesmo navegador onde o Facebook tá logado.
              Senão dá erro <code>invalid_state</code>.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-white/[0.04]">
            {metaProfiles.map((p) => (
              <ProfileBlock key={p.externalUserId} profile={p} platform="meta" />
            ))}
          </div>
        )}
      </div>

      {/* ============ CARD TIKTOK ============ */}
      <div className="rounded-2xl border border-white/[0.08] bg-white/[0.02] overflow-hidden">
        <div className="flex items-center justify-between border-b border-white/[0.06] px-5 py-4">
          <div className="flex items-center gap-3">
            <span className="inline-flex size-10 items-center justify-center rounded-xl bg-gradient-to-br from-pink-500/30 to-cyan-500/30 text-pink-300">
              <svg viewBox="0 0 24 24" className="size-5 fill-current">
                <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5.8 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1.84-.1Z" />
              </svg>
            </span>
            <div>
              <p className="text-base font-semibold text-white">TikTok Ads</p>
              <p className="text-xs text-zinc-400">
                Business Center — conecte e sincronize advertisers/campanhas
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setShowTiktokModal(true)}
            className="inline-flex items-center gap-1.5 rounded-full bg-gradient-to-r from-pink-500 to-cyan-500 px-3 py-1.5 text-xs font-semibold text-white hover:opacity-90 transition"
          >
            <Plus className="size-3" /> Adicionar Business Center
          </button>
        </div>

        {tiktokProfiles.length === 0 ? (
          <div className="px-5 py-10 text-center">
            <Plug className="mx-auto size-8 text-zinc-600" />
            <p className="mt-3 text-sm text-zinc-400">
              Nenhum Business Center do TikTok conectado ainda.
            </p>
            <p className="text-xs text-zinc-500">
              Clique em <strong>Adicionar Business Center</strong> pra começar.
            </p>
            <Info className="mx-auto mt-4 size-3 text-yellow-300" />
            <p className="text-[11px] text-yellow-300 max-w-md mx-auto">
              💡 Você precisa ser admin/operador do Business Center no TikTok pra autorizar.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-white/[0.04]">
            {tiktokProfiles.map((p) => (
              <ProfileBlock
                key={p.externalUserId}
                profile={p}
                platform="tiktok"
              />
            ))}
          </div>
        )}
      </div>

      {showConnectModal && (
        <ConnectMetaModal onClose={() => setShowConnectModal(false)} />
      )}
      {showTiktokModal && (
        <ConnectTiktokModal onClose={() => setShowTiktokModal(false)} />
      )}
    </div>
  );
}


/**
 * Bloco unificado de um perfil/Business Center:
 *  - Linha do topo: nome + qtd contas + sync + disconnect
 *  - Subseção colapsada (default): "Ativar todas" + lista de contas
 */
function ProfileBlock({
  profile,
  platform,
}: {
  profile: AdProfile;
  platform: Platform;
}) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [msg, setMsg] = useState<string | null>(null);
  const [expanded, setExpanded] = useState(false); // pré-recolhido

  function sync() {
    setMsg(null);
    startTransition(async () => {
      const res = await fetch(`/api/oauth/${platform}/sync`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ externalUserId: profile.externalUserId }),
      });
      const data = await res.json();
      if (data.ok) {
        const total = data.results.reduce(
          (s: number, r: { campaigns?: number }) => s + (r.campaigns ?? 0),
          0,
        );
        setMsg(`${total} campanhas sincronizadas`);
        router.refresh();
      } else {
        setMsg(`Erro: ${data.error || "desconhecido"}`);
      }
    });
  }

  function disconnect() {
    const label = platform === "tiktok" ? "Business Center" : "perfil";
    if (!confirm(`Desconectar o ${label} "${profile.profileName}" e TODAS suas contas?`))
      return;
    startTransition(async () => {
      await fetch(`/api/oauth/${platform}/disconnect`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ externalUserId: profile.externalUserId }),
      });
      router.refresh();
    });
  }

  function toggleAccount(adId: string, enabled: boolean) {
    startTransition(async () => {
      await fetch("/api/oauth/meta/account", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adAccountId: adId, enabled }),
      });
      router.refresh();
    });
  }

  return (
    <div className="px-5 py-4">
      <div
        className="flex items-center justify-between rounded-lg border border-white/[0.06] bg-white/[0.03] px-3 py-2.5 cursor-pointer hover:bg-white/[0.05] transition"
        onClick={() => setExpanded((v) => !v)}
      >
        <div className="flex items-center gap-3 min-w-0 flex-1">
          {expanded ? (
            <ChevronDown className="size-3.5 text-zinc-400 shrink-0" />
          ) : (
            <ChevronRight className="size-3.5 text-zinc-400 shrink-0" />
          )}
          <span
            className={`inline-flex size-2 rounded-full ${profile.adAccounts.length > 0 ? "bg-lime-400" : "bg-zinc-500"}`}
          />
          <p className="text-sm font-medium text-white truncate">
            {profile.profileName}
          </p>
          <p className="text-[10px] text-zinc-500">
            {profile.adAccounts.length} conta
            {profile.adAccounts.length !== 1 ? "s" : ""}
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0" onClick={(e) => e.stopPropagation()}>
          <button
            type="button"
            onClick={sync}
            disabled={isPending}
            className="rounded-md p-1.5 text-zinc-400 hover:text-lime-300 transition disabled:opacity-50"
            title="Sincronizar"
          >
            {isPending ? (
              <Loader2 className="size-3.5 animate-spin" />
            ) : (
              <RefreshCw className="size-3.5" />
            )}
          </button>
          <button
            type="button"
            onClick={disconnect}
            disabled={isPending}
            className="rounded-md p-1.5 text-zinc-400 hover:text-red-300 transition"
            title="Desconectar"
          >
            <Trash2 className="size-3.5" />
          </button>
        </div>
      </div>

      {msg && <p className="mt-2 text-[11px] text-lime-300">{msg}</p>}

      {expanded && (
        <div className="mt-3 rounded-lg border border-white/[0.04] bg-black/20 overflow-hidden">
          {/* Header: ativar todas */}
          <div className="flex items-center justify-between border-b border-white/[0.04] px-3 py-2">
            <span className="text-[11px] uppercase tracking-wider text-zinc-500">
              Contas de Anúncio
            </span>
            <DisableAllForProfile profile={profile} platform={platform} />
          </div>
          {/* Lista de contas */}
          <div className="divide-y divide-white/[0.04]">
            {profile.adAccounts.length === 0 ? (
              <div className="px-3 py-6 text-center text-xs text-zinc-500">
                Nenhuma conta de anúncio neste perfil.
              </div>
            ) : (
              profile.adAccounts.map((acc) => (
                <div
                  key={acc.id}
                  className="flex items-center justify-between gap-3 px-3 py-2.5 text-sm"
                >
                  <div className="min-w-0 flex-1">
                    <p className="text-sm text-white truncate">{acc.accountName}</p>
                    <p className="text-[10px] text-zinc-500 font-mono">
                      {acc.accountId} ·{" "}
                      {acc.enabled ? (
                        <span className="text-lime-400">Habilitada</span>
                      ) : (
                        <span className="text-zinc-500">Desabilitada</span>
                      )}
                      {acc.syncError && (
                        <span className="text-red-300 ml-2">
                          · {acc.syncError.slice(0, 60)}
                        </span>
                      )}
                    </p>
                    {/* PIXELS da conta — puxados no sync (nome + ID).
                        Usados no "Subir Campanhas em Massa". */}
                    <div className="mt-1.5">
                      <p className="text-[9px] uppercase tracking-wider text-zinc-600 mb-1">
                        Pixels {acc.pixels.length > 0 ? `(${acc.pixels.length})` : ""}
                      </p>
                      {acc.pixels.length === 0 ? (
                        <p className="text-[10px] text-zinc-600">
                          Nenhum pixel encontrado. Clique em sincronizar (
                          <RefreshCw className="inline size-2.5" />) pra puxar.
                        </p>
                      ) : (
                        <div className="flex flex-wrap gap-1">
                          {acc.pixels.map((px) => (
                            <PixelChip key={px.id} pixel={px} />
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => toggleAccount(acc.id, !acc.enabled)}
                    disabled={isPending}
                    className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors disabled:opacity-50 ${
                      acc.enabled
                        ? platform === "tiktok"
                          ? "bg-pink-500"
                          : "bg-blue-500"
                        : "bg-zinc-700"
                    }`}
                    aria-pressed={acc.enabled}
                  >
                    <span
                      className={`inline-block size-4 transform rounded-full bg-white shadow ring-0 transition ${
                        acc.enabled ? "translate-x-4" : "translate-x-0"
                      }`}
                    />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}

/** Toggle de "Ativar/Desativar todas" — escopado a UM perfil/BC. */
function DisableAllForProfile({
  profile,
  platform,
}: {
  profile: AdProfile;
  platform: Platform;
}) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const accounts = profile.adAccounts;
  const allEnabled = accounts.length > 0 && accounts.every((a) => a.enabled);

  function toggle(e: React.MouseEvent) {
    e.stopPropagation();
    if (accounts.length === 0) return;
    const newEnabled = !allEnabled;
    startTransition(async () => {
      await Promise.all(
        accounts.map((a) =>
          fetch("/api/oauth/meta/account", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ adAccountId: a.id, enabled: newEnabled }),
          }),
        ),
      );
      router.refresh();
    });
  }

  return (
    <div className="flex items-center gap-2">
      <span className="text-[10px] text-zinc-400">
        {allEnabled ? "Desativar todas" : "Ativar todas"}
      </span>
      <button
        type="button"
        onClick={toggle}
        disabled={isPending || accounts.length === 0}
        className={`relative inline-flex h-4 w-8 cursor-pointer rounded-full border-2 border-transparent transition-colors disabled:opacity-50 ${
          allEnabled
            ? platform === "tiktok"
              ? "bg-pink-500"
              : "bg-blue-500"
            : "bg-zinc-700"
        }`}
      >
        <span
          className={`inline-block size-3 transform rounded-full bg-white shadow transition ${
            allEnabled ? "translate-x-3.5" : "translate-x-0"
          }`}
        />
      </button>
    </div>
  );
}

/** Chip de pixel: mostra o nome + ID (mono). Clica → copia o ID. */
function PixelChip({ pixel }: { pixel: { id: string; name: string } }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      type="button"
      onClick={(e) => {
        e.stopPropagation();
        navigator.clipboard.writeText(pixel.id).then(() => {
          setCopied(true);
          setTimeout(() => setCopied(false), 1500);
        });
      }}
      title={`Copiar ID: ${pixel.id}`}
      className="inline-flex items-center gap-1 rounded-md border border-white/[0.08] bg-white/[0.03] px-1.5 py-0.5 text-[10px] text-zinc-300 hover:bg-white/[0.06] transition max-w-[220px]"
    >
      {copied ? (
        <Check className="size-2.5 text-lime-400 shrink-0" />
      ) : (
        <Copy className="size-2.5 text-zinc-500 shrink-0" />
      )}
      <span className="truncate font-medium">{pixel.name || "(sem nome)"}</span>
      <span className="font-mono text-zinc-500 shrink-0">{pixel.id.slice(0, 8)}…</span>
    </button>
  );
}

function ConnectMetaModal({ onClose }: { onClose: () => void }) {
  const [copied, setCopied] = useState(false);
  const [multiloginUrl, setMultiloginUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function getMultiloginUrl() {
    setLoading(true);
    try {
      const res = await fetch("/api/oauth/meta/connect?multilogin=1");
      const data = await res.json();
      if (data.ok && data.url) {
        setMultiloginUrl(data.url);
        await navigator.clipboard.writeText(data.url);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }
    } finally {
      setLoading(false);
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-2xl border border-white/[0.08] bg-zinc-950 p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <h3 className="text-base font-semibold text-white">Conectar Meta Ads</h3>
        <p className="mt-1 text-xs text-zinc-400">
          Escolha como deseja conectar sua conta Meta Ads.
        </p>

        <div className="mt-4 rounded-lg border border-yellow-400/30 bg-yellow-400/[0.04] p-3 text-[11px] text-yellow-200">
          ⚠️ <strong>Atenção:</strong> abra o BravoPay no mesmo navegador onde o
          Facebook tá logado. Se você usa Multilogin/Adspower, use o botão{" "}
          <strong>Copiar link</strong> abaixo.
        </div>

        <div className="mt-5 space-y-3">
          <a
            href="/api/oauth/meta/connect"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 rounded-lg bg-blue-500 px-4 py-3 text-sm font-semibold text-white hover:bg-blue-400 transition"
          >
            <ExternalLink className="size-4" />
            Continuar neste navegador (nova aba)
          </a>
          <p className="text-[11px] text-zinc-500 text-center">
            Conecta diretamente no navegador atual (precisa estar logado no FB
            aqui)
          </p>

          <button
            type="button"
            onClick={getMultiloginUrl}
            disabled={loading}
            className="flex w-full items-center justify-center gap-2 rounded-lg bg-zinc-800 px-4 py-3 text-sm font-medium text-white hover:bg-zinc-700 transition disabled:opacity-50"
          >
            {loading ? (
              <Loader2 className="size-4 animate-spin" />
            ) : copied ? (
              <Check className="size-4" />
            ) : (
              <Copy className="size-4" />
            )}
            {copied ? "Link copiado!" : "Copiar link para navegador multilogin"}
          </button>
          <p className="text-[11px] text-zinc-500 text-center">
            Cole em outro navegador onde o FB tá logado (Multilogin/Adspower)
          </p>

          {multiloginUrl && (
            <div className="rounded-lg border border-white/[0.06] bg-white/[0.02] p-3 text-[10px] font-mono text-zinc-400 break-all">
              {multiloginUrl}
            </div>
          )}
        </div>

        <button
          type="button"
          onClick={onClose}
          className="mt-5 w-full rounded-lg border border-white/[0.08] py-2 text-xs text-zinc-400 hover:bg-white/[0.04]"
        >
          Cancelar
        </button>
      </div>
    </div>
  );
}

function ConnectTiktokModal({ onClose }: { onClose: () => void }) {
  const [copied, setCopied] = useState(false);
  const [multiloginUrl, setMultiloginUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function getMultiloginUrl() {
    setLoading(true);
    try {
      const res = await fetch("/api/oauth/tiktok/connect?multilogin=1");
      const data = await res.json();
      if (data.ok && data.url) {
        setMultiloginUrl(data.url);
        await navigator.clipboard.writeText(data.url);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }
    } finally {
      setLoading(false);
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-2xl border border-white/[0.08] bg-zinc-950 p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <h3 className="text-base font-semibold text-white">
          Conectar TikTok Business Center
        </h3>
        <p className="mt-1 text-xs text-zinc-400">
          Autorize o BravoPay no Business Center pra sincronizar advertisers e campanhas.
        </p>

        <div className="mt-4 rounded-lg border border-yellow-400/30 bg-yellow-400/[0.04] p-3 text-[11px] text-yellow-200">
          ⚠️ <strong>Atenção:</strong> você precisa ser{" "}
          <strong>admin ou operador</strong> do Business Center que quer
          conectar. O TikTok vai listar todos os advertisers (contas de
          anúncio) ali dentro e dar o token de acesso pro BravoPay.
        </div>

        <div className="mt-5 space-y-3">
          <a
            href="/api/oauth/tiktok/connect"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-pink-500 to-cyan-500 px-4 py-3 text-sm font-semibold text-white hover:opacity-90 transition"
          >
            <ExternalLink className="size-4" />
            Continuar neste navegador (nova aba)
          </a>
          <p className="text-[11px] text-zinc-500 text-center">
            Conecta diretamente no navegador atual (você precisa estar logado
            no TikTok Business aqui)
          </p>

          <button
            type="button"
            onClick={getMultiloginUrl}
            disabled={loading}
            className="flex w-full items-center justify-center gap-2 rounded-lg bg-zinc-800 px-4 py-3 text-sm font-medium text-white hover:bg-zinc-700 transition disabled:opacity-50"
          >
            {loading ? (
              <Loader2 className="size-4 animate-spin" />
            ) : copied ? (
              <Check className="size-4" />
            ) : (
              <Copy className="size-4" />
            )}
            {copied ? "Link copiado!" : "Copiar link para navegador multilogin"}
          </button>
          <p className="text-[11px] text-zinc-500 text-center">
            Cole em outro navegador onde o TikTok Business tá logado
          </p>

          {multiloginUrl && (
            <div className="rounded-lg border border-white/[0.06] bg-white/[0.02] p-3 text-[10px] font-mono text-zinc-400 break-all">
              {multiloginUrl}
            </div>
          )}
        </div>

        <button
          type="button"
          onClick={onClose}
          className="mt-5 w-full rounded-lg border border-white/[0.08] py-2 text-xs text-zinc-400 hover:bg-white/[0.04]"
        >
          Cancelar
        </button>
      </div>
    </div>
  );
}
