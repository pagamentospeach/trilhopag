"use server";

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/prisma";
import { requireSessionUserId } from "@/lib/auth-helpers";
import { setObjectStatus, setObjectBudget } from "@/lib/ad-sync";
import { assertSafeOrigin } from "@/lib/security/origin";

/**
 * Pausa UMA campanha a partir do dashboard (card "pior campanha").
 * Verifica que a conta é do usuário antes de agir.
 */
export async function pauseAdCampaign(
  adAccountDbId: string,
  externalId: string,
): Promise<{ ok: true } | { ok: false; error: string }> {
  try {
    await assertSafeOrigin();
  } catch {
    return { ok: false, error: "Origem inválida" };
  }
  const userId = await requireSessionUserId();
  const acc = await prisma.adAccount.findFirst({
    where: { id: adAccountDbId, userId },
    select: { id: true },
  });
  if (!acc) return { ok: false, error: "Conta não encontrada" };
  const r = await setObjectStatus(acc.id, "campaign", externalId, "PAUSED");
  if (!r.ok) return { ok: false, error: r.error || "Falha ao pausar" };
  revalidatePath("/dashboard");
  revalidatePath("/dashboard/tracking/campanhas");
  return { ok: true };
}

/**
 * Escala UMA campanha a partir do dashboard (card "melhor campanha"): sobe o
 * orçamento diário em `pct`% (default 20). Usa o budget atual no banco.
 */
export async function scaleAdCampaign(
  adAccountDbId: string,
  externalId: string,
  pct = 20,
): Promise<
  { ok: true; newBudgetCents: number } | { ok: false; error: string }
> {
  try {
    await assertSafeOrigin();
  } catch {
    return { ok: false, error: "Origem inválida" };
  }
  const userId = await requireSessionUserId();
  const acc = await prisma.adAccount.findFirst({
    where: { id: adAccountDbId, userId },
    select: { id: true },
  });
  if (!acc) return { ok: false, error: "Conta não encontrada" };

  const camp = await prisma.adCampaign.findFirst({
    where: { adAccountId: acc.id, externalId },
    select: { dailyBudgetCents: true },
  });
  const cur = camp?.dailyBudgetCents ?? 0;
  if (cur <= 0) {
    return {
      ok: false,
      error: "Sem budget diário (CBO/ABO no conjunto). Ajuste em Campanhas.",
    };
  }
  const step = Number.isFinite(pct) && pct > 0 ? Math.min(pct, 500) : 20;
  const next = Math.round(cur * (1 + step / 100));
  const r = await setObjectBudget(acc.id, externalId, next);
  if (!r.ok) return { ok: false, error: r.error || "Falha ao subir budget" };
  revalidatePath("/dashboard");
  revalidatePath("/dashboard/tracking/campanhas");
  return { ok: true, newBudgetCents: next };
}
