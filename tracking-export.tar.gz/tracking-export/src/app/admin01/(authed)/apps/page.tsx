import { Plug } from "lucide-react";
import { getPlatformAppsStatus } from "@/lib/platform-apps";
import { AppsClient } from "./client";

export const dynamic = "force-dynamic";

/**
 * Admin → Apps. Conecta o app Meta/TikTok da PLATAFORMA (App ID + Secret +
 * config_id do Meta). Fica no banco — não se perde em migração de conta
 * (foi o que derrubou o connect do TikTok). Os providers leem daqui com
 * fallback pro env.
 */
export default async function AdminAppsPage() {
  const status = await getPlatformAppsStatus();

  return (
    <div className="max-w-3xl space-y-6">
      <header>
        <h1 className="flex items-center gap-2 text-2xl font-semibold text-white">
          <Plug className="size-5 text-lime-400" />
          Apps de Integração (Meta / TikTok)
        </h1>
        <p className="mt-1 text-sm text-zinc-400">
          Credenciais dos apps que os sellers usam pra conectar contas de
          anúncio no Tracking. Ficam no banco (sobrevivem a migração de conta).
          Os providers usam isto primeiro, caindo pras env vars como fallback.
        </p>
      </header>

      <AppsClient status={status} />
    </div>
  );
}
