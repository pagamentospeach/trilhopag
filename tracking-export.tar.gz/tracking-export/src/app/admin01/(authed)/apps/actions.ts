"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { requireAdmin, logAdminAction } from "@/lib/admin-auth";
import { savePlatformApp } from "@/lib/platform-apps";

/**
 * Salva as credenciais do app Meta/TikTok da plataforma (admin).
 * Substitui as env vars — fica no banco (sobrevive a migração de conta).
 * O secret é enviado vazio quando o admin não quer trocar (mantém o atual).
 */
const Input = z.object({
  platform: z.enum(["meta", "tiktok"]),
  appId: z.string().trim().min(1, "App ID obrigatório").max(200),
  appSecret: z.string().trim().max(400).optional().nullable(),
  configId: z.string().trim().max(200).optional().nullable(),
});

export async function savePlatformAppAction(
  input: z.infer<typeof Input>,
): Promise<{ ok: true } | { ok: false; error: string }> {
  const r = await requireAdmin();
  if (!r) return { ok: false, error: "Não autorizado" };

  const parsed = Input.safeParse(input);
  if (!parsed.success) {
    return {
      ok: false,
      error: parsed.error.flatten().fieldErrors.appId?.[0] ?? "Dados inválidos",
    };
  }

  try {
    await savePlatformApp(parsed.data.platform, {
      appId: parsed.data.appId,
      appSecret: parsed.data.appSecret || undefined,
      configId: parsed.data.configId ?? null,
    });
    await logAdminAction(r.admin.id, "platform_app_save", parsed.data.platform, {
      appId: parsed.data.appId,
      hasSecret: !!parsed.data.appSecret,
      configId: parsed.data.configId ?? null,
    });
    revalidatePath("/admin01/apps");
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Erro ao salvar" };
  }
}
