"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Check, Loader2, AlertTriangle, Database, KeyRound } from "lucide-react";
import { savePlatformAppAction } from "./actions";

type PlatformStatus = {
  configured: boolean;
  source: "db" | "env" | "none";
  appId: string | null;
  configId: string | null;
  hasSecret: boolean;
};

export function AppsClient({
  status,
}: {
  status: Record<"meta" | "tiktok", PlatformStatus>;
}) {
  return (
    <div className="space-y-4">
      <PlatformCard
        platform="tiktok"
        title="TikTok Ads"
        accent="from-pink-500 to-cyan-500"
        status={status.tiktok}
        showConfigId={false}
        helpUrl="https://business-api.tiktok.com/portal"
      />
      <PlatformCard
        platform="meta"
        title="Meta Ads (Facebook)"
        accent="from-blue-500 to-blue-400"
        status={status.meta}
        showConfigId
        helpUrl="https://developers.facebook.com/apps"
      />
    </div>
  );
}

function PlatformCard({
  platform,
  title,
  accent,
  status,
  showConfigId,
  helpUrl,
}: {
  platform: "meta" | "tiktok";
  title: string;
  accent: string;
  status: PlatformStatus;
  showConfigId: boolean;
  helpUrl: string;
}) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [appId, setAppId] = useState(status.appId ?? "");
  const [appSecret, setAppSecret] = useState("");
  const [configId, setConfigId] = useState(status.configId ?? "");
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  function save() {
    setMsg(null);
    startTransition(async () => {
      const r = await savePlatformAppAction({
        platform,
        appId: appId.trim(),
        appSecret: appSecret.trim() || null,
        configId: showConfigId ? configId.trim() || null : null,
      });
      if (r.ok) {
        setAppSecret("");
        setMsg({ ok: true, text: "Salvo! As novas conexões já usam essas credenciais." });
        router.refresh();
      } else {
        setMsg({ ok: false, text: r.error });
      }
    });
  }

  return (
    <div className="rounded-2xl border border-white/[0.08] bg-white/[0.02] p-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className={`size-9 rounded-xl bg-gradient-to-br ${accent}`} />
          <div>
            <p className="text-base font-semibold text-white">{title}</p>
            <p className="text-xs text-zinc-500">
              <a href={helpUrl} target="_blank" rel="noreferrer" className="underline hover:text-zinc-300">
                Painel do desenvolvedor ↗
              </a>
            </p>
          </div>
        </div>
        {/* Status */}
        {status.configured ? (
          <span className="inline-flex items-center gap-1.5 rounded-full border border-lime-400/30 bg-lime-400/10 px-2.5 py-1 text-[11px] font-medium text-lime-300">
            {status.source === "db" ? (
              <Database className="size-3" />
            ) : (
              <KeyRound className="size-3" />
            )}
            {status.source === "db" ? "Configurado (banco)" : "Via env (legacy)"}
          </span>
        ) : (
          <span className="inline-flex items-center gap-1.5 rounded-full border border-amber-400/30 bg-amber-400/10 px-2.5 py-1 text-[11px] font-medium text-amber-300">
            <AlertTriangle className="size-3" />
            Não configurado
          </span>
        )}
      </div>

      <div className="mt-4 space-y-3">
        <div>
          <label className="block text-[11px] uppercase tracking-wider text-zinc-500 mb-1">
            App ID {platform === "tiktok" ? "(client_key)" : "(client_id)"}
          </label>
          <input
            value={appId}
            onChange={(e) => setAppId(e.target.value)}
            placeholder="ex: 7644439881833250817"
            className="w-full rounded-lg border border-white/[0.08] bg-black/30 px-3 py-2 text-sm text-white font-mono placeholder:text-zinc-600 focus:border-white/20 focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-[11px] uppercase tracking-wider text-zinc-500 mb-1">
            App Secret
          </label>
          <input
            type="password"
            value={appSecret}
            onChange={(e) => setAppSecret(e.target.value)}
            placeholder={
              status.hasSecret
                ? "•••••••••• (preencha só pra trocar)"
                : "cole o app secret"
            }
            className="w-full rounded-lg border border-white/[0.08] bg-black/30 px-3 py-2 text-sm text-white font-mono placeholder:text-zinc-600 focus:border-white/20 focus:outline-none"
          />
          <p className="mt-1 text-[10px] text-zinc-600">
            Criptografado no banco. Deixe vazio pra manter o secret atual.
          </p>
        </div>

        {showConfigId && (
          <div>
            <label className="block text-[11px] uppercase tracking-wider text-zinc-500 mb-1">
              Login Config ID (Facebook Login for Business) — opcional
            </label>
            <input
              value={configId}
              onChange={(e) => setConfigId(e.target.value)}
              placeholder="config_id (deixe vazio pra usar scopes clássicos)"
              className="w-full rounded-lg border border-white/[0.08] bg-black/30 px-3 py-2 text-sm text-white font-mono placeholder:text-zinc-600 focus:border-white/20 focus:outline-none"
            />
          </div>
        )}

        {msg && (
          <p className={`text-xs ${msg.ok ? "text-lime-300" : "text-red-300"}`}>
            {msg.text}
          </p>
        )}

        <button
          type="button"
          onClick={save}
          disabled={isPending || !appId.trim()}
          className="inline-flex items-center gap-2 rounded-lg bg-white px-4 py-2 text-sm font-semibold text-black hover:bg-zinc-200 transition disabled:opacity-50"
        >
          {isPending ? (
            <Loader2 className="size-4 animate-spin" />
          ) : (
            <Check className="size-4" />
          )}
          Salvar {title}
        </button>
      </div>
    </div>
  );
}
