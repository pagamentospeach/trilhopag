import { NextResponse } from "next/server";
import { runAllActiveRules } from "@/lib/rule-engine";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

/**
 * Cron job: roda regras ativas (15min em 15min).
 * Configurado em vercel.json. Protegido por CRON_SECRET.
 */
export async function GET(request: Request) {
  // FIX F1: fail-CLOSED se CRON_SECRET sumir. Antes: `Bearer undefined`
  // batia se atacante mandasse `Authorization: Bearer undefined`.
  const cronSecret = process.env.CRON_SECRET;
  if (
    !cronSecret ||
    request.headers.get("authorization") !== `Bearer ${cronSecret}`
  ) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }
  const r = await runAllActiveRules();
  return NextResponse.json({ ok: true, ...r });
}
