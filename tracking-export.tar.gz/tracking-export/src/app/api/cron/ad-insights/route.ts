import { NextResponse } from "next/server";
import { runAllInsights } from "@/lib/ad-insights";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

/**
 * Cron: insights diários de ads (snapshot p/ gráfico + alerta de queima +
 * escalar vencedora). Roda logo após o ad-sync (que atualiza o gasto).
 * Protegido por CRON_SECRET. Fail-CLOSED se o secret sumir.
 */
export async function GET(request: Request) {
  const cronSecret = process.env.CRON_SECRET;
  if (
    !cronSecret ||
    request.headers.get("authorization") !== `Bearer ${cronSecret}`
  ) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }
  const r = await runAllInsights();
  return NextResponse.json({ ok: true, ...r });
}
