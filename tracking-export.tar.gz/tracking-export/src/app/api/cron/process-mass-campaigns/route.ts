import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { publishToAdAccount } from "@/lib/mass-campaign-publish";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

/**
 * Processa MassCampaignJobs enfileirados.
 *
 * Publica DE VERDADE na API do TikTok (Meta em breve — app em análise).
 * Tudo nasce PAUSED (operation_status: DISABLE) → nada entrega/gasta até
 * o seller ativar manualmente no TikTok.
 *
 * Fluxo:
 *  - Lê jobs status=queued (claim atômico via updateMany)
 *  - Pra cada ad account do job, chama publishToAdAccount (cadeia real
 *    campaign → adgroup → vídeo → ad)
 *  - Salva results JSON { ok, campaignId, error } por adAccount
 */
export async function GET(request: Request) {
  const cronSecret = process.env.CRON_SECRET;
  const auth = request.headers.get("authorization");
  if (!cronSecret || auth !== `Bearer ${cronSecret}`) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }

  const BATCH = 20;
  const jobs = await prisma.massCampaignJob.findMany({
    where: { status: "queued" },
    take: BATCH,
    orderBy: { createdAt: "asc" },
  });

  let processed = 0;
  for (const job of jobs) {
    try {
      // FIX F2: lock atômico via updateMany WHERE status=queued.
      // Se duas instâncias do cron rodarem em paralelo (Vercel timeout/retry),
      // só UMA consegue mover de queued → running. A outra pula com count=0.
      // Antes: `update({ id })` sem WHERE → ambas atualizavam → ambas publicavam
      // campanhas Meta/TikTok → seller dobrava o dailyBudget gasto.
      const claim = await prisma.massCampaignJob.updateMany({
        where: { id: job.id, status: "queued" },
        data: { status: "running", startedAt: new Date() },
      });
      if (claim.count === 0) {
        // Outra instância pegou esse job. Pula.
        continue;
      }

      const results: Record<string, { ok: boolean; campaignId?: string; error?: string }> = {};
      let success = 0;
      let failure = 0;

      for (const accountId of job.targetAdAccountIds) {
        // Publicação REAL na plataforma (PAUSED por padrão).
        const r = await publishToAdAccount(accountId, job.platform, job.config, {
          campaignsPerAccount: job.campaignsPerAccount,
          adsetsPerCampaign: job.adsetsPerCampaign,
          adsPerAdset: job.adsPerAdset,
        });
        results[accountId] = {
          ok: r.ok,
          campaignId: r.campaignIds?.join(",") || undefined,
          error: r.error,
        };
        if (r.ok) success++;
        else failure++;
      }

      const finalStatus =
        failure === 0 ? "completed" : success === 0 ? "failed" : "partial";

      await prisma.massCampaignJob.update({
        where: { id: job.id },
        data: {
          status: finalStatus,
          results: results as never,
          successCount: success,
          failureCount: failure,
          completedAt: new Date(),
        },
      });
      processed++;
    } catch (e) {
      console.error("[cron/mass-campaigns] job failed:", job.id, e);
      await prisma.massCampaignJob.update({
        where: { id: job.id },
        data: {
          status: "failed",
          completedAt: new Date(),
        },
      });
    }
  }

  return NextResponse.json({ ok: true, processed, total: jobs.length });
}
