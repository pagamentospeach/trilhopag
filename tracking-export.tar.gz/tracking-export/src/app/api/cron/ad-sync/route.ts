import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { syncAdAccount } from "@/lib/ad-sync";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

/**
 * Cron job: sincroniza todas ad accounts ativas (Meta + TikTok).
 * Roda a cada 30min.
 */
export async function GET(request: Request) {
  // FIX F1: fail-CLOSED se CRON_SECRET sumir.
  const cronSecret = process.env.CRON_SECRET;
  if (
    !cronSecret ||
    request.headers.get("authorization") !== `Bearer ${cronSecret}`
  ) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }
  const accounts = await prisma.adAccount.findMany({
    where: {
      status: "active",
      platform: { in: ["meta", "tiktok"] },
      enabled: true,
    },
    select: { id: true, platform: true },
  });

  // Meta: paralelo (rate limits OK). TikTok: SEQUENCIAL — o app TikTok tem
  // QPS baixo; sincronizar varias contas em paralelo estoura (code 40100)
  // e NADA puxa. Uma de cada vez + pausa mantem abaixo do limite.
  const metaAccounts = accounts.filter((a) => a.platform === "meta");
  const tiktokAccounts = accounts.filter((a) => a.platform === "tiktok");

  const metaResults = await Promise.all(
    metaAccounts.map((a) => syncAdAccount(a.id)),
  );
  const tiktokResults: Array<Awaited<ReturnType<typeof syncAdAccount>>> = [];
  for (let i = 0; i < tiktokAccounts.length; i++) {
    tiktokResults.push(await syncAdAccount(tiktokAccounts[i].id));
    if (i < tiktokAccounts.length - 1) {
      await new Promise((r) => setTimeout(r, 800));
    }
  }
  const results = [...metaResults, ...tiktokResults];
  return NextResponse.json({
    ok: true,
    count: accounts.length,
    byPlatform: {
      meta: accounts.filter((a) => a.platform === "meta").length,
      tiktok: accounts.filter((a) => a.platform === "tiktok").length,
    },
    results,
  });
}
