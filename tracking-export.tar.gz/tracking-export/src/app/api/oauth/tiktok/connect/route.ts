import { NextResponse } from "next/server";
import { randomBytes } from "node:crypto";
import { requireUserId } from "@/lib/auth-helpers";
import { tiktokOAuthUrl } from "@/lib/providers/tiktok-ads";

export const dynamic = "force-dynamic";

const COOKIE_NAME = "bp_tt_oauth_state";

/**
 * Inicia OAuth com TikTok Business.
 * GET /api/oauth/tiktok/connect → redireciona pra portal de auth do TikTok
 */
export async function GET(request: Request) {
  const userId = await requireUserId();
  const url = new URL(request.url);
  const multilogin = url.searchParams.get("multilogin") === "1";

  const state = randomBytes(16).toString("hex");
  const cookieValue = `${userId}:${state}`;

  // Blindagem: se o app TikTok não estiver configurado (DB nem env), NÃO
  // 500 — retorna erro legível (igual ao Google connect).
  let oauthUrl: string;
  try {
    oauthUrl = await tiktokOAuthUrl(state);
  } catch (e) {
    const msg =
      e instanceof Error ? e.message : "App TikTok não configurado";
    if (multilogin) {
      return NextResponse.json({ ok: false, error: msg }, { status: 503 });
    }
    return NextResponse.redirect(
      new URL(`/dashboard/tracking?error=${encodeURIComponent(msg)}`, request.url),
    );
  }

  console.log("[tiktok/connect]", { userId, state, multilogin });

  const cookieOpts = {
    httpOnly: true,
    // Lax: callback do TikTok é top-level GET → Lax envia o cookie.
    // None expunha o state a cross-site (connection-CSRF).
    sameSite: "lax" as const,
    secure: true,
    maxAge: 600,
    path: "/",
  };

  if (multilogin) {
    const response = NextResponse.json({ ok: true, url: oauthUrl });
    response.cookies.set(COOKIE_NAME, cookieValue, cookieOpts);
    return response;
  }

  const response = NextResponse.redirect(oauthUrl);
  response.cookies.set(COOKIE_NAME, cookieValue, cookieOpts);
  return response;
}
