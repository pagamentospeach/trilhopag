import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireUserId } from "@/lib/auth-helpers";
import { syncAdAccount } from "@/lib/ad-sync";

export const dynamic = "force-dynamic";
// Sync sequencial + retry de QPS pode levar mais que 60s com muitas contas.
export const maxDuration = 120;

const Body = z.object({
  accountId: z.string().optional(),
  externalUserId: z.string().optional(),
});

export async function POST(request: Request) {
  const userId = await requireUserId();
  const raw = await request.json().catch(() => ({}));
  const parsed = Body.safeParse(raw);
  if (!parsed.success)
    return NextResponse.json({ error: "validation" }, { status: 422 });

  const accounts = await prisma.adAccount.findMany({
    where: {
      userId,
      platform: "tiktok",
      status: "active",
      enabled: true,
      ...(parsed.data.accountId ? { id: parsed.data.accountId } : {}),
      ...(parsed.data.externalUserId
        ? { externalUserId: parsed.data.externalUserId }
        : {}),
    },
  });

  // SEQUENCIAL (NAO Promise.all): o TikTok tem QPS baixo no app. Sincronizar
  // varias contas em paralelo estoura o limite (code 40100) e NADA puxa.
  // Uma de cada vez + pausa entre elas mantem abaixo do QPS.
  const results: Array<Awaited<ReturnType<typeof syncAdAccount>>> = [];
  for (let i = 0; i < accounts.length; i++) {
    results.push(await syncAdAccount(accounts[i].id));
    if (i < accounts.length - 1) {
      await new Promise((r) => setTimeout(r, 1200));
    }
  }
  return NextResponse.json({
    ok: true,
    accounts: accounts.length,
    results: results.map((r, i) => ({
      accountId: accounts[i].id,
      ...r,
    })),
  });
}
