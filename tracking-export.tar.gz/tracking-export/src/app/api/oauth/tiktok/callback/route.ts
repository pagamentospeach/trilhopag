import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { prisma } from "@/lib/prisma";
import { encryptString } from "@/lib/crypto";
import {
  exchangeCodeForToken,
  listAdvertisers,
} from "@/lib/providers/tiktok-ads";
import { syncAdAccount } from "@/lib/ad-sync";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const COOKIE_NAME = "bp_tt_oauth_state";

export async function GET(request: Request) {
  const url = new URL(request.url);
  // TikTok manda auth_code (não code) + state
  const code = url.searchParams.get("auth_code") || url.searchParams.get("code");
  const state = url.searchParams.get("state");
  const error =
    url.searchParams.get("error") ||
    url.searchParams.get("error_description");

  const appUrl =
    process.env.NEXT_PUBLIC_APP_URL ?? "https://bravopay.club";

  console.log("[tiktok/callback] start", {
    hasCode: !!code,
    hasState: !!state,
    error,
  });

  if (error) {
    return NextResponse.redirect(
      `${appUrl}/dashboard/tracking?error=${encodeURIComponent(error)}`,
    );
  }
  if (!code || !state) {
    return NextResponse.redirect(
      `${appUrl}/dashboard/tracking?error=missing_code`,
    );
  }

  const cookieStore = await cookies();
  const stateCookie = cookieStore.get(COOKIE_NAME);
  if (!stateCookie?.value) {
    return NextResponse.redirect(
      `${appUrl}/dashboard/tracking?error=invalid_state_tiktok`,
    );
  }
  const [userId, savedState] = stateCookie.value.split(":");
  if (savedState !== state) {
    return NextResponse.redirect(
      `${appUrl}/dashboard/tracking?error=state_mismatch_tiktok`,
    );
  }

  try {
    // 1. auth_code → access_token + lista de advertiser IDs
    const { accessToken, advertiserIds } = await exchangeCodeForToken(code);
    console.log("[tiktok/callback] got token, advertisers:", advertiserIds.length);

    if (advertiserIds.length === 0) {
      return NextResponse.redirect(
        `${appUrl}/dashboard/tracking?error=no_advertisers_tiktok`,
      );
    }

    // 2. Busca detalhes dos advertisers
    const advertisers = await listAdvertisers(accessToken, advertiserIds);

    const encryptedToken = encryptString(accessToken);

    // 3. Cria 1 AdAccount pra cada advertiser. externalUserId = primeiro
    //    advertiser ID (TikTok não tem conceito de "user FB" — o BC center
    //    inteiro é amarrado ao token).
    const businessCenterId = advertiserIds[0];

    const createdAccountIds: string[] = [];
    for (const adv of advertisers) {
      // TikTok renomeou `advertiser_name` → `name` em 2026. Lê `name`
      // primeiro (novo) com fallback pra `advertiser_name` (retrocompat).
      const advName = adv.name || adv.advertiser_name || adv.advertiser_id;
      const displayName = adv.company
        ? `${adv.company} — ${advName}`
        : advName;
      const upserted = await prisma.adAccount.upsert({
        where: {
          userId_platform_accountId: {
            userId,
            platform: "tiktok",
            accountId: adv.advertiser_id,
          },
        },
        create: {
          userId,
          platform: "tiktok",
          externalUserId: businessCenterId,
          accountId: adv.advertiser_id,
          accountName: displayName,
          accessToken: encryptedToken,
          scope: "ads_read,ads_management",
          status: "active",
        },
        update: {
          accessToken: encryptedToken,
          status: "active",
          accountName: displayName,
          externalUserId: businessCenterId,
        },
      });
      createdAccountIds.push(upserted.id);
    }

    // Auto-sync APÓS o OAuth — aguarda (com timeout) pra que o seller já
    // veja campanhas/adgroups na aba /tracking/campanhas sem precisar
    // clicar em "Sincronizar". Em serverless não dá pra "fire-and-forget"
    // confiavelmente porque a função termina quando o response é enviado.
    //
    // Timeout: 40s total (50s max do route, 10s reservados pra outras
    // operações). Se passar, redireciona mesmo assim e o user pode
    // sincronizar manualmente depois.
    console.log("[tiktok/callback] starting auto-sync of", createdAccountIds.length, "accounts");
    try {
      await Promise.race([
        Promise.allSettled(createdAccountIds.map((id) => syncAdAccount(id))),
        new Promise((resolve) => setTimeout(resolve, 40_000)),
      ]);
      console.log("[tiktok/callback] auto-sync finished");
    } catch (syncErr) {
      console.error("[tiktok/callback] auto-sync error:", syncErr);
    }

    const success = NextResponse.redirect(
      `${appUrl}/dashboard/tracking?connected=tiktok&count=${advertisers.length}`,
    );
    success.cookies.set(COOKIE_NAME, "", { maxAge: 0, path: "/" });
    return success;
  } catch (e) {
    console.error("[tiktok/callback]", e);
    const msg = e instanceof Error ? e.message : "unknown";
    const errResp = NextResponse.redirect(
      `${appUrl}/dashboard/tracking?error=${encodeURIComponent(msg)}`,
    );
    errResp.cookies.set(COOKIE_NAME, "", { maxAge: 0, path: "/" });
    return errResp;
  }
}
