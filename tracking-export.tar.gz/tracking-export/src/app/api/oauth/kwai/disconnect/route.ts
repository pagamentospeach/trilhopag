import { NextResponse } from "next/server";
import { requireUserId } from "@/lib/auth-helpers";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const userId = await requireUserId();
  const body = await request.json().catch(() => ({}));
  const accountId = String(body?.accountId ?? "").trim();
  if (!accountId) {
    return NextResponse.json({ error: "missing_accountId" }, { status: 400 });
  }
  await prisma.adAccount.deleteMany({
    where: { userId, platform: "kwai", accountId },
  });
  return NextResponse.json({ ok: true });
}
