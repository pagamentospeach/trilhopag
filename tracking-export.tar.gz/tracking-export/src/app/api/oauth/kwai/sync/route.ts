import { NextResponse } from "next/server";
import { requireUserId } from "@/lib/auth-helpers";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function POST() {
  const userId = await requireUserId();
  await prisma.adAccount.updateMany({
    where: { userId, platform: "kwai" },
    data: { lastSyncAt: new Date(), syncError: null },
  });
  return NextResponse.json({ ok: true });
}
