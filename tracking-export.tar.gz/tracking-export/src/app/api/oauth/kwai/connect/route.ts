import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUserId } from "@/lib/auth-helpers";
import { prisma } from "@/lib/prisma";
import { encryptString } from "@/lib/crypto";

export const dynamic = "force-dynamic";

/**
 * Kwai Ads NÃO tem OAuth público pra desenvolvedores. A conexão é feita
 * via credenciais geradas no Kwai Business Manager → o seller cola elas
 * aqui → salvamos cifrado pra usar em conversões server-side.
 *
 * Aceita 3 campos:
 *  - accessToken (obrigatório): Bearer token da Marketing API
 *  - pixelId (opcional): pra disparar Conversion API
 *  - accountName (opcional): label custom — senão usa "Conta Kwai <pixelId|hash>"
 *
 * Sem validação online — endpoints da Kwai API são instáveis e/ou exigem
 * IP allowlist. Se o token for inválido, o erro aparece no momento do
 * disparo de evento (logs do tracking-dispatcher).
 */
const Body = z.object({
  accessToken: z.string().trim().min(10).max(500),
  pixelId: z.string().trim().max(120).optional(),
  accountName: z.string().trim().max(120).optional(),
});

function maskToken(s: string, keep = 6): string {
  return s.length > keep * 2 ? `${s.slice(0, keep)}…${s.slice(-keep)}` : s;
}

export async function POST(request: Request) {
  const userId = await requireUserId();
  const raw = await request.json().catch(() => null);
  const parsed = Body.safeParse(raw);
  if (!parsed.success) {
    return NextResponse.json(
      {
        error: "validation",
        message: "Access token obrigatório (mín. 10 caracteres)",
      },
      { status: 422 },
    );
  }
  const { accessToken, pixelId, accountName } = parsed.data;

  // Account ID interno = pixelId (se passou) OU hash do token (estável)
  const accountId =
    pixelId?.trim() ||
    `kwai-${maskToken(accessToken).replace(/[^a-z0-9]/gi, "")}`;
  const finalName =
    accountName?.trim() ||
    (pixelId ? `Conta Kwai (pixel ${pixelId})` : `Conta Kwai (${maskToken(accessToken, 4)})`);

  await prisma.adAccount.upsert({
    where: {
      userId_platform_accountId: {
        userId,
        platform: "kwai",
        accountId,
      },
    },
    create: {
      userId,
      platform: "kwai",
      externalUserId: accountId,
      accountId,
      accountName: finalName,
      accessToken: encryptString(accessToken),
      scope: pixelId ? `pixel:${pixelId}` : "marketing_api",
      status: "active",
    },
    update: {
      accessToken: encryptString(accessToken),
      accountName: finalName,
      scope: pixelId ? `pixel:${pixelId}` : "marketing_api",
      status: "active",
    },
  });

  return NextResponse.json({
    ok: true,
    account: { id: accountId, name: finalName, pixelId: pixelId ?? null },
  });
}
