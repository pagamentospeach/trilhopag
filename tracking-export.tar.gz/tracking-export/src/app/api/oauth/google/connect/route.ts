import { NextResponse } from "next/server";
import { randomBytes } from "node:crypto";
import { requireUserId } from "@/lib/auth-helpers";
import { googleAdsOAuthUrl } from "@/lib/providers/google-ads";

export const dynamic = "force-dynamic";

const COOKIE_NAME = "bp_g_oauth_state";

/**
 * Inicia OAuth com Google Ads.
 * GET /api/oauth/google/connect → redireciona pra accounts.google.com
 */
export async function GET(request: Request) {
  const userId = await requireUserId();
  const url = new URL(request.url);
  const multilogin = url.searchParams.get("multilogin") === "1";

  const state = randomBytes(16).toString("hex");
  const cookieValue = `${userId}:${state}`;

  try {
    const oauthUrl = googleAdsOAuthUrl(state);
    const cookieOpts = {
      httpOnly: true,
      // Lax: callback é top-level GET → Lax envia o cookie. None expunha
      // o state cookie a cross-site (connection-CSRF).
      sameSite: "lax" as const,
      secure: true,
      maxAge: 600,
      path: "/",
    };

    if (multilogin) {
      const response = NextResponse.json({ ok: true, url: oauthUrl });
      response.cookies.set(COOKIE_NAME, cookieValue, cookieOpts);
      return response;
    }

    const response = NextResponse.redirect(oauthUrl);
    response.cookies.set(COOKIE_NAME, cookieValue, cookieOpts);
    return response;
  } catch (err) {
    // Env var não configurada — instruir o admin
    const msg = err instanceof Error ? err.message : "config error";
    return NextResponse.json(
      {
        error: "google_not_configured",
        message: msg,
        howTo:
          "Admin precisa configurar GOOGLE_OAUTH_CLIENT_ID, GOOGLE_OAUTH_CLIENT_SECRET e GOOGLE_ADS_DEVELOPER_TOKEN no Vercel.",
      },
      { status: 503 },
    );
  }
}
