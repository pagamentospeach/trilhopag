import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { prisma } from "@/lib/prisma";
import { encryptString } from "@/lib/crypto";
import {
  exchangeGoogleCode,
  listAccessibleCustomers,
  getCustomerInfo,
} from "@/lib/providers/google-ads";

export const dynamic = "force-dynamic";

const COOKIE_NAME = "bp_g_oauth_state";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  const error = url.searchParams.get("error");

  const appUrl =
    process.env.NEXT_PUBLIC_APP_URL ?? "https://bravopay.club";

  if (error) {
    return NextResponse.redirect(
      `${appUrl}/dashboard/tracking?error=${encodeURIComponent(error)}`,
    );
  }
  if (!code || !state) {
    return NextResponse.redirect(`${appUrl}/dashboard/tracking?error=missing_code`);
  }

  const cookieStore = await cookies();
  const stateCookie = cookieStore.get(COOKIE_NAME);
  if (!stateCookie?.value) {
    return NextResponse.redirect(`${appUrl}/dashboard/tracking?error=invalid_state_google`);
  }
  const [userId, savedState] = stateCookie.value.split(":");
  if (savedState !== state) {
    return NextResponse.redirect(`${appUrl}/dashboard/tracking?error=state_mismatch_google`);
  }

  try {
    // Troca code por tokens
    const tokens = await exchangeGoogleCode(code);
    if (!tokens.refresh_token) {
      return NextResponse.redirect(
        `${appUrl}/dashboard/tracking?error=no_refresh_token_google`,
      );
    }

    // Lista contas Google Ads acessíveis
    const list = await listAccessibleCustomers(tokens.access_token);
    if (!list.resourceNames?.length) {
      return NextResponse.redirect(
        `${appUrl}/dashboard/tracking?error=no_accounts_google`,
      );
    }

    const encryptedRefreshToken = encryptString(tokens.refresh_token);

    // Pra cada customer, pega info + cria AdAccount
    for (const resource of list.resourceNames) {
      const customerId = resource.replace("customers/", "");
      try {
        const info = await getCustomerInfo(tokens.access_token, customerId);
        await prisma.adAccount.upsert({
          where: {
            userId_platform_accountId: {
              userId,
              platform: "google",
              accountId: customerId,
            },
          },
          create: {
            userId,
            platform: "google",
            externalUserId: customerId,
            accountId: customerId,
            accountName: info.descriptiveName,
            accessToken: encryptedRefreshToken, // armazenamos o refresh_token
            scope: "adwords",
            status: "active",
          },
          update: {
            accessToken: encryptedRefreshToken,
            accountName: info.descriptiveName,
            status: "active",
          },
        });
      } catch (e) {
        console.error(`[google/callback] erro customer ${customerId}:`, e);
        // continua pra próximos
      }
    }

    // Limpa cookie
    cookieStore.delete(COOKIE_NAME);

    return NextResponse.redirect(
      `${appUrl}/dashboard/tracking?connected=google`,
    );
  } catch (err) {
    console.error("[google/callback] erro:", err);
    return NextResponse.redirect(
      `${appUrl}/dashboard/tracking?error=${encodeURIComponent(
        err instanceof Error ? err.message.slice(0, 100) : "callback_error",
      )}`,
    );
  }
}
