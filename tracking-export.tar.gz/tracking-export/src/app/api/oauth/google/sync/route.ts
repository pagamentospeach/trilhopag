import { NextResponse } from "next/server";
import { requireUserId } from "@/lib/auth-helpers";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/**
 * Sync de campanhas/contas Google Ads.
 *
 * Por enquanto: apenas marca lastSyncAt. Sync real de campanhas/insights
 * será implementado quando integrarmos a Google Ads API completa
 * (precisa de `googleads-api` lib ou chamadas REST manuais — complexo).
 */
export async function POST() {
  const userId = await requireUserId();
  await prisma.adAccount.updateMany({
    where: { userId, platform: "google" },
    data: { lastSyncAt: new Date(), syncError: null },
  });
  return NextResponse.json({ ok: true, message: "Sync registrado (impl. completa em breve)" });
}
