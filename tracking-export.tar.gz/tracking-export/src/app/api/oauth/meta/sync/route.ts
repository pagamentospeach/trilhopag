import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireUserId } from "@/lib/auth-helpers";
import { syncAdAccount } from "@/lib/ad-sync";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const Body = z.object({
  accountId: z.string().optional(),
  externalUserId: z.string().optional(),
});

export async function POST(request: Request) {
  const userId = await requireUserId();
  const raw = await request.json().catch(() => ({}));
  const parsed = Body.safeParse(raw);
  if (!parsed.success)
    return NextResponse.json({ error: "validation" }, { status: 422 });

  const accounts = await prisma.adAccount.findMany({
    where: {
      userId,
      platform: "meta",
      status: "active",
      enabled: true,
      ...(parsed.data.accountId ? { id: parsed.data.accountId } : {}),
      ...(parsed.data.externalUserId
        ? { externalUserId: parsed.data.externalUserId }
        : {}),
    },
  });

  const results = await Promise.all(accounts.map((a) => syncAdAccount(a.id)));
  return NextResponse.json({
    ok: true,
    accounts: accounts.length,
    results: results.map((r, i) => ({
      accountId: accounts[i].id,
      ...r,
    })),
  });
}
