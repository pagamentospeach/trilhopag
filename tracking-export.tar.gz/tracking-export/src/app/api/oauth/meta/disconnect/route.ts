import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireUserId } from "@/lib/auth-helpers";

export const dynamic = "force-dynamic";

const Body = z.object({
  accountId: z.string().optional(),
  externalUserId: z.string().optional(),
  all: z.boolean().optional(),
});

export async function POST(request: Request) {
  const userId = await requireUserId();
  const raw = await request.json().catch(() => null);
  const parsed = Body.safeParse(raw);
  if (!parsed.success)
    return NextResponse.json({ error: "validation" }, { status: 422 });

  // Desconectar TODAS as contas Meta
  if (parsed.data.all || parsed.data.accountId === "*") {
    await prisma.adAccount.deleteMany({
      where: { userId, platform: "meta" },
    });
    return NextResponse.json({ ok: true, all: true });
  }

  // Desconectar todas as contas de um PERFIL FB específico
  if (parsed.data.externalUserId) {
    const r = await prisma.adAccount.deleteMany({
      where: {
        userId,
        platform: "meta",
        externalUserId: parsed.data.externalUserId,
      },
    });
    return NextResponse.json({ ok: true, deleted: r.count });
  }

  if (!parsed.data.accountId)
    return NextResponse.json({ error: "missing_account" }, { status: 422 });

  const acc = await prisma.adAccount.findFirst({
    where: { id: parsed.data.accountId, userId },
    select: { id: true },
  });
  if (!acc) return NextResponse.json({ error: "not_found" }, { status: 404 });

  await prisma.adAccount.delete({ where: { id: acc.id } });
  return NextResponse.json({ ok: true });
}
