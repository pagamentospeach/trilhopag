import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireUserId } from "@/lib/auth-helpers";

export const dynamic = "force-dynamic";

const Body = z.object({
  adAccountId: z.string().min(1),
  enabled: z.boolean(),
});

/** Habilita/desabilita uma ad account (toggle). */
export async function POST(request: Request) {
  const userId = await requireUserId();
  const raw = await request.json().catch(() => null);
  const parsed = Body.safeParse(raw);
  if (!parsed.success)
    return NextResponse.json({ error: "validation" }, { status: 422 });

  const acc = await prisma.adAccount.findFirst({
    where: { id: parsed.data.adAccountId, userId },
    select: { id: true },
  });
  if (!acc) return NextResponse.json({ error: "not_found" }, { status: 404 });

  await prisma.adAccount.update({
    where: { id: acc.id },
    data: { enabled: parsed.data.enabled },
  });
  return NextResponse.json({ ok: true });
}
