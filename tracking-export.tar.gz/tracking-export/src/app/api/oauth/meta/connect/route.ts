import { NextResponse } from "next/server";
import { randomBytes } from "node:crypto";
import { requireUserId } from "@/lib/auth-helpers";
import { metaOAuthUrl } from "@/lib/providers/meta-ads";

export const dynamic = "force-dynamic";

const COOKIE_NAME = "bp_oauth_state";

/**
 * Inicia OAuth com Meta.
 * GET /api/oauth/meta/connect → redireciona pra dialog do Facebook
 */
export async function GET(request: Request) {
  const userId = await requireUserId();
  const url = new URL(request.url);
  const multilogin = url.searchParams.get("multilogin") === "1";

  const state = randomBytes(16).toString("hex");
  const cookieValue = `${userId}:${state}`;

  // Blindagem: app Meta não configurado → erro legível, não 500.
  let oauthUrl: string;
  try {
    oauthUrl = await metaOAuthUrl(state);
  } catch (e) {
    const msg = e instanceof Error ? e.message : "App Meta não configurado";
    if (multilogin) {
      return NextResponse.json({ ok: false, error: msg }, { status: 503 });
    }
    return NextResponse.redirect(
      new URL(`/dashboard/tracking?error=${encodeURIComponent(msg)}`, request.url),
    );
  }

  console.log("[meta/connect]", {
    userId,
    state,
    cookieName: COOKIE_NAME,
    multilogin,
  });

  const cookieOpts = {
    httpOnly: true,
    // Lax: o callback do FB é navegação top-level GET → Lax JÁ envia o cookie.
    // None expunha o state cookie a TODA requisição cross-site (connection-CSRF).
    sameSite: "lax" as const,
    secure: true,
    maxAge: 600,
    path: "/",
  };

  if (multilogin) {
    const response = NextResponse.json({ ok: true, url: oauthUrl });
    response.cookies.set(COOKIE_NAME, cookieValue, cookieOpts);
    return response;
  }

  const response = NextResponse.redirect(oauthUrl);
  response.cookies.set(COOKIE_NAME, cookieValue, cookieOpts);
  return response;
}
