import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { prisma } from "@/lib/prisma";
import { encryptString } from "@/lib/crypto";
import {
  exchangeCodeForToken,
  exchangeForLongLivedToken,
  listAdAccounts,
  getMe,
} from "@/lib/providers/meta-ads";

export const dynamic = "force-dynamic";

const COOKIE_NAME = "bp_oauth_state";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  const error = url.searchParams.get("error");

  const appUrl =
    process.env.NEXT_PUBLIC_APP_URL ?? "https://bravopay.club";

  console.log("[meta/callback] start", { hasCode: !!code, hasState: !!state, error });

  if (error) {
    return NextResponse.redirect(
      `${appUrl}/dashboard/tracking?error=${encodeURIComponent(error)}`,
    );
  }
  if (!code || !state) {
    return NextResponse.redirect(
      `${appUrl}/dashboard/tracking?error=missing_code`,
    );
  }

  // Lê todos os cookies pra debug
  const cookieStore = await cookies();
  const allCookieNames = cookieStore
    .getAll()
    .map((c) => c.name)
    .filter((n) => !n.startsWith("bravopay") && !n.startsWith("bp_vid"));
  console.log("[meta/callback] cookies vistos:", allCookieNames);

  // Valida CSRF state
  const stateCookie = cookieStore.get(COOKIE_NAME);
  if (!stateCookie?.value) {
    console.error("[meta/callback] cookie bp_oauth_state ausente. Cookies:", allCookieNames);
    return NextResponse.redirect(
      `${appUrl}/dashboard/tracking?error=invalid_state&seen=${encodeURIComponent(allCookieNames.join(","))}`,
    );
  }
  const [userId, savedState] = stateCookie.value.split(":");
  if (savedState !== state) {
    console.error("[meta/callback] state mismatch", { savedState, state });
    return NextResponse.redirect(
      `${appUrl}/dashboard/tracking?error=state_mismatch`,
    );
  }

  try {
    // 1. code → short-lived token
    const short = await exchangeCodeForToken(code);
    // 2. short → long-lived (~60 dias)
    const long = await exchangeForLongLivedToken(short.accessToken);
    // 3. Pegar info do usuário FB
    const me = await getMe(long.accessToken);
    // 4. Listar ad accounts
    const accounts = await listAdAccounts(long.accessToken);

    if (accounts.length === 0) {
      return NextResponse.redirect(
        `${appUrl}/dashboard/tracking?error=no_ad_accounts`,
      );
    }

    const encryptedToken = encryptString(long.accessToken);
    const expiresAt = new Date(Date.now() + long.expiresInSec * 1000);

    for (const acc of accounts) {
      await prisma.adAccount.upsert({
        where: {
          userId_platform_accountId: {
            userId,
            platform: "meta",
            accountId: acc.id,
          },
        },
        create: {
          userId,
          platform: "meta",
          externalUserId: me.id,
          accountId: acc.id,
          accountName: acc.business_name
            ? `${acc.business_name} — ${acc.name}`
            : acc.name,
          accessToken: encryptedToken,
          expiresAt,
          scope: "ads_read,ads_management,business_management",
          status: "active",
        },
        update: {
          accessToken: encryptedToken,
          expiresAt,
          status: "active",
          accountName: acc.business_name
            ? `${acc.business_name} — ${acc.name}`
            : acc.name,
          externalUserId: me.id,
        },
      });
    }

    const success = NextResponse.redirect(
      `${appUrl}/dashboard/tracking?connected=meta&count=${accounts.length}`,
    );
    success.cookies.set(COOKIE_NAME, "", { maxAge: 0, path: "/" });
    return success;
  } catch (e) {
    console.error("[meta/callback]", e);
    const msg = e instanceof Error ? e.message : "unknown";
    const errResp = NextResponse.redirect(
      `${appUrl}/dashboard/tracking?error=${encodeURIComponent(msg)}`,
    );
    errResp.cookies.set(COOKIE_NAME, "", { maxAge: 0, path: "/" });
    return errResp;
  }
}
