"use client";

import Link from "next/link";
import dynamic from "next/dynamic";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import {
  Activity,
  TrendingUp,
  Trophy,
  AlertTriangle,
  ArrowUpRight,
  Coins,
  Sparkles,
  Package,
  Flame,
  Pause,
  Rocket,
  Download,
  Loader2,
  ArrowUp,
  ArrowDown,
  CalendarDays,
  Star,
} from "lucide-react";
import type { AdsOverview as AdsOverviewData } from "@/lib/ads-overview";
import { pauseAdCampaign, scaleAdCampaign } from "@/app/dashboard/ads-actions";

const AdsEvolutionChart = dynamic(
  () =>
    import("./ads-evolution-chart").then((m) => ({
      default: m.AdsEvolutionChart,
    })),
  {
    ssr: false,
    loading: () => (
      <div className="flex h-56 items-center justify-center text-xs text-zinc-500">
        carregando gráfico…
      </div>
    ),
  },
);

function brl(cents: number): string {
  return (cents / 100).toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  });
}

const PLATFORM_LABEL: Record<string, string> = {
  meta: "Meta",
  tiktok: "TikTok",
};

export function AdsOverview({ data }: { data: AdsOverviewData }) {
  const {
    platforms,
    totalRoas,
    best,
    worst,
    topCreatives,
    favorites,
    burningCount,
    series,
    topProducts,
    projection,
    comparison,
    converted,
    fxLive,
  } = data;

  const projProfit = projection.projRevenueCents - projection.projSpendCents;
  const showProjection =
    projection.spendTodayCents > 0 || projection.revenueTodayCents > 0;

  /** 📅 Exporta o histórico diário (snapshots) pra CSV (pt-BR). */
  function exportHistoryCsv() {
    const dec = (cents: number) => (cents / 100).toFixed(2).replace(".", ",");
    const headers = ["Dia", "Gasto", "Receita", "Lucro", "ROAS"];
    const rows = series.map((s) => {
      const profit = s.revenueCents - s.spendCents;
      const roas =
        s.spendCents > 0
          ? (s.revenueCents / s.spendCents).toFixed(2).replace(".", ",")
          : "";
      return [
        s.day,
        dec(s.spendCents),
        dec(s.revenueCents),
        dec(profit),
        roas,
      ];
    });
    const esc = (v: string) =>
      /[";\r\n]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v;
    const csv = [headers, ...rows]
      .map((r) => r.map((c) => esc(String(c ?? ""))).join(";"))
      .join("\r\n");
    const blob = new Blob(["﻿" + csv], {
      type: "text/csv;charset=utf-8;",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `ads-historico-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="rounded-2xl border border-white/[0.08] bg-white/[0.02] p-5">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h2 className="flex items-center gap-2 text-sm font-medium text-white">
            <Activity className="size-4 text-lime-400" />
            Tracking · Ads (hoje)
          </h2>
          <p className="text-xs text-zinc-500">
            Gasto × receita das suas contas de anúncio (sincronizado).
          </p>
          {converted && (
            <p className="mt-1 inline-flex items-center gap-1 rounded-full bg-white/[0.04] px-2 py-0.5 text-[10px] text-zinc-400">
              <Coins className="size-3 text-amber-300" />
              Inclui contas convertidas pra BRL ·{" "}
              {fxLive ? "câmbio ao vivo" : "câmbio aprox."}
            </p>
          )}
        </div>
        <Link
          href="/dashboard/tracking/campanhas"
          className="inline-flex items-center gap-1 text-xs text-zinc-400 hover:text-lime-300"
        >
          Ver campanhas <ArrowUpRight className="size-3" />
        </Link>
      </div>

      {/* ⭐ Favoritas (campanhas marcadas pra acompanhar) */}
      {favorites.length > 0 && (
        <div className="mb-3 rounded-xl border border-amber-400/20 bg-amber-400/[0.04] p-3">
          <p className="mb-2 flex items-center gap-1.5 text-[11px] uppercase tracking-wider text-amber-300">
            <Star className="size-3.5 fill-amber-400 text-amber-400" />
            Favoritas
          </p>
          <div className="space-y-1">
            {favorites.map((f, i) => (
              <div
                key={i}
                className="flex items-center justify-between gap-3 rounded-lg bg-black/20 px-3 py-1.5 text-xs"
              >
                <span className="min-w-0 truncate text-zinc-200" title={f.name}>
                  {f.name}
                  {!f.active && (
                    <span className="ml-1 text-[10px] text-zinc-500">
                      · pausada
                    </span>
                  )}
                  <span className="ml-1 text-[10px] text-zinc-600">
                    · {PLATFORM_LABEL[f.platform] ?? f.platform}
                  </span>
                </span>
                <span className="flex shrink-0 items-center gap-3 tabular-nums">
                  <span className="text-zinc-500">
                    {brl(f.spendCents)} → {brl(f.revenueCents)}
                  </span>
                  <span
                    className={
                      f.roas == null
                        ? "text-zinc-600"
                        : f.roas >= 1
                          ? "font-semibold text-lime-400"
                          : "font-semibold text-red-400"
                    }
                  >
                    {f.roas != null ? `${f.roas.toFixed(2)}x` : "—"}
                  </span>
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ROAS total + por plataforma */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-3">
        <RoasCard
          label="ROAS total"
          roas={totalRoas}
          sub={platforms
            .map(
              (p) =>
                `${PLATFORM_LABEL[p.platform] ?? p.platform} ${
                  p.roas != null ? `${p.roas.toFixed(2)}x` : "—"
                }`,
            )
            .join(" · ")}
        />
        {platforms.slice(0, 2).map((p) => (
          <RoasCard
            key={p.platform}
            label={`ROAS ${PLATFORM_LABEL[p.platform] ?? p.platform}`}
            roas={p.roas}
            sub={`${brl(p.spendCents)} → ${brl(p.revenueCents)}`}
          />
        ))}
      </div>

      {/* Melhor × Pior campanha */}
      <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
        <BestCampaignCard best={best} />
        <WorstCampaignCard worst={worst} />
      </div>

      {/* 🏆 Ranking de criativos */}
      {topCreatives.length > 0 && (
        <div className="mt-3">
          <p className="mb-2 flex items-center gap-1.5 text-[11px] uppercase tracking-wider text-zinc-500">
            <Trophy className="size-3.5 text-amber-400" />
            Top criativos (hoje)
          </p>
          <div className="space-y-1">
            {topCreatives.map((c, i) => (
              <div
                key={i}
                className="flex items-center justify-between gap-3 rounded-lg border border-white/[0.05] bg-white/[0.02] px-3 py-1.5 text-xs"
              >
                <span className="min-w-0 truncate text-zinc-300" title={c.name}>
                  <span className="mr-1 text-zinc-600">{i + 1}.</span>
                  {c.name}
                  <span className="ml-1 text-[10px] text-zinc-600">
                    · {c.campaign}
                  </span>
                </span>
                <span className="flex shrink-0 items-center gap-3 tabular-nums">
                  <span className="text-zinc-500">{brl(c.revenueCents)}</span>
                  <span
                    className={
                      c.roas == null
                        ? "text-zinc-600"
                        : c.roas >= 1
                          ? "font-semibold text-lime-400"
                          : "font-semibold text-red-400"
                    }
                  >
                    {c.roas != null ? `${c.roas.toFixed(2)}x` : "—"}
                  </span>
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Ritmo de hoje (projeção) */}
      {showProjection && (
        <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 rounded-xl border border-indigo-400/20 bg-indigo-400/[0.04] px-4 py-2.5 text-xs">
          <span className="flex items-center gap-1.5 font-medium text-indigo-300">
            <Sparkles className="size-3.5" />
            Ritmo de hoje ({Math.round(projection.fractionElapsed * 100)}% do dia)
          </span>
          <span className="text-zinc-400">
            Gasto proj.{" "}
            <strong className="text-red-300">
              {brl(projection.projSpendCents)}
            </strong>
          </span>
          <span className="text-zinc-400">
            Receita proj.{" "}
            <strong className="text-lime-300">
              {brl(projection.projRevenueCents)}
            </strong>
          </span>
          <span className="text-zinc-400">
            Lucro proj.{" "}
            <strong className={projProfit >= 0 ? "text-lime-300" : "text-red-300"}>
              {brl(projProfit)}
            </strong>
          </span>
        </div>
      )}

      {/* 📆 Hoje vs ontem (mesmo horário) */}
      {comparison && (
        <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-2.5 text-xs">
          <span className="flex items-center gap-1.5 font-medium text-zinc-300">
            <CalendarDays className="size-3.5 text-zinc-400" />
            Hoje vs ontem (mesmo horário)
          </span>
          <DeltaPill label="Receita" pct={comparison.revenueDeltaPct} tone="good" />
          <DeltaPill label="Gasto" pct={comparison.spendDeltaPct} tone="neutral" />
          <DeltaPill label="Lucro" pct={comparison.profitDeltaPct} tone="good" />
          <DeltaPill label="ROAS" pct={comparison.roasDeltaPct} tone="good" />
        </div>
      )}

      {/* ROAS por produto */}
      {topProducts.length > 0 && (
        <div className="mt-3">
          <p className="mb-2 flex items-center gap-1.5 text-[11px] uppercase tracking-wider text-zinc-500">
            <Package className="size-3.5" />
            ROAS por produto (hoje)
          </p>
          <div className="space-y-1">
            {topProducts.map((p, i) => (
              <div
                key={i}
                className="flex items-center justify-between gap-3 rounded-lg border border-white/[0.05] bg-white/[0.02] px-3 py-1.5 text-xs"
              >
                <span className="truncate text-zinc-300" title={p.name}>
                  {p.name}
                </span>
                <span className="flex shrink-0 items-center gap-3 tabular-nums">
                  <span className="text-zinc-500">{brl(p.revenueCents)}</span>
                  <span
                    className={
                      p.roas == null
                        ? "text-zinc-600"
                        : p.roas >= 1
                          ? "text-lime-400 font-semibold"
                          : "text-red-400 font-semibold"
                    }
                  >
                    {p.roas != null ? `${p.roas.toFixed(2)}x` : "—"}
                  </span>
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Alerta de queima */}
      {burningCount > 0 && (
        <Link
          href="/dashboard/tracking/campanhas"
          className="mt-3 flex items-center gap-2 rounded-xl border border-amber-500/30 bg-amber-500/[0.06] px-4 py-2.5 text-xs text-amber-200 hover:bg-amber-500/[0.1] transition"
        >
          <AlertTriangle className="size-4 shrink-0 text-amber-400" />
          {burningCount === 1
            ? "1 campanha gastando sem vender hoje"
            : `${burningCount} campanhas gastando sem vender hoje`}{" "}
          <ArrowUpRight className="ml-auto size-3.5" />
        </Link>
      )}

      {/* Gráfico de evolução */}
      {series.length > 0 && (
        <div className="mt-4">
          <div className="mb-2 flex items-center justify-between">
            <p className="flex items-center gap-1.5 text-[11px] uppercase tracking-wider text-zinc-500">
              <TrendingUp className="size-3.5" />
              Evolução ({series.length} dia{series.length > 1 ? "s" : ""})
            </p>
            <button
              type="button"
              onClick={exportHistoryCsv}
              title="Baixar histórico diário em CSV"
              className="inline-flex items-center gap-1 rounded-full bg-white/[0.04] px-2.5 py-1 text-[11px] text-zinc-400 hover:bg-white/[0.08] hover:text-zinc-200 transition"
            >
              <Download className="size-3" />
              Exportar histórico
            </button>
          </div>
          <AdsEvolutionChart data={series} />
        </div>
      )}
    </div>
  );
}

function RoasCard({
  label,
  roas,
  sub,
}: {
  label: string;
  roas: number | null;
  sub?: string;
}) {
  const good = roas != null && roas >= 1;
  return (
    <div className="rounded-xl border border-white/[0.08] bg-white/[0.02] p-4">
      <p className="text-[10px] uppercase tracking-wider text-zinc-500">
        {label}
      </p>
      <p
        className={`mt-1 text-lg font-semibold tabular-nums ${
          roas == null ? "text-zinc-500" : good ? "text-lime-400" : "text-red-400"
        }`}
      >
        {roas != null ? `${roas.toFixed(2)}x` : "—"}
      </p>
      {sub && <p className="truncate text-[10px] text-zinc-500" title={sub}>{sub}</p>}
    </div>
  );
}

function DeltaPill({
  label,
  pct,
  tone,
}: {
  label: string;
  pct: number | null;
  tone: "good" | "neutral";
}) {
  if (pct == null) {
    return (
      <span className="text-zinc-500">
        {label} <span className="text-zinc-600">—</span>
      </span>
    );
  }
  const up = pct >= 0;
  const color =
    tone === "neutral" ? "text-zinc-300" : up ? "text-lime-400" : "text-red-400";
  const Icon = up ? ArrowUp : ArrowDown;
  return (
    <span className="flex items-center gap-1 text-zinc-400">
      {label}
      <span className={`inline-flex items-center gap-0.5 font-semibold ${color}`}>
        <Icon className="size-3" />
        {Math.abs(pct).toFixed(0)}%
      </span>
    </span>
  );
}

function BestCampaignCard({ best }: { best: AdsOverviewData["best"] }) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [msg, setMsg] = useState<string | null>(null);

  if (!best) {
    return (
      <div className="rounded-xl border border-white/[0.08] bg-white/[0.02] p-4">
        <p className="flex items-center gap-1 text-[10px] uppercase tracking-wider text-zinc-500">
          <Trophy className="size-3 text-amber-400" /> Melhor campanha
        </p>
        <p className="mt-1 text-sm text-zinc-600">—</p>
      </div>
    );
  }

  const b = best;
  function scale() {
    if (
      !confirm(`Subir o budget de "${b.name}" em +20%? (aplica na plataforma)`)
    )
      return;
    setMsg(null);
    startTransition(async () => {
      const r = await scaleAdCampaign(b.adAccountDbId, b.externalId, 20);
      if (r.ok) {
        setMsg(`→ ${brl(r.newBudgetCents)}/dia`);
        router.refresh();
      } else {
        setMsg(r.error);
      }
    });
  }

  return (
    <div className="rounded-xl border border-lime-400/20 bg-lime-400/[0.04] p-4">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="flex items-center gap-1 text-[10px] uppercase tracking-wider text-zinc-500">
            <Trophy className="size-3 text-amber-400" /> Melhor campanha
          </p>
          <p className="mt-1 truncate text-sm font-semibold text-white" title={b.name}>
            {b.name}
          </p>
          <p className="text-[11px] tabular-nums text-lime-400">
            {b.roas.toFixed(2)}x · {PLATFORM_LABEL[b.platform] ?? b.platform}
          </p>
        </div>
        <button
          type="button"
          onClick={scale}
          disabled={isPending}
          title="Subir budget +20%"
          className="inline-flex shrink-0 items-center gap-1 rounded-md border border-lime-400/30 bg-lime-400/10 px-2 py-1 text-[11px] font-medium text-lime-300 transition hover:bg-lime-400/20 disabled:opacity-50"
        >
          {isPending ? (
            <Loader2 className="size-3 animate-spin" />
          ) : (
            <Rocket className="size-3" />
          )}
          +20%
        </button>
      </div>
      {msg && <p className="mt-1 text-[10px] text-lime-300">{msg}</p>}
    </div>
  );
}

function WorstCampaignCard({ worst }: { worst: AdsOverviewData["worst"] }) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [msg, setMsg] = useState<string | null>(null);

  if (!worst) {
    return (
      <div className="rounded-xl border border-white/[0.08] bg-white/[0.02] p-4">
        <p className="flex items-center gap-1 text-[10px] uppercase tracking-wider text-zinc-500">
          <Flame className="size-3 text-orange-400" /> Pior campanha
        </p>
        <p className="mt-1 text-sm text-zinc-600">nenhuma no prejuízo 🎉</p>
      </div>
    );
  }

  const w = worst;
  function pause() {
    if (!confirm(`Pausar "${w.name}"? (reversível na plataforma)`)) return;
    setMsg(null);
    startTransition(async () => {
      const r = await pauseAdCampaign(w.adAccountDbId, w.externalId);
      if (r.ok) {
        setMsg("pausada");
        router.refresh();
      } else {
        setMsg(r.error);
      }
    });
  }

  return (
    <div className="rounded-xl border border-red-500/20 bg-red-500/[0.04] p-4">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="flex items-center gap-1 text-[10px] uppercase tracking-wider text-zinc-500">
            <Flame className="size-3 text-orange-400" /> Pior campanha (mais queima)
          </p>
          <p className="mt-1 truncate text-sm font-semibold text-white" title={w.name}>
            {w.name}
          </p>
          <p className="text-[11px] tabular-nums text-red-300">
            {w.roas.toFixed(2)}x · {brl(w.spendCents)} gastos ·{" "}
            {PLATFORM_LABEL[w.platform] ?? w.platform}
          </p>
        </div>
        <button
          type="button"
          onClick={pause}
          disabled={isPending}
          className="inline-flex shrink-0 items-center gap-1 rounded-md border border-red-500/30 bg-red-500/10 px-2 py-1 text-[11px] font-medium text-red-300 transition hover:bg-red-500/20 disabled:opacity-50"
        >
          {isPending ? (
            <Loader2 className="size-3 animate-spin" />
          ) : (
            <Pause className="size-3" />
          )}
          Pausar
        </button>
      </div>
      {msg && <p className="mt-1 text-[10px] text-lime-300">{msg}</p>}
    </div>
  );
}
