"use client";

import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

type Point = { day: string; spendCents: number; revenueCents: number };

function dayLabel(iso: string): string {
  const [, m, d] = iso.split("-");
  return `${d}/${m}`;
}

/** Evolução diária: Gasto × Receita × Lucro (a partir dos snapshots). */
export function AdsEvolutionChart({ data }: { data: Point[] }) {
  const points = data.map((p) => ({
    label: dayLabel(p.day),
    gasto: p.spendCents / 100,
    receita: p.revenueCents / 100,
    lucro: (p.revenueCents - p.spendCents) / 100,
  }));

  return (
    <div className="h-56 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={points} margin={{ top: 6, right: 6, left: 0, bottom: 0 }}>
          <CartesianGrid stroke="rgba(255,255,255,0.04)" vertical={false} />
          <XAxis
            dataKey="label"
            stroke="#71717a"
            fontSize={10}
            tickLine={false}
            axisLine={false}
            interval={Math.max(0, Math.floor(points.length / 6) - 1)}
          />
          <YAxis
            stroke="#71717a"
            fontSize={10}
            tickLine={false}
            axisLine={false}
            tickFormatter={(v: number) =>
              Math.abs(v) >= 1000 ? `${(v / 1000).toFixed(0)}k` : String(v)
            }
            width={40}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: "rgba(10,10,10,0.95)",
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: 12,
              fontSize: 12,
              color: "#fafafa",
            }}
            labelStyle={{ color: "#a1a1aa", fontSize: 11 }}
            formatter={(value, name) => {
              const n = Array.isArray(value) ? 0 : Number(value);
              return [
                `R$ ${n.toFixed(2).replace(".", ",")}`,
                String(name),
              ];
            }}
          />
          <Line
            type="monotone"
            dataKey="gasto"
            name="Gasto"
            stroke="#f87171"
            strokeWidth={2}
            dot={false}
          />
          <Line
            type="monotone"
            dataKey="receita"
            name="Receita"
            stroke="#a3e635"
            strokeWidth={2}
            dot={false}
          />
          <Line
            type="monotone"
            dataKey="lucro"
            name="Lucro"
            stroke="#60a5fa"
            strokeWidth={2}
            strokeDasharray="4 2"
            dot={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
